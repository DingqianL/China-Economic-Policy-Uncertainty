# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 14:40:57 2019

@author: dingq
"""

import tushare as ts

sse = ts.get_h_data('000001',index = True)
sse2 = ts.get_h_data('000001', start="1992-01-01", end= "1993-12-31", index = True)
sse94_95 = ts.get_h_data('000001', start="1994-01-01", end= "1995-12-31", index = True)
sse96_97 = ts.get_h_data('000001', start="1996-01-01", end= "1997-12-31", index = True)
sse98_99 = ts.get_h_data('000001', start="1998-01-01", end= "1999-12-31", index = True)
sse00_01 = ts.get_h_data('000001', start="2000-01-01", end= "2001-12-31", index = True)

sse02_03 = ts.get_h_data('000001', start="2002-01-01", end= "2003-12-31", index = True)
sse04_05 = ts.get_h_data('000001', start="2004-01-01", end= "2005-12-31", index = True)

sse06_07 = ts.get_h_data('000001', start="2006-01-01", end= "2007-12-31", index = True)
sse08_09 = ts.get_h_data('000001', start="2008-01-01", end= "2009-12-31", index = True)

sse10_11 = ts.get_h_data('000001', start="2010-01-01", end= "2011-12-31", index = True)
sse12_13 = ts.get_h_data('000001', start="2012-01-01", end= "2013-12-31", index = True)

sse14_15 = ts.get_h_data('000001', start="2014-01-01", end= "2015-12-31", index = True)
sse16_17 = ts.get_h_data('000001', start="2016-01-01", end= "2017-12-31", index = True)

sse18 = ts.get_h_data('000001', start="2018-01-01", end= "2018-12-31", index = True)


import pandas as pd
dataframe = [sse2, sse94_95, sse96_97, sse98_99, sse00_01, sse02_03, sse04_05,\
             sse06_07, sse08_09, sse10_11, sse12_13, sse14_15, sse16_17, sse]
sse_his = pd.concat(dataframe)

sse_his.columns

sse_his['date'] = sse_his.index

sse_his.head(5)

sse_his.sort_values('date')

import os
path = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\220_papaer_preperation'
os.chdir(path)

sse_his.to_csv("sse_his.csv")
sse_his['return'] = sse_his['close']/sse_his['open']-1

for i in sse_his['return']:
    if abs(i)>=0.04 is True:
        sse_his['jump'] =  1
    else:
        sse_his['jump'] = 0 
        
type(sse_his['return'][0])





