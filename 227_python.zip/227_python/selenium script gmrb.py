# -*- coding: utf-8 -*-
"""
2nd Modified on Fri Apr 29, 2022
1st Modified on Mon Mar 30 15:28:29 2020

@author: Dingqian Liu
"""
# import packages (need to install)
import os
from selenium import webdriver # need to download chromedriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time # to give the browser and server some rest time
import numpy as np

import sys
print(sys.path) # checking on the system path

# set the default folder
path = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\2000_2007'
os.chdir (path)

# start a controled chrome window
driver = webdriver.Chrome('C:\\Users\\dingq\\Documents\\200_academic\\220_Academic_My dissertation\\227_python\chromedriver.exe')

# log into the ruc webpage
driver.get("http://www.libproxy.ruc.edu.cn/")
time.sleep(5) # give the chrome window 5 seconds rest
# need to manually log into the account and find the guangming daily webpage
#
#driver.switch_to.default_content()
#driver.switch_to.frame('navigate')
#years = driver.find_elements_by_xpath("//a[@target = 'self']")

#years = years.find_elements_by_xpath('//a[@href]')

#time.sleep(10)
#m = years[33].get_attribute('href')
#years[32].click()

# find the correct tab and iframe
m = 3127 # there are 3127 pages for 2007
n = 414 # I start from page 2
while n<m:
    driver.switch_to.window(driver.window_handles[-1])
    driver.switch_to.default_content()
    driver.switch_to.frame('main')

    # find the correct article links
    articles = driver.find_element(by=By.XPATH, value="//div[@align = 'center']")
    articles = articles.find_elements(by=By.XPATH,  value="//a[@href]")

    articles = articles[-10:] # the first few links are for different pages, the last 10 links are links of articles
    #for i in articles:
     #   print(i.get_attribute('href'))


    # open new tabs for each article
    for i in articles:
        i.send_keys(Keys.CONTROL + Keys.RETURN)
        time.sleep(abs(np.random.normal(1,4,1)[0])) # set random time to rest after openning each article tab
    
    t = len(driver.window_handles) # count the number of tabs of articles 
    while t > 1:
        driver.switch_to.window(driver.window_handles[-1])
        driver.find_element(by=By.TAG_NAME, value='body').send_keys(Keys.CONTROL + Keys.TAB)
    
        driver.switch_to.default_content()
        seq = driver.find_elements(by=By.TAG_NAME, value='iframe')
        iframe = driver.find_elements(by=By.TAG_NAME, value='iframe')[0]

        driver.switch_to.frame(iframe)

        driver.implicitly_wait(2)
        date = driver.find_element(by=By.XPATH, value="//table[@id = 'Table_02']")
        date = date.find_elements(by=By.XPATH, value="//div[@style = 'margin-bottom:4px']")
        date = date[-1].text[:10]
        title = driver.find_element(by=By.XPATH, value="//div[@class ='STYLE11']").text
        content = driver.find_element(by=By.XPATH, value="//div[@id = 'str_zhenwen']").text
        with open(date +'.txt', 'a', encoding = 'utf8') as f:
            f.write(date + title + content+'/n')
        driver.close()   
        time.sleep(abs(np.random.normal(1,5,1)[0]))
        t = len(driver.window_handles)

    
    driver.switch_to.window(driver.window_handles[0])

    driver.switch_to.default_content()
    driver.switch_to.frame('main')

    articles = driver.find_element(by=By.XPATH, value="//div[@align = 'center']")
    articles = articles.find_elements(by=By.XPATH, value="//a[@href]")
    articles = [i for i in articles if i.get_attribute('href').startswith('http')]
    #for i in articles:
    #    print(i.get_attribute('href'))
    next = articles[-2]

    next.send_keys(Keys.RETURN)
    n= n+1
