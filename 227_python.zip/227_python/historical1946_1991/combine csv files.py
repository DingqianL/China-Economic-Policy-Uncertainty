# -*- coding: utf-8 -*-
"""
Created on Sun Jul 29 10:17:05 2018

@author: dingq
"""


import os
import pandas as pd
import shutil

#for supplement files, combine them together
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\supplement\1963'
os.chdir(path)


list=os.listdir(path)         
            
all_txt=''
for i in list:
    with open(i,'r',errors='ignore') as f:
        txt=f.read()
        all_txt=all_txt+str(txt)
with open('1963_sup.txt','w') as f:
    f.write(all_txt)

#combine csv files
dire=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
folder1=os.listdir(dire)
folder1=[f for f in folder1 if f.endswith('.csv')]

newpath=dire+'\\'+'csv'
os.makedirs(newpath)
#fullcsv=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\full.csv'
##把所有的csv文件都放在一个文件夹下
for i in folder1:
    dire1=dire+"\\"+i
    folder2=os.listdir(dire1)
    csvfiles=[f for f in folder2 if f.endswith(".csv")]
    csvfile=csvfiles[0]
    csvdire=dire1+"\\"+csvfile
    shutil.copy(csvdire, newpath)
    #content=pd.read_csv(csvdire)
    
    #with open(fullcsv,'a+') as f:
        #content.to_csv(f, header=False)
                    
#合并1946-1991的为一个csv
dire=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
filecsvs=os.listdir(dire)
filecsvs=[f for f in folder1 if f.endswith('.csv')]

newpath2=dire+'\\'+'historical1946_1977'
os.makedirs(newpath2)
os.chdir(newpath2)

#append all the data in a dataframe
dataframe=pd.DataFrame()

for i in filecsvs[32:]:
    direfile=dire+'\\'+i
    data=pd.read_csv(direfile)
    #if len(data.columns)>7:
        #print(i)
    dataframe=dataframe.append(data, sort=False)

dataframe
col=dataframe.columns
del dataframe['p']
del dataframe['u']
dataframe.to_csv('modern1978_2018.csv')


###generate daily index 
dataframe_h=pd.read_csv('all_1946_2018.csv')
dataframe_h.columns
del dataframe_h['Unnamed: 0']

epu_std=dataframe_h['epu_count'].std()
epu_e_std=dataframe_h['epu_econ'].std()

dataframe_h['epu_std']\
=dataframe_h['epu_count']/epu_std

dataframe_h['epu_e_std']\
=dataframe_h['epu_econ']/epu_e_std

epu_mean=dataframe_h['epu_std'].mean()
epu_e_mean=dataframe_h['epu_e_std'].mean()


dataframe_h['epu_normalized']\
=dataframe_h['epu_std']/epu_mean*100

dataframe_h['epu_e_normalized']\
=dataframe_h['epu_e_std']/epu_e_mean*100


dataframe_h.head(n=10)
dataframe_h.tail(n=10)

dataframe_h.to_csv('all_daily.csv')


#and monthly index

date_date=dataframe_h['date']
date_date=date_date.tolist()

import datetime
date_time=[]
for i in date_date:
    i=str(i)
    datetime0=datetime.datetime.strptime(i,'%m/%d/%Y')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y/%m')
    month_time.append(month_time0)

len(month_time)

dataframe_h['month']=month_time

dataframe_h['month']

df_month=dataframe_h.groupby('month').sum().reset_index()

df_month['epu_count']=df_month['epu']/df_month['count']
df_month['epu_econ']=df_month['epu']/df_month['e']

df_month.head(n=10)

df_month.columns

std2=df_month['epu_count'].std()
std2_e=df_month['epu_econ'].std()

df_month['epu_month_std']=df_month['epu_count']/std2
df_month['epu_month_e_std']=df_month['epu_econ']/std2_e

mean2=df_month['epu_month_std'].mean()
mean2_e=df_month['epu_month_e_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month['epu_month_e_normalized']=df_month['epu_month_e_std']*100/mean2_e

df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('all_month.csv')

import datetime as dt
#convert to quarter
df_quarter=pd.read_csv('all_1946_2018.csv')
del df_quarter['Unnamed: 0']

df_quarter['Qtr'] = pd.PeriodIndex(pd.to_datetime(df_quarter.date), freq='Q')

df_quarter=df_quarter.groupby('Qtr').sum().reset_index()

df_quarter['epu_count']=df_quarter['epu']/df_quarter['count']
df_quarter['epu_econ']=df_quarter['epu']/df_quarter['e']

df_quarter.columns
df_quarter.head(10)

std2=df_quarter['epu_count'].std()
std2_e=df_quarter['epu_econ'].std()

df_quarter['epu_quarter_std']=df_quarter['epu_count']/std2
df_quarter['epu_quarter_e_std']=df_quarter['epu_econ']/std2_e

mean2=df_quarter['epu_quarter_std'].mean()
mean2_e=df_quarter['epu_quarter_std'].mean()

df_quarter['epu_quarter_normalized']=df_quarter['epu_quarter_std']*100/mean2
df_quarter['epu_quarter_e_normalized']=df_quarter['epu_quarter_e_std']*100/mean2_e

del df_quarter['epu_quarter_std']
del df_quarter['epu_quarter_e_std']

df_quarter.to_csv('all_quarter.csv')

####SCMP
scmp=pd.read_excel('China_Policy_Uncertainty_Data.xlsx')
scmp.head(10)

scmp.columns
del scmp['year']
del scmp['month']
del scmp['Unnamed: 3']
scmp['epu']=scmp['China News-Based EPU']


scmp=scmp.groupby('Qtr').sum().reset_index()
scmp.to_excel('scmp.xlsx')

scmp['epu_count']=scmp['epu']/scmp['count']
scmp['epu_econ']=scmp['epu']/scmp['e']

df_quarter.columns
df_quarter.head(10)

std2=df_quarter['epu_count'].std()
std2_e=df_quarter['epu_econ'].std()

df_quarter['epu_quarter_std']=df_quarter['epu_count']/std2
df_quarter['epu_quarter_e_std']=df_quarter['epu_econ']/std2_e

mean2=df_quarter['epu_quarter_std'].mean()
mean2_e=df_quarter['epu_quarter_std'].mean()

df_quarter['epu_quarter_normalized']=df_quarter['epu_quarter_std']*100/mean2
df_quarter['epu_quarter_e_normalized']=df_quarter['epu_quarter_e_std']*100/mean2_e

del df_quarter['epu_quarter_std']
del df_quarter['epu_quarter_e_std']

df_quarter.to_csv('all_quarter.csv')
