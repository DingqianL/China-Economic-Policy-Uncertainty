# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 14:47:21 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 07:13:05 2018

@author: dingq
"""

### New and full data received on Mar 28 2018
### However, the data come in annually, that is all the newspaper in one year came in a singel text file.

## step 1: split the file into single article with date label


#import modules
import os 
#import epu
import tepu
#open and read text file
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete'
os.chdir(path)
files=os.listdir(path)
txtfiles=[f for f in files if f.endswith('.txt')]
txtfiles=[f for f in txtfiles if len(f)==8]

   
##this function applies for RMRB 1946-2006 for tepu
for i in txtfiles:
    tepu.tepu1(i)
## this works for RMRB 2007-2016 for epu
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete'
os.chdir(path)

with open('rmrb2007_2016_ue.txt', 'r+', errors='ignore') as f:
    text=f.read()
text=text.replace(' ', '') #delete space
text=text.replace('\n','') #delete lines

    

## this works for RMRB 2017-2018 for tepu
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete'
os.chdir(path)
files=os.listdir(path)
folders3=['2017','2018'] #each element is a year

for i in folders3:
    path0=os.path.join(path,i) #get the path of each year
    folders=os.listdir(path0) #every element is each date in the year
    tepu.tepu3(folders,path0)

###this works for GMRB 2008-2018 for tepu
import os
import tepu
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb'
os.chdir(path)
files=os.listdir(path)
folders=[f for f in files if len(f)>3 and len(f)<5]
folders=folders[:-1]

for i in folders[-11:]:
    path0=os.path.join(path,i) #get the path of each year
    folder=os.listdir(path0) #every element is each date in the year
    folder=[f for f in folder if not f.endswith('.csv')]
    tepu.tepu4(folder,path0)




##combine all the rmrb EPU csv files
import os    
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\mtepu'
###注意要重新写了，因为多加了csv在同一个folder下
csvfiles=os.listdir(path)
csvfiles=csvfiles[0,2,4,6]
csvs = []
csvs.append(csvfiles[0])
csvs.append(csvfiles[2])
csvs.append(csvfiles[4])
csvs.append(csvfiles[6])

##combine for 1946-2006, thus 61
os.chdir(path)

import pandas as pd

##build an empty dataframe so that we can combine csv from all years later
dataframe=pd.DataFrame() 
for i in csvs:
    csvf=pd.read_csv(i)
    dataframe=dataframe.append(csvf, sort=False)

##combination finished, but there's bugs in date selection
## export the file, mannually delete those nonsense dates
import datetime
dataframe.to_csv('pre_date1946_2006.csv', index=False)
## import the post-mannually fixed file
dataframe=pd.read_csv('pre_date1946_2006.csv')
dataframe.head(10)

##still, I do not have wrong dates, but I have missing dates
##to fix this, I need to form the date variable into desired format
## and set it as index, to excute the concat command
dataframe.count
date0=dataframe['date'].tolist()
##the current date format is %m/%d/%Y
date1=[datetime.datetime.strptime(f,'%m/%d/%Y') for f in date0]

##make the desired format '%Y-%m-%d'
date2=[f.strftime('%Y-%m-%d') for f in date1]
dataframe['date']=date2
#set the variable as index
dataframe=dataframe.set_index('date')
dataframe.head(10)

##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(1946, 5, 15)  # start date
d2 = datetime.datetime(2006, 12, 31)  # end date

delta = d2 - d1         # timedelta

#generate a list of datetime
datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

#to make it as the same date format as my epus
date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

#transform the date list into datafarm to excute the concate command
date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame.head(10)
date_frame.count

###
##excute the concat command of pandas dataframe
epudaily_1946_2006=pd.concat([dataframe, date_frame], axis=1,sort=False)

##the default of concat command is to leave unmatched observations after matched
## This causes a disorder of our dates
epudaily_1946_2006=epudaily_1946_2006.sort_values(by='date')
epudaily_1946_2006.count
epudaily_1946_2006.tail(10)
epudaily_1946_2006=epudaily_1946_2006.set_index('date')
epudaily_1946_2006.to_csv('1946_2006.csv')    

################################################################################
##combine 2007-2016
csvfiles2=csvfiles[61:-2]
dataframe07_16=pd.DataFrame()
for i in csvfiles2:
    csvf=pd.read_csv(i)
    dataframe07_16=dataframe07_16.append(csvf, sort=False)
    
dataframe07_16.head(10)
dataframe07_16.columns
dataframe07_16['date']=dataframe07_16['Unnamed: 0']
del dataframe07_16['Unnamed: 0']
dataframe07_16=dataframe07_16.set_index('date')
dataframe07_16.to_csv('2007_2016.csv')    


############################################################################
#combine 2017-2018
csvfiles3=csvfiles[-2:]
dataframe17_18=pd.DataFrame()
for i in csvfiles3:
    csvf=pd.read_csv(i)
    dataframe17_18=dataframe17_18.append(csvf, sort=False)
    
    
dataframe17_18.head(10)
dataframe17_18.tail(10)

import datetime
date0=dataframe17_18['date'].tolist()
date1=[datetime.datetime.strptime(f,'%m/%d/%Y') for f in date0]
date2=[f.strftime('%Y-%m-%d') for f in date1]
dataframe17_18['date']=date2
dataframe17_18=dataframe17_18.set_index('date')
dataframe17_18.to_csv('2017_2018.csv')


##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(2017, 1, 1)  # start date
d2 = datetime.datetime(2018, 10, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame.head(10)
date_frame.count

###
epudaily_1718=pd.concat([dataframe17_18, date_frame], axis=1,sort=False)
epudaily_1718.count
epudaily_1718.head(10)
del epudaily_1718['date']
epudaily_1718.to_csv('2017_2018.csv')    

############################
###combine 3 parts
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\epu181019\all'

filesall=os.listdir(path)
os.chdir(path)
filesall
filesall[:3]

dataframe46_18=pd.DataFrame()
for i in filesall[:3]:
    csvf=pd.read_csv(i)
    dataframe46_18=dataframe46_18.append(csvf, sort=False)

dataframe46_18.tail(10)
dataframe46_18.head(10)

dataframe46_18=dataframe46_18.sort_values(by='date')
dataframe46_18=dataframe46_18.set_index('date')

dataframe46_18.to_csv('epurmrbdaily46_18.csv')


###generate daily index

###generate daily index 
dataframe=pd.read_csv('epurmrbdaily46_18.csv') 
epu_std=dataframe['epu_count'].std()
epu_e_std=dataframe['epu_econ'].std()

dataframe['epu_std']\
=dataframe['epu_count']/epu_std

dataframe['epu_e_std']\
=dataframe['epu_econ']/epu_e_std

epu_mean=dataframe['epu_std'].mean()
epu_e_mean=dataframe['epu_e_std'].mean()


dataframe['epu_normalized']\
=dataframe['epu_std']/epu_mean*100

dataframe['epu_e_normalized']\
=dataframe['epu_e_std']/epu_e_mean*100

dataframe.to_csv('epurmrbdaily46_18_n.csv')

###to get quarter data
dataframe=pd.read_csv('epurmrbdaily00_18_n.csv')

dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']

data_quarter.to_csv('epurmrbquarter00_18_n.csv', index=False)

###to get Modern monthly data
dataframe=pd.read_csv('epurmrbdaily00_18_n.csv')

dataframe['month']=pd.to_datetime(dataframe['date']).dt.month
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_month=dataframe.groupby(['year','month']).sum().reset_index()
data_month.head(10)

data_month['epu_count']=data_month['epu']/data_month['count']
data_month['epu_econ']=data_month['epu']/data_month['e']

data_month.columns

std3=data_month['epu_count'].std()
std3_e=data_month['epu_econ'].std()

data_month['epu_month_std']=data_month['epu_count']/std3
data_month['epu_month_e_std']=data_month['epu_econ']/std3_e

mean3=data_month['epu_month_std'].mean()
mean3_e=data_month['epu_month_e_std'].mean()

data_month['epu_month_normalized']=data_month['epu_month_std']*100/mean3
data_month['epu_month_e_normalized']=data_month['epu_month_e_std']*100/mean3_e
data_month.columns
del data_month['epu_month_std']
del data_month['epu_month_e_std']

data_month.to_csv('epurmrbmonth00_18_n.csv', index=False)

###to get Full monthly data
dataframe=pd.read_csv('epurmrbdaily46_18_n.csv')

dataframe['month']=pd.to_datetime(dataframe['date']).dt.month
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_month=dataframe.groupby(['year','month']).sum().reset_index()
data_month.head(10)

data_month['epu_count']=data_month['epu']/data_month['count']
data_month['epu_econ']=data_month['epu']/data_month['e']

data_month.columns

std3=data_month['epu_count'].std()
std3_e=data_month['epu_econ'].std()

data_month['epu_month_std']=data_month['epu_count']/std3
data_month['epu_month_e_std']=data_month['epu_econ']/std3_e

mean3=data_month['epu_month_std'].mean()
mean3_e=data_month['epu_month_e_std'].mean()

data_month['epu_month_normalized']=data_month['epu_month_std']*100/mean3
data_month['epu_month_e_normalized']=data_month['epu_month_e_std']*100/mean3_e
data_month.columns
del data_month['epu_month_std']
del data_month['epu_month_e_std']

data_month.to_csv('epurmrbmonth46_18_n.csv', index=False)

#################################################################################    
##combine all the rmrb TPU csv files
import os    
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu181025'
###注意要重新写了，因为多加了csv在同一个folder下
csvfiles=os.listdir(path)
csvfiles=[f for f in csvfiles if f.endswith('.csv')]

csvfiles1=csvfiles[:61]
os.chdir(path)

import pandas as pd


dataframe=pd.DataFrame()
for i in csvfiles1:
    csvf=pd.read_csv(i)
    dataframe=dataframe.append(csvf, sort=False)
    
dataframe.count
dataframe.head(10)
import datetime
dataframe.to_csv('pre_date1946_2006.csv', index=False)
dataframe=pd.read_csv('pre_date1946_2006.csv')
dataframe.head(10)

date0=dataframe['date'].tolist()
date1=[datetime.datetime.strptime(f,'%m/%d/%Y') for f in date0]
date2=[f.strftime('%Y-%m-%d') for f in date1]
dataframe['date']=date2
dataframe=dataframe.set_index('date')
dataframe.head(10)

##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(1946, 5, 15)  # start date
d2 = datetime.datetime(2006, 12, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame.head(10)
date_frame.count


###
epudaily_1946_2006=pd.concat([dataframe, date_frame], axis=1,sort=False)
epudaily_1946_2006=epudaily_1946_2006.sort_values(by = 'date')
epudaily_1946_2006.tail(10)
epudaily_1946_2006=epudaily_1946_2006.set_index('date')
epudaily_1946_2006.to_csv('1946_2006.csv')    

################################################################################
##combine 2007-2016
csvfiles2=csvfiles[61:-2]
dataframe07_16=pd.DataFrame()
for i in csvfiles2:
    csvf=pd.read_csv(i)
    dataframe07_16=dataframe07_16.append(csvf, sort=False)
    
dataframe07_16.head(10)
dataframe07_16.columns
dataframe07_16=dataframe07_16.set_index('date')
dataframe07_16.to_csv('2007_2016.csv')    


############################################################################
#combine 2017-2018
csvfiles3=csvfiles[-2:]
dataframe17_18=pd.DataFrame()
for i in csvfiles3:
    csvf=pd.read_csv(i)
    dataframe17_18=dataframe17_18.append(csvf, sort=False)
    
    
dataframe17_18.head(10)
import datetime
date0=dataframe17_18['date'].tolist()
date1=[datetime.datetime.strptime(f,'%m/%d/%Y') for f in date0]
date2=[f.strftime('%Y-%m-%d') for f in date1]
dataframe17_18['date']=date2
dataframe17_18=dataframe17_18.set_index('date')
dataframe17_18.to_csv('2017_2018.csv')


##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(2017, 1, 1)  # start date
d2 = datetime.datetime(2018, 10, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame.head(10)
date_frame.count

###
epudaily_1718=pd.concat([dataframe17_18, date_frame], axis=1,sort=False)
epudaily_1718.count
del epudaily_1718['date']
epudaily_1718.to_csv('2017_2018.csv')    

############################
###combine 3 parts
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu181025\all'

filesall=os.listdir(path)
os.chdir(path)
filesall
filesall[:3]

dataframe46_18=pd.DataFrame()
for i in filesall[:3]:
    csvf=pd.read_csv(i)
    dataframe46_18=dataframe46_18.append(csvf, sort=False)
    
dataframe46_18.head(10)

dataframe46_18.tail(10)
dataframe46_18.count

###

dataframe46_18=dataframe46_18.sort_values(by='date')
dataframe46_18=dataframe46_18.set_index('date')

dataframe46_18.to_csv('tpurmrbdaily46_18.csv')


###generate daily index

###generate daily index 
dataframe=pd.read_csv('tpurmrbdaily46_18.csv') 
tpu_std=dataframe['tpu_count'].std()
tpu_e_std=dataframe['tpu_econ'].std()

dataframe['tpu_std']\
=dataframe['tpu_count']/tpu_std

dataframe['tpu_e_std']\
=dataframe['tpu_econ']/tpu_e_std

tpu_mean=dataframe['tpu_std'].mean()
tpu_e_mean=dataframe['tpu_e_std'].mean()


dataframe['tpu_normalized']\
=dataframe['tpu_std']/tpu_mean*100

dataframe['tpu_e_normalized']\
=dataframe['tpu_e_std']/tpu_e_mean*100

dataframe.to_csv('tpurmrbdaily46_18_n.csv')

###to get quarter data
dataframe=pd.read_csv('tpurmrbdaily00_18_n.csv')

dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

data_quarter['tpu_count']=data_quarter['tpu']/data_quarter['count']
data_quarter['tpu_econ']=data_quarter['tpu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['tpu_count'].std()
std3_e=data_quarter['tpu_econ'].std()

data_quarter['tpu_quarter_std']=data_quarter['tpu_count']/std3
data_quarter['tpu_quarter_e_std']=data_quarter['tpu_econ']/std3_e

mean3=data_quarter['tpu_quarter_std'].mean()
mean3_e=data_quarter['tpu_quarter_e_std'].mean()

data_quarter['tpu_quarter_normalized']=data_quarter['tpu_quarter_std']*100/mean3
data_quarter['tpu_quarter_e_normalized']=data_quarter['tpu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['tpu_quarter_std']
del data_quarter['tpu_quarter_e_std']

data_quarter.to_csv('tpurmrbquarter00_18.csv', index=False)

###to get monthly data
dataframe=pd.read_csv('tpurmrbdaily00_18_n.csv')

dataframe['month']=pd.to_datetime(dataframe['date']).dt.month
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_month=dataframe.groupby(['year','month']).sum().reset_index()
data_month.head(10)

data_month['tpu_count']=data_month['tpu']/data_month['count']
data_month['tpu_econ']=data_month['tpu']/data_month['e']

data_month.columns

std3=data_month['tpu_count'].std()
std3_e=data_month['tpu_econ'].std()

data_month['tpu_month_std']=data_month['tpu_count']/std3
data_month['tpu_month_e_std']=data_month['tpu_econ']/std3_e

mean3=data_month['tpu_month_std'].mean()
mean3_e=data_month['tpu_month_e_std'].mean()

data_month['tpu_month_normalized']=data_month['tpu_month_std']*100/mean3
data_month['tpu_month_e_normalized']=data_month['tpu_month_e_std']*100/mean3_e
data_month.columns
del data_month['tpu_month_std']
del data_month['tpu_month_e_std']

data_month.to_csv('tpurmrbmonth00_18.csv', index=False)

###########################################################################
####combine gmrb epu
import os
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\epu'
os.chdir(path)
csvfiles=os.listdir(path)

import pandas as pd
dataframe=pd.DataFrame()
for i in csvfiles:
    csvf=pd.read_csv(i)
    dataframe=dataframe.append(csvf, sort=False)

dataframe.head(10)
dataframe['date']=dataframe['date.1']

del dataframe['date.1']
dataframe.set_index('date', inplace=True)

epu_std=dataframe['epu_count'].std()
epu_e_std=dataframe['epu_econ'].std()

dataframe['epu_std']\
=dataframe['epu_count']/epu_std

dataframe['epu_e_std']\
=dataframe['epu_econ']/epu_e_std

epu_mean=dataframe['epu_std'].mean()
epu_e_mean=dataframe['epu_e_std'].mean()


dataframe['epu_normalized']\
=dataframe['epu_std']/epu_mean*100

dataframe['epu_e_normalized']\
=dataframe['epu_e_std']/epu_e_mean*100

dataframe.to_csv('epugmrbdaily08_17_n.csv')

###to get quarter data
dataframe=pd.read_csv('epugmrbdaily08_17_n.csv')
dataframe.head(10)
dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']
del data_quarter['epu_std']
del data_quarter['epu_e_std']
del data_quarter['epu_normalized']
del data_quarter['epu_e_normalized']
data_quarter.head(10)
data_quarter.to_csv('epugmrbquarter08_17.csv', index=False)

###to get monthly data
dataframe=pd.read_csv('epugmrbdaily08_17_n.csv')

dataframe['month']=pd.to_datetime(dataframe['date']).dt.month
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_month=dataframe.groupby(['year','month']).sum().reset_index()
data_month.head(10)

data_month['epu_count']=data_month['epu']/data_month['count']
data_month['epu_econ']=data_month['epu']/data_month['e']

std3=data_month['epu_count'].std()
std3_e=data_month['epu_econ'].std()

data_month['epu_month_std']=data_month['epu_count']/std3
data_month['epu_month_e_std']=data_month['epu_econ']/std3_e

mean3=data_month['epu_month_std'].mean()
mean3_e=data_month['epu_month_e_std'].mean()

data_month['epu_month_normalized']=data_month['epu_month_std']*100/mean3
data_month['epu_month_e_normalized']=data_month['epu_month_e_std']*100/mean3_e
data_month.columns
del data_month['epu_month_std']
del data_month['epu_month_e_std']
del data_month['epu_normalized']
del data_month['epu_e_normalized']
del data_month['epu_std']
del data_month['epu_e_std']


data_month.to_csv('epugmrbmonth08_17.csv', index=False)


###########################################################################
####combine gmrb tpu
import os
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\tpu'
os.chdir(path)
csvfiles=os.listdir(path)

import pandas as pd
dataframe=pd.DataFrame()
for i in csvfiles:
    csvf=pd.read_csv(i)
    dataframe=dataframe.append(csvf, sort=False)

dataframe.head(10)
dataframe['date']=dataframe['date.1']

del dataframe['date.1']
dataframe.set_index('date', inplace=True)

tpu_std=dataframe['tpu_count'].std()
tpu_e_std=dataframe['tpu_econ'].std()

dataframe['tpu_std']\
=dataframe['tpu_count']/tpu_std

dataframe['tpu_e_std']\
=dataframe['tpu_econ']/tpu_e_std

tpu_mean=dataframe['tpu_std'].mean()
tpu_e_mean=dataframe['tpu_e_std'].mean()

dataframe['tpu_normalized']\
=dataframe['tpu_std']/tpu_mean*100

dataframe['tpu_e_normalized']\
=dataframe['tpu_e_std']/tpu_e_mean*100

dataframe.to_csv('tpugmrbdaily08_17_n.csv')

###to get quarter data
dataframe=pd.read_csv('tpugmrbdaily08_17_n.csv')
dataframe.head(10)
dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

data_quarter['tpu_count']=data_quarter['tpu']/data_quarter['count']
data_quarter['tpu_econ']=data_quarter['tpu']/data_quarter['e']

std3=data_quarter['tpu_count'].std()
std3_e=data_quarter['tpu_econ'].std()

data_quarter['tpu_quarter_std']=data_quarter['tpu_count']/std3
data_quarter['tpu_quarter_e_std']=data_quarter['tpu_econ']/std3_e

mean3=data_quarter['tpu_quarter_std'].mean()
mean3_e=data_quarter['tpu_quarter_e_std'].mean()

data_quarter['tpu_quarter_normalized']=data_quarter['tpu_quarter_std']*100/mean3
data_quarter['tpu_quarter_e_normalized']=data_quarter['tpu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['tpu_quarter_std']
del data_quarter['tpu_quarter_e_std']
del data_quarter['tpu_std']
del data_quarter['tpu_e_std']
del data_quarter['tpu_normalized']
del data_quarter['tpu_e_normalized']
data_quarter.head(10)
data_quarter.to_csv('tpugmrbquarter08_17.csv', index=False)

###to get monthly data
dataframe=pd.read_csv('tpugmrbdaily08_17_n.csv')

dataframe['month']=pd.to_datetime(dataframe['date']).dt.month
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_month=dataframe.groupby(['year','month']).sum().reset_index()
data_month.head(10)

data_month['tpu_count']=data_month['tpu']/data_month['count']
data_month['tpu_econ']=data_month['tpu']/data_month['e']

std3=data_month['tpu_count'].std()
std3_e=data_month['tpu_econ'].std()

data_month['tpu_month_std']=data_month['tpu_count']/std3
data_month['tpu_month_e_std']=data_month['tpu_econ']/std3_e

mean3=data_month['tpu_month_std'].mean()
mean3_e=data_month['tpu_month_e_std'].mean()

data_month['tpu_month_normalized']=data_month['tpu_month_std']*100/mean3
data_month['tpu_month_e_normalized']=data_month['tpu_month_e_std']*100/mean3_e
data_month.columns
del data_month['tpu_month_std']
del data_month['tpu_month_e_std']
del data_month['tpu_normalized']
del data_month['tpu_e_normalized']
del data_month['tpu_std']
del data_month['tpu_e_std']


data_month.to_csv('tpugmrbmonth08_17.csv', index=False)

####MPU 2001-2018 QUARTER
path1 = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_gmrb\mtepu'
os.chdir(path1)

