# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 13:48:05 2018

@author: dingq
"""
import os
import pandas as pd
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_stock market')
a=pd.read_csv('A stock index.csv',encoding='gb2312' )
a.head(10)
a.index
a.columns
b=a['日期']
c=a['前收盘']
lead1=u'本报'.encode('utf8')
stock=pd.concat([b,c],axis=1)
stock=stock.rename(columns={'日期':'date','前收盘':'price'})
stock.head(10)

os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\more uncertainty')

daily=pd.read_csv('epu_daily_normalized2011-2017.csv')
daily.head(10)
d=daily['epu_normalized']
d.colums=['epu_rmrb']
e=daily['date']
daily_rmrb=pd.concat([e,d],axis=1)
daily_rmrb.head(10)

reg=pd.merge(stock,daily_rmrb,on='date')
reg.head(10)

reg.to_csv('reg.csv')


import statsmodels.formula.api as smf

results = smf.ols('price', ~ 'epu_normalized', data=reg).fit()
print(results.summary())

