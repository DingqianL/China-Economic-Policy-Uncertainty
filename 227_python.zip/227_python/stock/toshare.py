# -*- coding: utf-8 -*-
"""
Created on Wed Apr 04 20:49:02 2018

@author: dingq
"""

# install tushare
!pip install tushare

#upgrage tushare
!pip install tushare --upgrade

#upgrade pip
!python -m pip install --upgrade pip


import tushare as ts

ts.get_hist_data('600848', ktype='W') #获取周k线数据
ts.get_hist_data('600848', ktype='M') #获取月k线数据
ts.get_hist_data('600848', ktype='5') #获取5分钟k线数据
ts.get_hist_data('600848', ktype='15') #获取15分钟k线数据
ts.get_hist_data('600848', ktype='30') #获取30分钟k线数据
ts.get_hist_data('600848', ktype='60') #获取60分钟k线数据

#获取上证指数k线数据，其它参数与个股一致，下同
sh=ts.get_hist_data('sh', ktype='30')
sz=ts.get_hist_data('sz', ktype='30') #获取深圳成指k线数据
hs300=ts.get_hist_data('hs300', ktype='30') #获取沪深300指数k线数据
sz50=ts.get_hist_data('sz50', ktype='30') #获取上证50指数k线数据
zxb=ts.get_hist_data('zxb', ktype='30') #获取中小板指数k线数据
cyb=ts.get_hist_data('cyb', ktype='30') #获取创业板指数k线数据

os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\stockmarket')
sh.to_csv('sh.csv')
sz.to_csv('sz.csv')
hs300.to_csv('hs300.csv')
sz50.to_csv('sz50.csv')
zxb.to_csv('zxb.csv')
cyb.to_csv('cyb.csv')



