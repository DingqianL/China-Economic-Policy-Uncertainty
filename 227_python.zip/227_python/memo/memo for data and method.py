# -*- coding: utf-8 -*-
"""
Created on Sat Apr 07 20:34:34 2018

@author: dingq
"""

## This script is written for the memo to prof davis

import pandas as pd
import os

os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_csv\reduced1946-2003')

##generate normalized daily epu
epudaily46_03 = pd.read_excel('aggregate_epudailty1946_2003.xlsx')

epudaily46_03.head(10)


std=epudaily46_03['epu_count'].std()
epudaily46_03['epu_count_std']=epudaily46_03['epu_count']/std

mean=epudaily46_03['epu_count_std'].mean()

epudaily46_03['epu_daily_normalized']=epudaily46_03['epu_count_std']*100/mean
epudaily46_03.head(10)
del epudaily46_03['epu_count_std']
epudaily46_03.head(10)
epudaily46_03.to_csv('epu_daily_1946_2003_normalized.csv')

epudaily46_03=pd.read_csv('epu_daily_1946_2003_normalized.csv')

###plot result
import matplotlib.pyplot as plt
ts4603=epudaily46_03[['date','epu_daily_normalized']]
ts4603=ts4603[:21050]
ts4603.set_index('date',inplace=True)

plt.figure();
ts4603.plot(kind='bar')
plt.show()

%matplotlib auto
%matplotlib inline

# generate monthly epu for 1946-2003
epudaily46_03 = pd.read_excel('aggregate_epudailty1946_2003.xlsx')
epudaily46_03.head(10)

date_date=epudaily46_03['date'].astype(str)
date_date=date_date.tolist()
type(date_date[0])

import datetime
date_time=[]
for i in date_date:
    datetime0=datetime.datetime.strptime(i,'%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y-%m')
    month_time.append(month_time0)

len(month_time)

epudaily46_03['month']=month_time
epudaily46_03.head(10)

df_month=epudaily46_03.groupby('month').sum().reset_index()
df_month.head()
df_month['epu_month']=df_month['epu']/df_month['count']

df_month.head(n=10)

df_month.describe()
std=df_month['epu_month'].std()
df_month['epu_month_std']=df_month['epu_month']/std

mean=df_month['epu_month_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean
df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('data_month_1946_2003.csv')
















