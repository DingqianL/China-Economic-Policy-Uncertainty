# -*- coding: utf-8 -*-
"""
Created on Sun Apr 08 11:04:04 2018

@author: dingq
"""


##goal: download daily return and calculate monthly realized volatility based on it

import tushare as ts

ts.get_hist_data('600848', ktype='W') #获取周k线数据
ts.get_hist_data('600848', ktype='M') #获取月k线数据
ts.get_hist_data('600848', ktype='5') #获取5分钟k线数据
ts.get_hist_data('600848', ktype='15') #获取15分钟k线数据
ts.get_hist_data('600848', ktype='30') #获取30分钟k线数据
ts.get_hist_data('600848', ktype='60') #获取60分钟k线数据

#获取上证指数k线数据，其它参数与个股一致，下同
sh=ts.get_hist_data('sh', ktype='M',start='2011-01-01',end='2017-12-31') #获取上证综指
sz=ts.get_hist_data('sz', ktype='D',start='1991-01-01',end='2017-12-31') #获取深圳成指k线数据
hs300=ts.get_hist_data('hs300', ktype='D',start='1991-01-01',end='2017-12-31') #获取沪深300指数k线数据
Astock=ts.get_hist_data('000002', ktype='D',start='1991-01-01',end='2017-12-31') #A股指数
Bstock=ts.get_hist_data('000003', ktype='D',start='1991-01-01',end='2017-12-31') #B股指数

import os
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\stockmarket')
sh.to_csv('sh.csv')
sz.to_csv('sz.csv')
hs300.to_csv('hs300.csv')



