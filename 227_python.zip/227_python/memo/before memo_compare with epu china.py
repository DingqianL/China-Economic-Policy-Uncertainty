# -*- coding: utf-8 -*-
"""
Created on Sat Apr 07 22:23:55 2018

@author: dingq
"""

# I wrote this script to
import pandas as pd
data1946_2003=pd.read_csv('C:\\Users\\dingq\\Documents\\200-academic\\220-Academic-My dissertation\\data_csv\\aggregate_epudailty1946_2003_2011_2017.csv')
data1946_2003.head(10) 

data1946_2003[17763:17764]
data1946_2003.loc[[17763]]
data1995_2003=data1946_2003[17763:]
data1995_2003=data1995_2003.reset_index(drop=True)
data1995_2003[3286:3287]  
data1995_2003=data1995_2003[:3287]
data1995_2003.tail(5)
os.chdir('C:\\Users\\dingq\\Documents\\200-academic\\220-Academic-My dissertation\\data_csv')
data1995_2003.to_csv('data1995_2003.csv')


data1946_2003.columns


#delete the part that I do not want
del data1946_2003[u'Unnamed: 0']
date_date=data1995_2003['date']

date_date=date_date.tolist()

import datetime
date_time=[]
for i in date_date:
    datetime0=datetime.datetime.strptime(i,'%m/%d/%Y')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y-%m')
    month_time.append(month_time0)

len(month_time)

data1995_2003['month']=month_time
data1995_2003.head(10)

df_month=data1995_2003.groupby('month').sum().reset_index()
df_month.head()
df_month['epu_month']=df_month['epu']/df_month['count']

df_month.head(n=10)

df_month.describe()
std=df_month['epu_month'].std()
df_month['epu_month_std']=df_month['epu_month']/std

mean=df_month['epu_month_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean
df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('data_month_1995_2003.csv')

