# -*- coding: utf-8 -*-
"""
Created on Mon May 07 20:47:20 2018

@author: dingq
"""

import os
import re

aa=2017

lead1=u'本报'
lead2=u'新华社'

uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy1=u'财政'
policy2=u'货币'
policy3=u'证监会'
policy4=u'银监会'
policy5=u'财政部'
policy6=u'人民银行'
policy7=u'国家发改委'
policy8=u'开放'
policy9=u'改革'
policy10=u'商务部'
policy11=u'法律'
policy12=u'法规'
policy13=u'税收'
policy14=u'财政赤字'
policy15=u'国债'
policy16=u'政府债务'
policy17=u'央行'
policy18=u'外经贸部'
policy19=u'关税'

tpolicy1=u'进口关税'
tpolicy2=u'进口税'
tpolicy3=u'进口壁垒'
tpolicy4=u'WTO'
tpolicy5=u'世界贸易组织'
tpolicy6=u'世贸组织'
tpolicy7=u'贸易条约'
tpolicy8=u'贸易协定'
tpolicy9=u'贸易政策'
tpolicy10=u'贸易法'
tpolicy11=u'多哈回合'
tpolicy12=u'乌拉圭回合'
tpolicy13=u'GATT'
tpolicy14=u'关贸总协定'
tpolicy15=u'倾销'
tpolicy16=u'保护主义'
tpolicy17=u'贸易壁垒'
tpolicy18=u'出口补贴'




pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp10 =re.compile(policy10)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)

tp1 =re.compile(tpolicy1)
tp2 =re.compile(tpolicy2)
tp3 =re.compile(tpolicy3)
tp4 =re.compile(tpolicy4)
tp5 =re.compile(tpolicy5)
tp6 =re.compile(tpolicy6)
tp7 =re.compile(tpolicy7)
tp8 =re.compile(tpolicy8)
tp9 =re.compile(tpolicy9)
tp10 =re.compile(tpolicy10)
tp11 =re.compile(tpolicy11)
tp12 =re.compile(tpolicy12)
tp13 =re.compile(tpolicy13)
tp14 =re.compile(tpolicy14)
tp15 =re.compile(tpolicy15)
tp16 =re.compile(tpolicy16)
tp17 =re.compile(tpolicy17)
tp18 =re.compile(tpolicy18)



article=[]
u1=[]
u2=[]
u3=[]
u4=[]
u5=[]
u6=[]
u7=[]
u8=[]
u9=[]
u10=[]

e1=[]
e2=[]

p1 =[]
p2 =[]
p3 =[]
p4 =[]
p5 =[]
p6 =[]
p7 =[]
p8 =[]
p9 =[]
p10=[]
p11 =[]
p12 =[]
p13 =[]
p14 =[]
p15 =[]
p16 =[]
p17 =[]
p18 =[]
p19 =[]


t1 =[]
t2 =[]
t3 =[]
t4 =[]
t5 =[]
t6 =[]
t7 =[]
t8 =[]
t9 =[]
t10=[]
t11 =[]
t12 =[]
t13 =[]
t14 =[]
t15 =[]
t16 =[]
t17 =[]
t18 =[]

dire1=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete'+'\\'+str(aa)
os.chdir(dire1)
path=os.listdir(dire1)
path[0]
len(path)
path=[f for f in path if f.endswith('.txt')]

articles_data=[]
for m in path:
    with open(m,'r+',encoding='utf8', errors='ignore') as f:
        read_data=f.read()
        read_data=read_data.replace(' ', '')
        read_data=read_data.replace('\n','')
        slot1=read_data.split(lead1)
        slot2=[]
    for j in slot1:
        slot=j.split(lead2)
        slot2.extend(slot)
        
    n=0
    while n<len(slot2):
        if len(slot2[n])<20:
            slot2.pop(n)
            n-=1
        n+=1
    article=article+list(range(len(slot2)))
    articles_data.extend(slot2)

    for i in slot2:
        result=len(pu1.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u1.append(uu)
        
    for i in slot2:
        result=len(pu2.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u2.append(uu)
        
    for i in slot2:
        result=len(pu3.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u3.append(uu)

    for i in slot2:
        result=len(pu4.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u4.append(uu)
        
    for i in slot2:
        result=len(pu5.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u5.append(uu)
        
    for i in slot2:
        result=len(pu6.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u6.append(uu)
    
    for i in slot2:
        result=len(pu7.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u7.append(uu)
    
    for i in slot2:
        result=len(pu8.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u8.append(uu)
    
    for i in slot2:
        result=len(pu9.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u9.append(uu)
    
    for i in slot2:
        result=len(pu10.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u10.append(uu)
                
    for i in slot2:
        result=len(pe1.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e1.append(ee)
                
    for i in slot2:
        result=len(pe2.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e2.append(ee)
                
    for i in slot2:
        result=len(pp1.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p1.append(pp)
        
    for i in slot2:
        result=len(pp2.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p2.append(pp)
                
    for i in slot2:
        result=len(pp3.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p3.append(pp)
                
    for i in slot2:
        result=len(pp4.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p4.append(pp)
                
    for i in slot2:
        result=len(pp5.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p5.append(pp)
        
    for i in slot2:
        result=len(pp6.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p6.append(pp)
                
    for i in slot2:
        result=len(pp7.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p7.append(pp)
        
    for i in slot2:
        result=len(pp8.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p8.append(pp)
        
    for i in slot2:
        result=len(pp9.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p9.append(pp)
        
    for i in slot2:
        result=len(pp10.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p10.append(pp)
        
    for i in slot2:
        result=len(pp11.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p11.append(pp)
        
    for i in slot2:
        result=len(pp12.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p12.append(pp)
        
    for i in slot2:
        result=len(pp13.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p13.append(pp)
        
    for i in slot2:
        result=len(pp14.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p14.append(pp)
        
    for i in slot2:
        result=len(pp15.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p15.append(pp)
        
    for i in slot2:
        result=len(pp16.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p16.append(pp)
        
    for i in slot2:
        result=len(pp17.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p17.append(pp)
        
    for i in slot2:
        result=len(pp18.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p18.append(pp)
        
    for i in slot2:
        result=len(pp19.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p19.append(pp)
    
        

import datetime

bb=aa-1
start=datetime.date(bb,12,31)
date=[]
i=0
while i<len(article):
    if i<len(article)-1:
        if article[i-1]<article[i]:
            time=str(start)
            date.append(time)
            i+=1
        else:
            start=start+datetime.timedelta(days=1)
            time=str(start)
            date.append(time)
            i+=1
    else:
        date.append(time)
        i+=1
    
len(article)
len(date)

u=[]
e=[]
p=[]

for i in range(len(article)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(article)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(article)):        
    if p1[i]>0 or \
       p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p10[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0 or \
       p16[i]>0 or \
       p17[i]>0 or \
       p18[i]>0 or \
       p19[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(u)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 

if len(e)==len(p)==len(u)==len(epu)==len(article)==len(date):
    print('Pass')
else:
    print('Alert')

import pandas as pd
articlelist=pd.DataFrame()
articlelist['date']=date
articlelist['article']=articles_data
articlelist['e']=e
articlelist['p']=p
articlelist['u']=u
articlelist['epu']=epu
#save data into dataframe:
articlelist['不确定']=u1
articlelist['不明确']=u2
articlelist['不明朗']=u3
articlelist['未明']=u4
articlelist['难料']=u5
articlelist['难以预计']=u6
articlelist['难以估计']=u7
articlelist['难以预测']=u8
articlelist['难以预料']=u9
articlelist['未知']=u10

articlelist['经济']=e1
articlelist['商业']=e2

articlelist['财政']=p1
articlelist['货币']=p2
articlelist['证监会']=p3
articlelist['银监会']=p4
articlelist['财政部']=p5
articlelist['人民银行']=p6
articlelist['国家发改委']=p7
articlelist['开放']=p8
articlelist['改革']=p9
articlelist['商务部']=p10
articlelist['法律']=p11
articlelist['法规']=p12
articlelist['税收']=p13
articlelist['财政赤字']=p14
articlelist['国债']=p15
articlelist['政府债务']=p16
articlelist['央行']=p17
articlelist['外经贸部']=p18
articlelist['关税']=p19


path11=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
path22=path11+'\\'+'all_epu'+str(aa)+'.xlsx'

articlelist.to_excel(path22,encoding='utf8')

data2007={'count':article,'e':e,'p':p,'u':u,'epu':epu,'date':date}
epu2007=pd.DataFrame(data=data2007,index=date)

cc=epu2007.groupby('date').sum().reset_index()
bb=epu2007.groupby('date').max().reset_index()
date_sort=bb['date']
article_sort=bb['count']
epu_sort=cc['epu']
e_sort=cc['e']
p_sort=cc['p']
u_sort=cc['u']

epu2007_sorted=pd.concat([date_sort,epu_sort,article_sort,e_sort,p_sort,u_sort],axis=1)
epu2007_sorted['epu_count']=epu2007_sorted['epu']/epu2007_sorted['count']
epu2007_sorted['epu_econ']=epu2007_sorted['epu']/epu2007_sorted['e']

epu2007_sorted.head(10)

epu2007_sorted.set_index('date',inplace=True)
epu2007_sorted.to_csv(path11+'\\'+'epudaily'+str(aa)+'.csv',encoding='utf-8')

