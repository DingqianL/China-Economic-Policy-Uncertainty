# -*- coding: utf-8 -*-
"""
Created on Sun Jul 29 10:17:05 2018

@author: dingq
"""


import os
import pandas as pd
import shutil

#for supplement files, combine them together
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\supplement\1963'
os.chdir(path)


list=os.listdir(path)         
            
all_txt=''
for i in list:
    with open(i,'r',errors='ignore') as f:
        txt=f.read()
        all_txt=all_txt+str(txt)
with open('1963_sup.txt','w') as f:
    f.write(all_txt)

#combine csv files
dire=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete'
folder1=os.listdir(dire)
del folder1[-2:]
folder1=folder1[-11:]
del folder1[-15:]


newpath=dire+'\\'+'tpu'
os.chdir(newpath)
os.makedirs(newpath)
#fullcsv=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\full.csv'
##把所有的csv文件都放在一个文件夹下
for i in folder1:
    dire1=dire+"\\"+i
    folder2=os.listdir(dire1)
    csvfiles=[f for f in folder2 if f.endswith(".csv")]
    csvfile=csvfiles[0]
    csvdire=dire1+"\\"+csvfile
    shutil.copy(csvdire, newpath)
    #content=pd.read_csv(csvdire)
    
    #with open(fullcsv,'a+') as f:
        #content.to_csv(f, header=False)
                    
#合并1992-2007的为一个csv
thepath=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu'
filecsvs=os.listdir(thepath)       
del filecsvs[0]
len(filecsvs)

filecsvs.index('r_epudaily1978_e.csv')

filecsv1=filecsvs[32:] #get the list of 1978-2018
filecsv2=[x for x in filecsvs if x not in filecsv1] #get the list of 1946-1977
filecsvs=filecsv1+filecsv2


newpath2=thepath+'\\'+'TPU'
os.makedirs(newpath2)
os.chdir(newpath2)

#append all the data in a dataframe
dataframe=pd.DataFrame()

for i in filecsvs:
    direfile=thepath+'\\'+i
    data=pd.read_csv(direfile)
    #if len(data.columns)>7:
        #print(i)
    dataframe=dataframe.append(data, sort=False)

dataframe.columns
#del dataframe['Unnamed: 6']
dataframe.to_csv('daily_tpu1978_2018.csv', index=False)

dataframe=pd.DataFrame()

for i in filecsvs:
    direfile=thepath+'\\'+i
    data=pd.read_csv(direfile)
    #if len(data.columns)>7:
        #print(i)
    dataframe=dataframe.append(data, sort=False)

dataframe.columns
dataframe.to_csv('daily1946_1977.csv', index=False)

##merge the two parts
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1978_2018')
data1=pd.read_csv('daily1978_2018.csv')
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1946_1977')
data2=pd.read_csv('daily1946_1977.csv')
dataframe=data2.append(data1, sort=False)
dataframe.head(5)
###generate daily index 
epu_std=dataframe['epu_count'].std()
epu_e_std=dataframe['epu_econ'].std()

dataframe['epu_std']\
=dataframe['epu_count']/epu_std

dataframe['epu_e_std']\
=dataframe['epu_econ']/epu_e_std

epu_mean=dataframe['epu_std'].mean()
epu_e_mean=dataframe['epu_e_std'].mean()


dataframe['epu_normalized']\
=dataframe['epu_std']/epu_mean*100

dataframe['epu_e_normalized']\
=dataframe['epu_e_std']/epu_e_mean*100

dataframe.columns
del dataframe['epu_std']
del dataframe['epu_e_std']
del dataframe['p']
del dataframe['u']

os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\all')
dataframe.to_csv('1978_2018_tpudaily.csv', index=False)
dataframe=pd.read_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1992_2017\1992_2017daily_mo.csv')

## to get weekly data
dataframe['week']=pd.to_datetime(dataframe['date']).dt.week
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_week=dataframe.groupby(['year','week']).sum().reset_index()

data_week['epu_count']=data_week['epu']/data_week['count']
data_week['epu_econ']=data_week['epu']/data_week['e']

data_week.columns
del data_week['epu_normalized']
del data_week['epu_e_normalized']
del data_week['epu_std']
del data_week['epu_e_std']

std3=data_week['epu_count'].std()
std3_e=data_week['epu_econ'].std()

data_week['epu_week_std']=data_week['epu_count']/std3
data_week['epu_week_e_std']=data_week['epu_econ']/std3_e

mean3=data_week['epu_week_std'].mean()
mean3_e=data_week['epu_week_e_std'].mean()

data_week['epu_week_normalized']=data_week['epu_week_std']*100/mean3
data_week['epu_week_e_normalized']=data_week['epu_week_e_std']*100/mean3_e

data_week.columns
del data_week['epu_week_std']
del data_week['epu_week_e_std']

data_week.to_csv('1946_2018_tpuweekly.csv', index=False)


##to get quarter data
dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

del data_quarter['epu_std']
del data_quarter['epu_e_std']

del data_quarter['epu_normalized']
del data_quarter['epu_e_normalized']
del data_quarter['week']


data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']

data_quarter.to_csv('1946_2018_tpuquarterly.csv', index=False)

####to get monthly data
##to get quarter data
dataframe['quarter']=pd.to_datetime(dataframe['date']).dt.quarter
dataframe['year']=pd.to_datetime(dataframe['date']).dt.year
data_quarter=dataframe.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

del data_quarter['epu_std']
del data_quarter['epu_e_std']

del data_quarter['epu_normalized']
del data_quarter['epu_e_normalized']
del data_quarter['week']


data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']

data_quarter.to_csv('1946_2018_tpuquarterly.csv', index=False)


#and monthly index
dataframe=pd.read_csv(r'1946_2018daily.csv')
date_date=dataframe['date']
date_date=date_date.tolist()


import datetime
date_time=[]
for i in date_date:
    i=str(i)
    try:
        datetime0=datetime.datetime.strptime(i,'%m/%d/%Y')
    except ValueError:
        datetime0=datetime.datetime.strptime(i, '%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y/%m')
    month_time.append(month_time0)

len(month_time)

dataframe['month']=month_time

dataframe['month']

df_month=dataframe.groupby('month').sum().reset_index()
df_month.columns
df_month=df_month[['month','epu','e','count']]


df_month['epu_count']=df_month['epu']/df_month['count']
df_month['epu_econ']=df_month['epu']/df_month['e']

df_month.head(n=10)

df_month.columns

std2=df_month['epu_count'].std()
std2_e=df_month['epu_econ'].std()

df_month['epu_month_std']=df_month['epu_count']/std2
df_month['epu_month_e_std']=df_month['epu_econ']/std2_e

mean2=df_month['epu_month_std'].mean()
mean2_e=df_month['epu_month_e_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month['epu_month_e_normalized']=df_month['epu_month_e_std']*100/mean2_e

df_month.columns
del df_month['epu_month_std']
del df_month['epu_month_e_std']
df_month.head(10)
df_month.to_csv(r'1946_2018_tpumonthly.csv')

'''####################
Generate Historical EPU
'''
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1946_1977')
his1946_1977=pd.read_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1946_1977\daily1946_1977.csv')
his1946_1977.columns

###generate daily index 
epu_std=his1946_1977['epu_count'].std()
epu_e_std=his1946_1977['epu_econ'].std()

his1946_1977['epu_std']\
=his1946_1977['epu_count']/epu_std

his1946_1977['epu_e_std']\
=his1946_1977['epu_econ']/epu_e_std

epu_mean=his1946_1977['epu_std'].mean()
epu_e_mean=his1946_1977['epu_e_std'].mean()


his1946_1977['epu_normalized']\
=his1946_1977['epu_std']/epu_mean*100

his1946_1977['epu_e_normalized']\
=his1946_1977['epu_e_std']/epu_e_mean*100

his1946_1977.columns
del his1946_1977['epu_std']
del his1946_1977['epu_e_std']

his1946_1977.to_csv('1946_1977daily.csv', index=False)

## to get weekly data
his1946_1977['week']=pd.to_datetime(his1946_1977['date']).dt.week
his1946_1977['year']=pd.to_datetime(his1946_1977['date']).dt.year
data_week=his1946_1977.groupby(['year','week']).sum().reset_index()

data_week['epu_count']=data_week['epu']/data_week['count']
data_week['epu_econ']=data_week['epu']/data_week['e']

data_week.columns
del data_week['epu_normalized']
del data_week['epu_e_normalized']

std3=data_week['epu_count'].std()
std3_e=data_week['epu_econ'].std()

data_week['epu_week_std']=data_week['epu_count']/std3
data_week['epu_week_e_std']=data_week['epu_econ']/std3_e

mean3=data_week['epu_week_std'].mean()
mean3_e=data_week['epu_week_e_std'].mean()

data_week['epu_week_normalized']=data_week['epu_week_std']*100/mean3
data_week['epu_week_e_normalized']=data_week['epu_week_e_std']*100/mean3_e

data_week.columns
del data_week['epu_week_std']
del data_week['epu_week_e_std']

data_week.to_csv('1946_1977weekly.csv', index=False)


##to get quarter data
his1946_1977['quarter']=pd.to_datetime(his1946_1977['date']).dt.quarter
his1946_1977['year']=pd.to_datetime(his1946_1977['date']).dt.year
data_quarter=his1946_1977.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

del data_quarter['epu_normalized']
del data_quarter['epu_e_normalized']
del data_quarter['week']


data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']

data_quarter.to_csv('1946_1977quarterly.csv', index=False)



#and monthly index
date_date=his1946_1977['date']
date_date=date_date.tolist()


import datetime
date_time=[]
for i in date_date:
    i=str(i)
    try:
        datetime0=datetime.datetime.strptime(i,'%m/%d/%Y')
    except ValueError:
        datetime0=datetime.datetime.strptime(i, '%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y/%m')
    month_time.append(month_time0)

len(month_time)

his1946_1977['month']=month_time


df_month=his1946_1977.groupby('month').sum().reset_index()
df_month.columns
df_month=df_month[['month','epu','e','count']]


df_month['epu_count']=df_month['epu']/df_month['count']
df_month['epu_econ']=df_month['epu']/df_month['e']

df_month.head(n=10)

df_month.columns

std2=df_month['epu_count'].std()
std2_e=df_month['epu_econ'].std()

df_month['epu_month_std']=df_month['epu_count']/std2
df_month['epu_month_e_std']=df_month['epu_econ']/std2_e

mean2=df_month['epu_month_std'].mean()
mean2_e=df_month['epu_month_e_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month['epu_month_e_normalized']=df_month['epu_month_e_std']*100/mean2_e

df_month.columns
del df_month['epu_month_std']
del df_month['epu_month_e_std']
df_month.head(10)
df_month.to_csv(r'1946_1977monthly.csv')




'''####################
Generate Modern EPU
'''
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\daily1978_2018')
modern1978_2018=pd.read_csv('daily1978_2018.csv')
modern1978_2018.columns

###generate daily index 
epu_std=modern1978_2018['epu_count'].std()
epu_e_std=modern1978_2018['epu_econ'].std()

modern1978_2018['epu_std']\
=modern1978_2018['epu_count']/epu_std

modern1978_2018['epu_e_std']\
=modern1978_2018['epu_econ']/epu_e_std

epu_mean=modern1978_2018['epu_std'].mean()
epu_e_mean=modern1978_2018['epu_e_std'].mean()


modern1978_2018['epu_normalized']\
=modern1978_2018['epu_std']/epu_mean*100

modern1978_2018['epu_e_normalized']\
=modern1978_2018['epu_e_std']/epu_e_mean*100

modern1978_2018.columns
del modern1978_2018['epu_std']
del modern1978_2018['epu_e_std']

modern1978_2018.to_csv('1978_2018daily.csv', index=False)

## to get weekly data
modern1978_2018['week']=pd.to_datetime(modern1978_2018['date']).dt.week
modern1978_2018['year']=pd.to_datetime(modern1978_2018['date']).dt.year
data_week=modern1978_2018.groupby(['year','week']).sum().reset_index()

data_week['epu_count']=data_week['epu']/data_week['count']
data_week['epu_econ']=data_week['epu']/data_week['e']

data_week.columns
del data_week['epu_normalized']
del data_week['epu_e_normalized']

std3=data_week['epu_count'].std()
std3_e=data_week['epu_econ'].std()

data_week['epu_week_std']=data_week['epu_count']/std3
data_week['epu_week_e_std']=data_week['epu_econ']/std3_e

mean3=data_week['epu_week_std'].mean()
mean3_e=data_week['epu_week_e_std'].mean()

data_week['epu_week_normalized']=data_week['epu_week_std']*100/mean3
data_week['epu_week_e_normalized']=data_week['epu_week_e_std']*100/mean3_e

data_week.columns
del data_week['epu_week_std']
del data_week['epu_week_e_std']

data_week.to_csv('1978_2018weekly.csv', index=False)


##to get quarter data
modern1978_2018['quarter']=pd.to_datetime(modern1978_2018['date']).dt.quarter
modern1978_2018['year']=pd.to_datetime(modern1978_2018['date']).dt.year
data_quarter=modern1978_2018.groupby(['year','quarter']).sum().reset_index()
data_quarter.columns

del data_quarter['epu_normalized']
del data_quarter['epu_e_normalized']
del data_quarter['week']


data_quarter['epu_count']=data_quarter['epu']/data_quarter['count']
data_quarter['epu_econ']=data_quarter['epu']/data_quarter['e']

data_quarter.columns

std3=data_quarter['epu_count'].std()
std3_e=data_quarter['epu_econ'].std()

data_quarter['epu_quarter_std']=data_quarter['epu_count']/std3
data_quarter['epu_quarter_e_std']=data_quarter['epu_econ']/std3_e

mean3=data_quarter['epu_quarter_std'].mean()
mean3_e=data_quarter['epu_quarter_e_std'].mean()

data_quarter['epu_quarter_normalized']=data_quarter['epu_quarter_std']*100/mean3
data_quarter['epu_quarter_e_normalized']=data_quarter['epu_quarter_e_std']*100/mean3_e
data_quarter.columns
del data_quarter['epu_quarter_std']
del data_quarter['epu_quarter_e_std']

data_quarter.to_csv('1978_2018quarterly.csv', index=False)



#and monthly index
date_date=modern1978_2018['date']
date_date=date_date.tolist()


import datetime
date_time=[]
for i in date_date:
    i=str(i)
    try:
        datetime0=datetime.datetime.strptime(i,'%m/%d/%Y')
    except ValueError:
        datetime0=datetime.datetime.strptime(i, '%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y/%m')
    month_time.append(month_time0)

len(month_time)

modern1978_2018['month']=month_time


df_month=modern1978_2018.groupby('month').sum().reset_index()
df_month.columns
df_month=df_month[['month','epu','e','count']]


df_month['epu_count']=df_month['epu']/df_month['count']
df_month['epu_econ']=df_month['epu']/df_month['e']

df_month=df_month.iloc[1:]
df_month.head(n=10)

df_month.columns

std2=df_month['epu_count'].std()
std2_e=df_month['epu_econ'].std()

df_month['epu_month_std']=df_month['epu_count']/std2
df_month['epu_month_e_std']=df_month['epu_econ']/std2_e

mean2=df_month['epu_month_std'].mean()
mean2_e=df_month['epu_month_e_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month['epu_month_e_normalized']=df_month['epu_month_e_std']*100/mean2_e

df_month.columns
del df_month['epu_month_std']
del df_month['epu_month_e_std']
df_month.head(10)
df_month.to_csv(r'1978_2018monthly.csv')


all1946_2017=his1946_1991.append(current1992_2017, sort=False)
all1946_2017.to_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\all\1946_2017month.csv')
##directly put together
his1946_1991=pd.read_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\historical1946_1991\historical_month.csv')
col1=his1946_1991.columns
del his1946_1991['epu_month_std']
del his1946_1991['epu_month_e_std']

current1992_2017=pd.read_csv('1992_2017month.csv')
col2=current1992_2017.columns
del current1992_2017['epu_month_e_std']

all1946_2017=his1946_1991.append(current1992_2017, sort=False)
all1946_2017.to_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\all\1946_2017month_part.csv')

#calculate as a whole
all46_17=pd.read_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\all\1946_2017month.csv')
std3=all46_17['epu_count'].std()
std3_e=all46_17['epu_econ'].std()

all46_17['epu_month_std']=all46_17['epu_count']/std3
all46_17['epu_month_e_std']=all46_17['epu_econ']/std3_e

mean3=all46_17['epu_month_std'].mean()
mean3_e=all46_17['epu_month_e_std'].mean()

all46_17['epu_month_normalized']=all46_17['epu_month_std']*100/mean3
all46_17['epu_month_e_normalized']=all46_17['epu_month_e_std']*100/mean3_e
del all1946_2017['epu_month_std']
del all1946_2017['epu_month_e_std']


all46_17.to_csv(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\csv\all\1946_2017month_all.csv')
