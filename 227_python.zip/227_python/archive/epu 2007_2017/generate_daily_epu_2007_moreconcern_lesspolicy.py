# -*- coding: utf-8 -*-
"""
Created on Mon May 07 20:47:20 2018

@author: dingq
"""

import os
import re


lead1=u'本报'
lead2=u'新华社'

uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

tpolicy1=u'进口关税'
tpolicy2=u'进口税'
tpolicy3=u'进口壁垒'
tpolicy4=u'WTO'
tpolicy5=u'世界贸易组织'
tpolicy6=u'世贸组织'
tpolicy7=u'贸易条约'
tpolicy8=u'贸易协定'
tpolicy9=u'贸易政策'
tpolicy10=u'贸易法'
tpolicy11=u'多哈回合'
tpolicy12=u'乌拉圭回合'
tpolicy13=u'GATT'
tpolicy14=u'关贸总协定'
tpolicy15=u'倾销'
tpolicy16=u'保护主义'
tpolicy17=u'贸易壁垒'
tpolicy18=u'出口补贴'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

tp1 =re.compile(tpolicy1)
tp2 =re.compile(tpolicy2)
tp3 =re.compile(tpolicy3)
tp4 =re.compile(tpolicy4)
tp5 =re.compile(tpolicy5)
tp6 =re.compile(tpolicy6)
tp7 =re.compile(tpolicy7)
tp8 =re.compile(tpolicy8)
tp9 =re.compile(tpolicy9)
tp10 =re.compile(tpolicy10)
tp11 =re.compile(tpolicy11)
tp12 =re.compile(tpolicy12)
tp13 =re.compile(tpolicy13)
tp14 =re.compile(tpolicy14)
tp15 =re.compile(tpolicy15)
tp16 =re.compile(tpolicy16)
tp17 =re.compile(tpolicy17)
tp18 =re.compile(tpolicy18)





article=[]
u1=[]
u2=[]
u3=[]
u4=[]
u5=[]
u6=[]
u7=[]
u8=[]
u9=[]
u10=[]

e1=[]
e2=[]

t1 =[]
t2 =[]
t3 =[]
t4 =[]
t5 =[]
t6 =[]
t7 =[]
t8 =[]
t9 =[]
t10 =[]
t11 =[]
t12 =[]
t13 =[]
t14 =[]
t15 =[]
t16 =[]
t17 =[]
t18 =[]

year_='2016'
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\Archive\RMRB complete'+'\\'+year_)
path=os.listdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\Archive\RMRB complete'+'\\'+year_)
path[0]
len(path)

for m in path:
    with open(m,'r+',encoding='utf8',errors='ignore') as f:
        read_data=f.read()
        read_data=read_data.replace(' ', '')
        read_data=read_data.replace('\n','')
        slot1=read_data.split(lead1)
        slot2=[]
    for j in slot1:
        slot=j.split(lead2)
        slot2.extend(slot)
    n=0
    while n<len(slot2):
        if len(slot2[n])<200:
            slot2.pop(n)
            n-=1
        n+=1
    article=article+list(range(len(slot2)))

    for i in slot2:
        result=len(pu1.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u1.append(uu)
        
    for i in slot2:
        result=len(pu2.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u2.append(uu)
        
    for i in slot2:
        result=len(pu3.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u3.append(uu)

    for i in slot2:
        result=len(pu4.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u4.append(uu)
        
    for i in slot2:
        result=len(pu5.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u5.append(uu)
        
    for i in slot2:
        result=len(pu6.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u6.append(uu)
    
    for i in slot2:
        result=len(pu7.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u7.append(uu)
    
    for i in slot2:
        result=len(pu8.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u8.append(uu)
    
    for i in slot2:
        result=len(pu9.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u9.append(uu)
    
    for i in slot2:
        result=len(pu10.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u10.append(uu)
                
    for i in slot2:
        result=len(pe1.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e1.append(ee)
                
    for i in slot2:
        result=len(pe2.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e2.append(ee)
                
    for i in slot2:
        result=len(tp1.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t1.append(pp)
 
         
    for i in slot2:
        result=len(tp2.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t2.append(pp)
                
    for i in slot2:
        result=len(tp3.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t3.append(pp)
                
    for i in slot2:
        result=len(tp4.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t4.append(pp)
                
    for i in slot2:
        result=len(tp5.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t5.append(pp)
        
    for i in slot2:
        result=len(tp6.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t6.append(pp)
                
    for i in slot2:
        result=len(tp7.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t7.append(pp)
        
    for i in slot2:
        result=len(tp8.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t8.append(pp)
        
    for i in slot2:
        result=len(tp9.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t9.append(pp)

    for i in slot2:
        result=len(tp10.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t10.append(pp)
        
    
    for i in slot2:
        result=len(tp11.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t11.append(pp)
        
    for i in slot2:
        result=len(tp12.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t12.append(pp)
        
    for i in slot2:
        result=len(tp13.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t13.append(pp)
        
    for i in slot2:
        result=len(tp14.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t14.append(pp)
        
    for i in slot2:
        result=len(tp15.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t15.append(pp)
        
    for i in slot2:
        result=len(tp16.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t16.append(pp)
        
    for i in slot2:
        result=len(tp17.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t17.append(pp)
        
    for i in slot2:
        result=len(tp18.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        t18.append(pp)
        


import datetime

start=datetime.date(int(year_)-1,12,31)
date=[]
i=0
while i<len(article):
    if i<len(article)-1:
        if article[i-1]<article[i]:
            time=str(start)
            date.append(time)
            i+=1
        else:
            start=start+datetime.timedelta(days=1)
            time=str(start)
            date.append(time)
            i+=1
    else:
        date.append(time)
        i+=1
    
len(article)
len(date)

u=[]
e=[]
t=[]

for i in range(len(article)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(article)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(article)):        
    if t1[i]>0 or \
       t2[i]>0 or \
       t3[i]>0 or \
       t4[i]>0 or \
       t5[i]>0 or \
       t6[i]>0 or \
       t7[i]>0 or \
       t8[i]>0 or \
       t9[i]>0 or \
       t10[i]>0 or \
       t11[i]>0 or \
       t12[i]>0 or \
       t13[i]>0 or \
       t14[i]>0 or \
       t15[i]>0 or \
       t16[i]>0 or \
       t17[i]>0 or \
       t18[i]>0: 
           p0=1
           t.append(p0)
    else:
        p0=0
        t.append(p0)

         
tpu=[]
for i in range(len(u)):  
    if u[i]>0 and e[i]>0 and t[i]>0:
        epu0=1
        tpu.append(epu0)
    else:
        epu0=0
        tpu.append(epu0)
 
len(e)
len(t)
len(u)
len(tpu)

len(article)
len(date)

import pandas as pd       
data2007={'article':article,'e':e,'t':t,'u':u,'tpu':tpu,'date':date}
epu2007=pd.DataFrame(data=data2007,index=date)

cc=epu2007.groupby('date').sum().reset_index()
bb=epu2007.groupby('date').max().reset_index()
date_sort=bb['date']
article_sort=bb['article']
tpu_sort=cc['tpu']
e_sort=cc['e']
t_sort=cc['t']
u_sort=cc['u']

epu2007_sorted=pd.concat([date_sort,tpu_sort,article_sort,e_sort,t_sort,u_sort],axis=1)
epu2007_sorted['tpu_article']=epu2007_sorted['tpu']/epu2007_sorted['article']
epu2007_sorted['tpu_e_article']=epu2007_sorted['tpu']/epu2007_sorted['e']

epu2007_sorted.head(10)

epu2007_sorted.set_index('date',inplace=True)
epu2007_sorted.head(10)
epu2007_sorted=epu2007_sorted.rename(columns={'article':'count'})
epu2007_sorted=epu2007_sorted.rename(columns={'tpu_article':'tpu_count'})
epu2007_sorted=epu2007_sorted.rename(columns={'tpu_e_article':'tpu_econ'})


epu2007_sorted=epu2007_sorted.filter(['tpu','count','e','tpu_count','tpu_econ'])
epu2007_sorted.to_csv('tpudaily'+year_+'.csv')




