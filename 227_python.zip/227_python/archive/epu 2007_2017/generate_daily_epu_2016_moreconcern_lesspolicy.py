# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:35:14 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:33:43 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:32:08 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:30:13 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 11:27:06 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 09:02:07 2018

@author: dingq
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 23:10:46 2017

@author: dingqianliu
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 23:08:13 2017

@author: dingqianliu
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 28 13:02:27 2017

@author: dingqianliu
"""

import os
import re


lead1=u'本报'
lead2=u'新华社'

uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy2=u'财政'
policy3=u'货币'
policy4=u'证监会'
policy5=u'银监会'
policy6=u'财政部'
policy7=u'人民银行'
policy8=u'国家发改委'
policy9=u'银行'
policy11=u'规则'
policy12=u'决策'
policy13=u'开放'
policy14=u'改革'
policy15=u'规定'
policy16=u'商务部'
policy17=u'法律'
policy18=u'法规'
policy19=u'税'
policy20=u'赤字'
policy21=u'国债'
policy22=u'政府债务'
policy23=u'央行'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)
pp20 =re.compile(policy20)
pp21 =re.compile(policy21)
pp22 =re.compile(policy22)
pp23 =re.compile(policy23)

article=[]
u1=[]
u2=[]
u3=[]
u4=[]
u5=[]
u6=[]
u7=[]
u8=[]
u9=[]
u10=[]

e1=[]
e2=[]

p2 =[]
p3 =[]
p4 =[]
p5 =[]
p6 =[]
p7 =[]
p8 =[]
p9 =[]
p11 =[]
p12 =[]
p13 =[]
p14 =[]
p15 =[]
p16 =[]
p17 =[]
p18 =[]
p19 =[]
p20 =[]
p21 =[]
p22 =[]
p23 =[]

os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_txt\2016')
path=os.listdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_txt\2016')
path[0]
len(path)

for m in path:
    with open(m,'r+',encoding='utf8') as f:
        read_data=f.read()
        read_data=read_data.replace(' ', '')
        read_data=read_data.replace('\n','')
        slot1=read_data.split(lead1)
        slot2=[]
    for j in slot1:
        slot=j.split(lead2)
        slot2.extend(slot)
    n=0
    while n<len(slot2):
        if len(slot2[n])<200:
            slot2.pop(n)
            n-=1
        n+=1
    article=article+list(range(len(slot2)))

    for i in slot2:
        result=len(pu1.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u1.append(uu)
        
    for i in slot2:
        result=len(pu2.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u2.append(uu)
        
    for i in slot2:
        result=len(pu3.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u3.append(uu)

    for i in slot2:
        result=len(pu4.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u4.append(uu)
        
    for i in slot2:
        result=len(pu5.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u5.append(uu)
        
    for i in slot2:
        result=len(pu6.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u6.append(uu)
    
    for i in slot2:
        result=len(pu7.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u7.append(uu)
    
    for i in slot2:
        result=len(pu8.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u8.append(uu)
    
    for i in slot2:
        result=len(pu9.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u9.append(uu)
    
    for i in slot2:
        result=len(pu10.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u10.append(uu)
                
    for i in slot2:
        result=len(pe1.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e1.append(ee)
                
    for i in slot2:
        result=len(pe2.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e2.append(ee)
                
                   
    for i in slot2:
        result=len(pp2.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p2.append(pp)
                
    for i in slot2:
        result=len(pp3.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p3.append(pp)
                
    for i in slot2:
        result=len(pp4.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p4.append(pp)
                
    for i in slot2:
        result=len(pp5.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p5.append(pp)
        
    for i in slot2:
        result=len(pp6.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p6.append(pp)
                
    for i in slot2:
        result=len(pp7.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p7.append(pp)
        
    for i in slot2:
        result=len(pp8.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p8.append(pp)
        
    for i in slot2:
        result=len(pp9.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p9.append(pp)
        
        
    for i in slot2:
        result=len(pp11.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p11.append(pp)
        
    for i in slot2:
        result=len(pp12.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p12.append(pp)
        
    for i in slot2:
        result=len(pp13.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p13.append(pp)
        
    for i in slot2:
        result=len(pp14.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p14.append(pp)
        
    for i in slot2:
        result=len(pp15.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p15.append(pp)
        
    for i in slot2:
        result=len(pp16.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p16.append(pp)
        
    for i in slot2:
        result=len(pp17.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p17.append(pp)
        
    for i in slot2:
        result=len(pp18.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p18.append(pp)
        
    for i in slot2:
        result=len(pp19.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p19.append(pp)
        
    for i in slot2:
        result=len(pp20.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p20.append(pp)
        
    for i in slot2:
        result=len(pp21.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p21.append(pp)
        
    for i in slot2:
        result=len(pp22.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p22.append(pp)
        
    for i in slot2:
        result=len(pp23.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p23.append(pp)
        
  


import datetime

start=datetime.date(2015,12,31)
date=[]
i=0
while i<len(article):
    if i<len(article)-1:
        if article[i-1]<article[i]:
            time=str(start)
            date.append(time)
            i+=1
        else:
            start=start+datetime.timedelta(days=1)
            time=str(start)
            date.append(time)
            i+=1
    else:
        date.append(time)
        i+=1
    
len(article)
len(date)

u=[]
e=[]
p=[]

for i in range(len(article)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(article)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(article)):        
    if p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0 or \
       p16[i]>0 or \
       p17[i]>0 or \
       p18[i]>0 or \
       p19[i]>0 or \
       p20[i]>0 or \
       p21[i]>0 or \
       p22[i]>0 or \
       p23[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(u)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 
len(e)
len(p)
len(u)
len(epu)

import pandas as pd       
data2016={'article':article,'e':e,'p':p,'u':u,'epu':epu,'date':date}
epu2016=pd.DataFrame(data=data2016,index=date)

cc=epu2016.groupby('date').sum().reset_index()
bb=epu2016.groupby('date').max().reset_index()
date_sort=bb['date']
article_sort=bb['article']
epu_sort=cc['epu']

epu2016_sorted=pd.concat([date_sort,epu_sort,article_sort],axis=1)
epu2016_sorted['epu_article']=epu2016_sorted['epu']/epu2016_sorted['article']
epu2016_sorted.head(10)

epu2016_sorted.set_index('date',inplace=True)
epu2016_sorted.to_csv('r_epu2016_sorted.csv',encoding='utf-8')

