# -*- coding: utf-8 -*-
"""
Created on Fri Sep  7 15:04:47 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 11 15:10:31 2018

@author: dingq
"""
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 15:33:52 2018

@author: dingq
"""




'''现在的问题是要将这些步骤连接起来:
    1. 打开某一天的第一版页面，并爬取当天所有版面的链接，保存在list中
    2. 写loop，爬取每个版面的文章列表链接，保存在list中
    3. 将列表链接和网站general链接组合起来，保存在list中
    4. 写loop，爬取当天报纸每一天的文章
    
    '''
'''第一步：爬取当天所有版面的链接，保存在list中'''
#准备好软件包
from bs4 import BeautifulSoup
import urllib.request
import re
import time
import os
import http


newpath = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_re_scrap'
if not os.path.exists(newpath):
    os.makedirs(newpath)
os.chdir(newpath)
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
add_on='/1'
p=re.compile('\d')

#提取当天第一版的 URL 的HTML内容
#a='20070101'

def arti(x):
    general='http://data.people.com.cn/rmrb'+'/'+x
    rmrb_p=urllib.request.Request(url=general+add_on, headers=headers)
    rmrb_p_r=urllib.request.urlopen(rmrb_p)
    response=rmrb_p_r.read()
    #用BeautifulSoup解析数据，'html.parser'在python3中是必须
    html=BeautifulSoup(response,'html.parser')
#     except urllib.error.HTTPError:
#        print('urllib.error.HTTPError')  
    #出现错误，停几秒先    
#    except http.client.IncompleteRead:
#        print('IncompleteRead')
    #提取当天文章总数和版面数
    article_num=html.find_all(id='UseRmrbNum')
    article_num=''.join([str(f) for f in article_num])
    article_num=int(''.join(p.findall(article_num)))
    article_num=str(article_num)
    return article_num

import datetime
from datetime import timedelta
d1 = datetime.datetime(1946, 5, 15)  # start date
d2 = datetime.datetime(1977, 12, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)
    
    
    
datelist_str=[]
for i in datelist:
    year=str(i.year)
    month=str(i.month)
    if len(month)<2:
        month='0'+month
    else:
        month=month
    dat=str(i.day)
    if len(dat)<2:
        dat='0'+dat
    else:
        dat=dat
    aa=year+month+dat
    datelist_str.append(aa)
    
len(datelist_str) 
datelist_str[3128]
    
art_nums=[]

for i in datelist_str[9800:]:
    art_n=arti(i)
    art_nums.append(art_n)
    time.sleep(0.1)

len(art_nums)
#art_nums.append('')
   
import pandas as pd
df=pd.DataFrame(data=art_nums)    
df['date']=date_form

df.to_csv('article_number_daily_1946_2006.csv')
    