# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
##import os package which helps to deal with file issues##
import os
##to get current file path, default by system##
os.getcwd()
print os.getcwd()
##change the file path, chdir as change directory##
os.chdir('/Users/dingqianliu/Documents/my dissertation/data/201103')
##or can use##
path='/Users/dingqianliu/Documents/my dissertation/python'
os.chdir(path)
##open file and write file##
#intro level, always remember to close the file after use##
f=open('myfile.txt','a+') #默认指针在最后，故用read（）会出来空的答案，得先调整指针位置
f.seek(0)
f.read(2)
f.write('1234')
f.seek(5) #go to the 6th byte in the file
f.write('abcd')
f.seek(-3,2) # go to the 3rd byte before the end
f.readline() #reads a single line from the file
f.close()
f.closed

## read a file with loop, 但即使这样用，也存在指针位置的问题
f.seek(0)
for line in f:
    print line

##读整个file，但出来的结果会成为一个list，在中括号里
f.seek(0)
list(f)
f.readlines()
#to write sth other than tring, need to convert it into string

f.tell() #returns an integer giving the file object’s current position in the file, measured in bytes from the beginning of the file

#intermediate level, with open will close the file automatically, no worries with f.close
with open('myfile.txt','r+') as f:
    read_data=f.read()
read_data

with open('myfile.txt','a+') as f:
    f.write('night\n') #\n指新起一行写入，\n is the line seperator,
    

#deal with pdf
!conda install PyPDF2
!pip install PyPDF2
#if this does not work try it in ipython
import PyPDF2

#正则表达式，中文
import re

pdf=open('rmrb.pdf','rb')
pdfreader=PyPDF2.PdfFileReader(pdf)
pdfreader.numPages
pageobj=pdfreader.getPage(0)
a=pageobj.extractText()
import sys
print sys.getdefaultencoding()
