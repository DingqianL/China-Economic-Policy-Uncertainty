#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 24 10:43:59 2018

@author: dingqianliu
"""

import pytesseract
from PIL import Image

image = Image.open(‘yzm.png‘)
image.load()
image.split()
vcode = pytesseract.image_to_string(image)
print vcode



from wand.image import Image
from PIL import Image as PI
import pyocr
import pyocr.builders
import io
import sys

!pip install git+https://github.com/jflesch/pyocr.git

tools = pyocr.get_available_tools()
if len(tools) == 0:
    print("No OCR tool found")
   

#获得ocr库以及在pyocr中要用的语言
tool=pyocr.get_available_tools()[0]
lang=tool.get_available_languages()[1]

#建立列表储存图像和最终的文本
req_image=[]
final_text=[]

#运用wand将一个pdf文件转换成jpeg文件

image_pdf=Image(filename='/Users/dingqianliu/Documents/200-academic/220-Academic|My dissertation/data_ocr/人民日报 2006年/1月/01.pdf', resolution =300)
image_jpeg=image_pdf.convert('jpeg')


with Image(filename='/Users/dingqianliu/Documents/200-academic/220-Academic|My dissertation/data_ocr/人民日报 2006年/1月/01.pdf') as pdf: 
    with pdf.convert('jpeg') as image: 
        image.save(filename='result.jpeg')

#wand已经将PDF中所有的独立页面都转成了独立的二进制图像对象。我们可以遍历这个大对象，并把它们加入到req_image序列中去

for img in image_jpeg.sequence:
    img_page=Image(image=img)
    req_image.append(img_page.make_blob('jpeg'))
    
#开始在图像对象上运行ocr文件
    
for img in req_image:
    txt=tool.image_to_string(
            PI.open(io.BytesIO(img)),
            lang=lang,
            builder=pyocr.builders.TextBuilder()
    )
    final_text.append(txt)
    
    
    

import pytesseract
from PIL import Image
img=Image.open('')  # 创建image对象
text=pytesseract.image_to_string(img)
repr(text)
    
    
pytesseract.pytesseract.tesseract_cmd ='/usr/local/Cellar/tesseract/3.05.01/bin/tesseract'
os.chdir('/Users/dingqianliu/Documents/200-academic/220-Academic|My dissertation/data_ocr/人民日报 2006年/1月')

text=pytesseract.image_to_string(Image.open('test.png'))
text2=pytesseract.image_to_string(Image.open('01_Page_1.png'), lang='chi_sim')

with open('01_Page_1.txt','w') as file:
    file.write(text2.encode('utf8'))



import PythonMagick
img = PythonMagick.Image()
img.density("300")
img.read("Desktop/test.PDF") # read in at 300 dpi
img.write("Desktop/test.PNG")

import PyPDF2
from wand.image import Image
import io
import os


