#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 15:15:20 2018

@author: dingqianliu
"""

  
os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\jan')
path=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\jan')

for x in range(len(path)):
    old_name=path[x]
    new_name=str(x+15)+'.txt'
    pdfTotxt(old_name,new_name)
    
os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\feb')
path1=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\feb')
for x in range(len(path1)):
    old_name=path[x]
    new_name=str(x+15)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\march')
path2=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\march')
for x in range(len(path2)):
    old_name=path[x]
    new_name=str(x+15)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\apr')
path3=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\apr')
for x in range(len(path3)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\may')
path4=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\may')
for x in range(len(path4)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\jun')
path5=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\jun')
for x in range(len(path5)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)


os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\july')
path6=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\july')
for x in range(len(path6)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\aug')
path7=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\aug')
for x in range(len(path7)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)


os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\sep')
path8=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\sep')
for x in range(len(path8)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\oct')
path9=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\oct')
for x in range(len(path9)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\nov')
path10=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\nov')
for x in range(len(path10)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)

os.chdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\dec')
path11=os.listdir('C:\\Users\\dingq\\Documents\\2009\\18 2009\\dec')
for x in range(len(path11)):
    old_name=path[x]
    new_name=str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)




####above is to read pdfto text
    