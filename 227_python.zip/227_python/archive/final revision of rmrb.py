# -*- coding: utf-8 -*-
"""
Created on Tue Jun 26 16:16:02 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 14:02:07 2018

@author: dingq
"""

#####data processing
from datetime import datetime
import pandas as pd
import os

#date_today = datetime.now().date()
#days = pd.date_range(date_today, date_today + timedelta(7), freq='D')

from datetime import date
d0=date(1946,5,15)
d1=date(2017,12,31)
d2=date(1946,12,31)
delta=d1-d0
delta2=d2-d0
period=delta.days+1
print(delta2.days)


fulldate=pd.date_range("19460515", periods=period)
fulldate_string=[i.strftime('%m/%d/%Y') for i in fulldate]
fulldate_datetime=[datetime.strptime(d,'%m/%d/%Y').date() for d in fulldate_string]
fullrange=pd.DataFrame(fulldate_datetime)
fullrange=fullrange.rename(columns={0:'date'})
fullrange.head(10)
fullrange.tail(10)
fullrange.count
fullrange.to_csv('fullrange.csv')



os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\223_data_csv_01_reduced1946-2017(most updated)')
full_epudaily=pd.read_csv('aggregate_epudailty1946_2017(revised and complete).csv')
full_epudaily.head(10)
full_epudaily.tail(10)
full_epudaily.set_index(full_epudaily['date'],inplace=True)

redo=pd.to_datetime(full_epudaily['date'])
full_epudaily['date']=redo
aggregate_epudaily1946_2017=pd.concat([fullrange, full_epudaily],axis=0,sort=False)
aggregate_epudaily1946_2017.head(10)
aa=pd.merge(fullrange, full_epudaily,on='date')
aa.head(10)
#aggregate_epudailty1946_2006_2011_2017=pd.merge(fullrange, a_epudaily1946_2003_2011_2017,how='outer')
fullrange.join(full_epudaily,how='right')

aggregate_epudaily1946_2017.to_csv('test.csv')
#aggregate_epudailty1946_2003_2011_2017.to_csv('aggregate_epudailty1946_2003_2011_2017.csv')

os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\223_data_csv_01_reduced1946-2017(most updated)')
full_epudaily=pd.read_excel('aggregate_epudailty1946_2017(revised and complete).xlsx')
full_epudaily.head(10)

###generate daily index 
epu_std=full_epudaily['epu_count'].std()
full_epudaily['epu_std']\
=full_epudaily['epu_count']/epu_std
epu_mean=full_epudaily['epu_std'].mean()

full_epudaily['epu_normalized']\
=full_epudaily['epu_std']/epu_mean*100
full_epudaily.describe()

full_epudaily.head(n=10)
full_epudaily.tail(n=10)

full_epudaily.to_csv('full_epudaily_normalized1949-2017.csv',encoding='utf-8')

#and monthly index
full_epudaily=pd.read_csv('full_epudaily_normalized1949-2017.csv',encoding='utf-8')
full_epudaily.head(5)
date_date=full_epudaily['date']
date_date=date_date.tolist()

import datetime
date_time=[]
for i in date_date:
    i=str(i)
    datetime0=datetime.datetime.strptime(i,'%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y-%m')
    month_time.append(month_time0)

len(month_time)

full_epudaily['month']=month_time

full_epudaily['month']

df_month=full_epudaily.groupby('month').sum().reset_index()
df_month['epu_count']=df_month['epu']/df_month['count']

df_month.head(n=10)

df_month.describe()
std2=df_month['epu_normalized'].std()
df_month['epu_month_std']=df_month['epu_normalized']/std2

mean2=df_month['epu_month_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('full_epu_month_normalized1949-2017.csv',encoding='utf-8')

