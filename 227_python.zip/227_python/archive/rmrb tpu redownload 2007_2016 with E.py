# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 14:47:21 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 07:13:05 2018

@author: dingq
"""

## I have to redownload data for 2007-2016, as the PDF files has bias on spliting articles
## I need to design this program to process each folder, as there're dozens of txt files in each folder
## Each folder contains all text files of a certain year (2007-2016), and each article is labelled with E


## step 1: split each txt file into single article with date label (eg. 2007-12-02)

#import modules
import os 
import re
import pandas as pd

#write all text file into a single text file
path=os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_re_scrap\rmrb2016')
file='2016e.txt'

with open(file,'r', encoding = 'utf8') as f:
    texts=f.read()
       
texts=texts.replace(' ', '') #delete space
texts=texts.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
datepattern=re.compile(r'\d{4}\-\d{2}\-\d{2}')
match = re.split(datepattern, texts) #split into single article
del match[0]

date=re.findall(datepattern,texts) #identify dates

##to make sure the #of text matches that of date
if len(match)!=len(date):
    print('Split Error!')
else:
    print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
#        texts=f.write(match[m])
#    m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
articlelist=pd.DataFrame(data=match, index=date)
articlelist.info() 
articlelist['date']=date

##compile key words
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

#no E as these articles are already labeled with E
#economy1=u'经济'
#economy2=u'商业'

tpolicy1=u'外贸'
tpolicy2=u'进出口'
tpolicy3=u'保护主义'
tpolicy4=u'贸易顺差'
tpolicy5=u'贸易逆差'
tpolicy6=u'贸易壁垒'
tpolicy7=u'进口关税'
tpolicy8=u'进口税'
tpolicy9=u'进口壁垒'
tpolicy10=u'WTO'
tpolicy11=u'世界贸易组织'
tpolicy12=u'贸易条约'
tpolicy13=u'贸易协定'
tpolicy14=u'贸易政策'
tpolicy15=u'贸易法'
tpolicy16=u'多哈回合'
tpolicy17=u'乌拉圭回合'
tpolicy18=u'GATT'
tpolicy19=u'关贸总协定'
tpolicy20=u'倾销'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

#pe1=re.compile(economy1)
#pe2=re.compile(economy2)

tp1 =re.compile(tpolicy1)
tp2 =re.compile(tpolicy2)
tp3 =re.compile(tpolicy3)
tp4 =re.compile(tpolicy4)
tp5 =re.compile(tpolicy5)
tp6 =re.compile(tpolicy6)
tp7 =re.compile(tpolicy7)
tp8 =re.compile(tpolicy8)
tp9 =re.compile(tpolicy9)
tp10 =re.compile(tpolicy10)
tp11 =re.compile(tpolicy11)
tp12 =re.compile(tpolicy12)
tp13 =re.compile(tpolicy13)
tp14 =re.compile(tpolicy14)
tp15 =re.compile(tpolicy15)
tp16 =re.compile(tpolicy16)
tp17 =re.compile(tpolicy17)
tp18 =re.compile(tpolicy18)
tp19 =re.compile(tpolicy19)
tp20 =re.compile(tpolicy20)


# a function to compile keywords
def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts
    

    
# save count of keywords into DataFrame
u1=keywords(match,pu1)
articlelist['u1']=u1
u2=keywords(match,pu2)
articlelist['u2']=u2
u3=keywords(match,pu3)
articlelist['u3']=u3
u4=keywords(match,pu4)
articlelist['u4']=u4
u5=keywords(match,pu5)
articlelist['u5']=u5
u6=keywords(match,pu6)
articlelist['u6']=u6
u7=keywords(match,pu7)
articlelist['u7']=u7
u8=keywords(match,pu8)
articlelist['u8']=u8
u9=keywords(match,pu9)
articlelist['u9']=u9
u10=keywords(match,pu10)
articlelist['u10']=u10

#e1=keywords(match,pe1)
#articlelist['e1']=e1
#e2=keywords(match,pe2)
#articlelist['e2']=e2

ttp1 =keywords(match,tp1)
articlelist['tp1']=ttp1
ttp2 =keywords(match,tp2)
articlelist['tp2']=ttp2
ttp3 =keywords(match,tp3)
articlelist['tp3']=ttp3
ttp4 =keywords(match,tp4)
articlelist['tp4']=ttp4
ttp5 =keywords(match,tp5)
articlelist['tp5']=ttp5
ttp6 =keywords(match,tp6)
articlelist['tp6']=ttp6
ttp7 =keywords(match,tp7)
articlelist['tp7']=ttp7
ttp8 =keywords(match,tp8)
articlelist['tp8']=ttp8
ttp9 =keywords(match,tp9)
articlelist['tp9']=ttp9
ttp10 =keywords(match,tp10)
articlelist['tp10']=ttp10
ttp11 =keywords(match,tp11)
articlelist['tp11']=ttp11
ttp12 =keywords(match,tp12)
articlelist['tp12']=ttp12
ttp13 =keywords(match,tp13)
articlelist['tp13']=ttp13
ttp14 =keywords(match,tp14)
articlelist['tp14']=ttp14
ttp15 =keywords(match,tp15)
articlelist['tp15']=ttp15
ttp16 =keywords(match,tp16)
articlelist['tp16']=ttp16
ttp17 =keywords(match,tp17)
articlelist['tp17']=ttp17
ttp18 =keywords(match,tp18)
articlelist['tp18']=ttp18
ttp19 =keywords(match,tp19)
articlelist['tp19']=ttp19
ttp20 =keywords(match,tp20)
articlelist['tp20']=ttp20
    
###generate index epu
u=[]
p=[]

for i in range(len(match)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

        
for i in range(len(match)):        
    if ttp1[i]>0 or \
       ttp2[i]>0 or \
       ttp3[i]>0 or \
       ttp4[i]>0 or \
       ttp5[i]>0 or \
       ttp6[i]>0 or \
       ttp7[i]>0 or \
       ttp8[i]>0 or \
       ttp9[i]>0 or \
       ttp10[i]>0 or \
       ttp11[i]>0 or \
       ttp12[i]>0 or \
       ttp13[i]>0 or \
       ttp14[i]>0 or \
       ttp15[i]>0 or \
       ttp16[i]>0 or \
       ttp17[i]>0 or \
       ttp18[i]>0 or \
       ttp19[i]>0 or \
       ttp20[i]:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
tpu=[]
for i in range(len(match)):  
    if u[i]>0 and p[i]>0:
        tpu0=1
        tpu.append(tpu0)
    else:
        tpu0=0
        tpu.append(tpu0)
 
len(p)
len(u)
len(tpu)


if len(p)==len(u)==len(tpu)==len(match)==len(date):
    print('Pass')
else:
    print('Alert')

#put epu index into DataFrame
articlelist['p']=p
articlelist['u']=u
articlelist['tpu']=tpu

articlelist=articlelist.rename(columns={0:'match'})
articlelist.columns


'''generate epu daily index'''

tpu_test=articlelist.filter(['date','tpu'],axis=1)
tpu_test.count()
tpu_test.head(10)

tpu_test1=tpu_test.groupby('date').sum()
tpu_test1.count()
tpu_test1.head(10)

tpu_test2=tpu_test.groupby('date').size()
tpu_test2.head(10)

tpudaily=pd.concat([tpu_test1,tpu_test2],axis=1)
tpudaily=tpudaily.rename(columns={0:'e'})
tpudaily.head(10)
tpudaily.count

##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(2016, 1, 1)  # start date
d2 = datetime.datetime(2016, 12, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame
date_frame.head(10)
date_frame.count


###
tpudaily_date=pd.concat([tpudaily, date_frame], axis=1)
tpudaily_date=tpudaily_date.fillna(0)
tpudaily_date.head(25)
tpudaily_date.count

a_count=pd.read_csv('2016article.csv')
a_count_n=a_count['count']
a_count_n1=a_count_n.tolist()
tpudaily_date['count']=a_count_n1
tpudaily_date.head(25)
tpudaily_date.count


tpudaily_date.drop('date', axis=1, inplace=True)
tpudaily_date.head(10)
tpudaily_date['tpu_count']=tpudaily_date['tpu']/tpudaily_date['count']
tpudaily_date['tpu_econ']=tpudaily_date['tpu']/tpudaily_date['e']

tpudaily_date.tail(10)
tpudaily_date.to_csv('tpu2016_en.csv')


