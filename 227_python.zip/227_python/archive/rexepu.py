# -*- coding: utf-8 -*-
"""
Created on Fri Oct 12 13:43:24 2018

@author: dingq
"""

##rex for rmrb epu
import re
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy1=u'财政'
policy2=u'货币'
policy3=u'证监会'
policy4=u'银监会'
policy5=u'财政部'
policy6=u'人民银行'
policy7=u'国家发改委'
policy8=u'开放'
policy9=u'改革'
policy10=u'商务部'
policy11=u'法律'
policy12=u'法规'
policy13=u'税收'
policy14=u'国债'
policy15=u'政府债务'
policy16=u'央行'
policy17=u'外经贸部'
policy18=u'关税'
policy19=u'政府赤字'

#rex for T terms of TPU
tpolicy1=u'进口关税'
tpolicy2=u'进口税'
tpolicy3=u'进口壁垒'
tpolicy4=u'WTO'
tpolicy5=u'世界贸易组织'
tpolicy6=u'世贸组织'
tpolicy7=u'贸易条约'
tpolicy8=u'贸易协定'
tpolicy9=u'贸易政策'
tpolicy10=u'贸易法'
tpolicy11=u'多哈回合'
tpolicy12=u'乌拉圭回合'
tpolicy13=u'GATT'
tpolicy14=u'关贸总协定'
tpolicy15=u'倾销'
tpolicy16=u'保护主义'
tpolicy17=u'贸易壁垒'
tpolicy18=u'出口补贴'




pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp10 =re.compile(policy10)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)

tp1 =re.compile(tpolicy1)
tp2 =re.compile(tpolicy2)
tp3 =re.compile(tpolicy3)
tp4 =re.compile(tpolicy4)
tp5 =re.compile(tpolicy5)
tp6 =re.compile(tpolicy6)
tp7 =re.compile(tpolicy7)
tp8 =re.compile(tpolicy8)
tp9 =re.compile(tpolicy9)
tp10 =re.compile(tpolicy10)
tp11 =re.compile(tpolicy11)
tp12 =re.compile(tpolicy12)
tp13 =re.compile(tpolicy13)
tp14 =re.compile(tpolicy14)
tp15 =re.compile(tpolicy15)
tp16 =re.compile(tpolicy16)
tp17 =re.compile(tpolicy17)
tp18 =re.compile(tpolicy18)


#Terms for EPU, the compounded version of SCMP
spolicy1=u'政策'
spolicy2=u'支出'
spolicy3=u'预算'
spolicy4=u'政治'
spolicy5=u'利率'
spolicy6=u'改革'

sgeneral1=u'政府'
sgeneral2=u'中共中央'
sgeneral3=u'国务院'

spolicy7=u'税收'
spolicy8=u'规定'
spolicy9=u'监管'
spolicy10=u'央行'
spolicy11=u'人民银行'
spolicy12=u'赤字'
spolicy13=u'WTO'
spolicy14=u'世界贸易组织'
spolicy15=u'世贸组织'


sp1 =re.compile(spolicy1)
sp2 =re.compile(spolicy2)
sp3 =re.compile(spolicy3)
sp4 =re.compile(spolicy4)
sp5 =re.compile(spolicy5)
sp6 =re.compile(spolicy6)
sp7 =re.compile(spolicy7)
sp8 =re.compile(spolicy8)
sp9 =re.compile(spolicy9)
sp10 =re.compile(spolicy10)
sp11 =re.compile(spolicy11)
sp12 =re.compile(spolicy12)
sp13 =re.compile(spolicy13)
sp14 =re.compile(spolicy14)
sp15 =re.compile(spolicy15)

sg1 =re.compile(sgeneral1)
sg2 =re.compile(sgeneral2)
sg3 =re.compile(sgeneral3)

# a function to compile keywords
def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts
    
