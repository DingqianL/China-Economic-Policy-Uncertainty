# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 14:47:21 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 07:13:05 2018

@author: dingq
"""

## I have to redownload data for 2007-2016, as the PDF files has bias on spliting articles
## I need to design this program to process each folder, as there're dozens of txt files in each folder
## Each folder contains all text files of a certain year (2007-2016), and each article is labelled with E


## step 1: split each txt file into single article with date label (eg. 2007-12-02)

#import modules
import os 
import re
import pandas as pd

#write all text file into a single text file
path=os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_re_scrap\rmrb2016')
files=os.listdir(path)

texts=''
for i in files:
    with open( i,'r+',encoding = 'utf8', errors='ignore' ) as f:
        text=f.read()
        texts=texts+text
        
with open('2016e.txt','w', encoding = 'utf8') as f:
    f.write(texts)
       
texts=texts.replace(' ', '') #delete space
texts=texts.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
datepattern=re.compile(r'\d{4}\-\d{2}\-\d{2}')
match = re.split(datepattern, texts) #split into single article
del match[0]

date=re.findall(datepattern,texts) #identify dates

##to make sure the #of text matches that of date
if len(match)!=len(date):
    print('Split Error!')
else:
    print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
#        texts=f.write(match[m])
#    m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
articlelist=pd.DataFrame(data=match, index=date)
articlelist.info() 
articlelist['date']=date

##compile key words
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

#no E as these articles are already labeled with E
#economy1=u'经济'
#economy2=u'商业'

policy1=u'财政'
policy2=u'货币'
policy3=u'证监会'
policy4=u'银监会'
policy5=u'财政部'
policy6=u'人民银行'
policy7=u'国家发改委'
policy8=u'开放'
policy9=u'改革'
policy10=u'商务部'
policy11=u'法律'
policy12=u'法规'
policy13=u'税收'
policy14=u'国债'
policy15=u'政府债务'
policy16=u'央行'
policy17=u'外经贸部'
policy18=u'关税'

pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

#pe1=re.compile(economy1)
#pe2=re.compile(economy2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp10 =re.compile(policy10)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)


# a function to compile keywords
def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts
    

    
# save count of keywords into DataFrame
u1=keywords(match,pu1)
articlelist['u1']=u1
u2=keywords(match,pu2)
articlelist['u2']=u2
u3=keywords(match,pu3)
articlelist['u3']=u3
u4=keywords(match,pu4)
articlelist['u4']=u4
u5=keywords(match,pu5)
articlelist['u5']=u5
u6=keywords(match,pu6)
articlelist['u6']=u6
u7=keywords(match,pu7)
articlelist['u7']=u7
u8=keywords(match,pu8)
articlelist['u8']=u8
u9=keywords(match,pu9)
articlelist['u9']=u9
u10=keywords(match,pu10)
articlelist['u10']=u10

#e1=keywords(match,pe1)
#articlelist['e1']=e1
#e2=keywords(match,pe2)
#articlelist['e2']=e2

p1 =keywords(match,pp1)
articlelist['p1']=p1
p2 =keywords(match,pp2)
articlelist['p2']=p2
p3 =keywords(match,pp3)
articlelist['p3']=p3
p4 =keywords(match,pp4)
articlelist['p4']=p4
p5 =keywords(match,pp5)
articlelist['p5']=p5
p6 =keywords(match,pp6)
articlelist['p6']=p6
p7 =keywords(match,pp7)
articlelist['p7']=p7
p8 =keywords(match,pp8)
articlelist['p8']=p8
p9 =keywords(match,pp9)
articlelist['p9']=p9
p10 =keywords(match,pp10)
articlelist['p10']=p10
p11 =keywords(match,pp11)
articlelist['p11']=p11
p12 =keywords(match,pp12)
articlelist['p12']=p12
p13 =keywords(match,pp13)
articlelist['p13']=p13
p14 =keywords(match,pp14)
articlelist['p14']=p14
p15 =keywords(match,pp15)
articlelist['p15']=p15
p16 =keywords(match,pp16)
articlelist['p16']=p16
p17 =keywords(match,pp17)
articlelist['p17']=p17
p18 =keywords(match,pp18)
articlelist['p18']=p18
    
###generate index epu
u=[]
p=[]

for i in range(len(match)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

        
for i in range(len(match)):        
    if p1[i]>0 or \
       p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p10[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0 or \
       p16[i]>0 or \
       p17[i]>0 or \
       p18[i]:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(match)):  
    if u[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 
len(p)
len(u)
len(epu)


if len(p)==len(u)==len(epu)==len(match)==len(date):
    print('Pass')
else:
    print('Alert')

#put epu index into DataFrame
articlelist['p']=p
articlelist['u']=u
articlelist['epu']=epu

articlelist=articlelist.rename(columns={0:'match'})
articlelist.columns


'''generate epu daily index'''

epu_test=articlelist.filter(['date','epu'],axis=1)
epu_test.count()
epu_test.head(10)

epu_test1=epu_test.groupby('date').sum()
epu_test1.count()
epu_test1.head(10)

epu_test2=epu_test.groupby('date').size()
epu_test2.head(10)

epudaily=pd.concat([epu_test1,epu_test2],axis=1)
epudaily=epudaily.rename(columns={0:'e'})
epudaily.head(10)
epudaily.count

##generate correct list of date
import datetime
from datetime import timedelta
d1 = datetime.datetime(2016, 1, 1)  # start date
d2 = datetime.datetime(2016, 12, 31)  # end date

delta = d2 - d1         # timedelta

datelist=[]
for i in range(delta.days + 1):
    a=d1 + timedelta(i)
    datelist.append(a)

date_form=[]
for i in datelist:
    aaa=i.strftime('%Y-%m-%d')
    date_form.append(aaa)

date_frame=pd.DataFrame(data=date_form, index=date_form)
date_frame=date_frame.rename(columns={0:'date'})
date_frame
date_frame.head(10)
date_frame.count


###
epudaily_date=pd.concat([epudaily, date_frame], axis=1)
epudaily_date=epudaily_date.fillna(0)
epudaily_date.head(25)
epudaily_date.count

a_count=pd.read_csv('2016article.csv')
a_count_n=a_count['count']
a_count_n1=a_count_n.tolist()
epudaily_date['count']=a_count_n1
epudaily_date.head(25)
epudaily_date.count


epudaily_date.drop('date', axis=1, inplace=True)
epudaily_date.head(10)
epudaily_date['epu_count']=epudaily_date['epu']/epudaily_date['count']
epudaily_date['epu_econ']=epudaily_date['epu']/epudaily_date['e']

epudaily_date.tail(10)
epudaily_date.to_csv('epu2016_en.csv')


