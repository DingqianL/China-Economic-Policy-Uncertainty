# -*- coding: utf-8 -*-
"""
Created on Sat Sep  1 00:22:58 2018

@author: dingq
"""

##将txt文件存入dataframe中,先对全国性报纸
#import modules
import os
import pandas as pd
#set the target path
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\policy trade'
#get all the year folder in the target folder
files=os.listdir(path)
files=[f for f in files if f.endswith('.txt')]

#generate empty dataframe and list
dataframe=pd.DataFrame()
years=[]
texts=[]

#iteration to analyze files for all national text files
for j in files:             #iteration to get title for each article
    file=path+'\\'+j           #get the path for each article
    year=j[:4]
        #read one text file and delete all spaces and line change
    with open(file, errors='ignore') as f:
        text=f.read()           #read one file 
        text=text.replace(' ', '')
        text=text.replace('\n', '')
        #put article in each corespondense list
    years.append(year)
    texts.append(text)

#put the list in the data frame
dataframe['year']=years
dataframe['text']=texts
os.chdir(path)
dataframe.to_excel('trade 2006_2016 raw.xlsx', encoding='utf8')

    
###others example    
import pandas as pd
import jieba
import jieba.analyse

#设置pd的显示长度
#pd.set_option('max_colwidth',500)

segments = []
for i in texts:
    #TextRank 关键词抽取，只获取固定词性
    words = jieba.analyse.extract_tags(i, topK=20,withWeight=False,allowPOS=('ns', 'n', 'vn', 'v'))
    for word in words:
        # 记录全局分词
        segments.append({'word':word,'count':1})
    
counts = pd.DataFrame(segments)
counts = counts.groupby('word').sum()
counts.to_excel('trade policy_keywords.xlsx',encoding='utf8')
