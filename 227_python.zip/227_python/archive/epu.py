# -*- coding: utf-8 -*-
"""
Created on Fri Oct 12 15:06:31 2018

@author: dingq
"""
import re
import os
import pandas as pd
import rexepu
import datetime
from datetime import timedelta

def epu1(file):
    with open(file,'r+',errors='ignore') as f:
        text=f.read()
    text=text.replace(' ', '') #delete space
    text=text.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
    datepattern=re.compile(r'\d{4}\.\d{2}\.\d{2}')
    match = re.split(datepattern, text) #split into single article
    del match[0]

    dateextract=re.findall(datepattern,text) #identify dates
    date=[i.replace('.','-') for i in dateextract] #formalize date

##to make sure the #of text matches that of date
    if len(match)!=len(date):
        print('Split Error!')
    else:
        print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
 #       texts=f.write(match[m])
  #  m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
    articlelist=pd.DataFrame(data=match, index=date)
    articlelist['date']=date

# save count of keywords into DataFrame
    u1=rexepu.keywords(match,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(match,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(match,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(match,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(match,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(match,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(match,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(match,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(match,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(match,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(match,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(match,rexepu.pe2)
    articlelist['e2']=e2

    p1 =rexepu.keywords(match,rexepu.pp1)
    articlelist['p1']=p1
    p2 =rexepu.keywords(match,rexepu.pp2)
    articlelist['p2']=p2
    p3 =rexepu.keywords(match,rexepu.pp3)
    articlelist['p3']=p3
    p4 =rexepu.keywords(match,rexepu.pp4)
    articlelist['p4']=p4
    p5 =rexepu.keywords(match,rexepu.pp5)
    articlelist['p5']=p5
    p6 =rexepu.keywords(match,rexepu.pp6)
    articlelist['p6']=p6
    p7 =rexepu.keywords(match,rexepu.pp7)
    articlelist['p7']=p7
    p8 =rexepu.keywords(match,rexepu.pp8)
    articlelist['p8']=p8
    p9 =rexepu.keywords(match,rexepu.pp9)
    articlelist['p9']=p9
    p10 =rexepu.keywords(match,rexepu.pp10)
    articlelist['p10']=p10
    p11 =rexepu.keywords(match,rexepu.pp11)
    articlelist['p11']=p11
    p12 =rexepu.keywords(match,rexepu.pp12)
    articlelist['p12']=p12
    p13 =rexepu.keywords(match,rexepu.pp13)
    articlelist['p13']=p13
    p14 =rexepu.keywords(match,rexepu.pp14)
    articlelist['p14']=p14
    p15 =rexepu.keywords(match,rexepu.pp15)
    articlelist['p15']=p15
    p16 =rexepu.keywords(match,rexepu.pp16)
    articlelist['p16']=p16
    p17 =rexepu.keywords(match,rexepu.pp17)
    articlelist['p17']=p17
    p18 =rexepu.keywords(match,rexepu.pp18)
    articlelist['p18']=p18
    p19 =rexepu.keywords(match,rexepu.pp19)
    articlelist['p19']=p19

    
###generate index epu
    u=[]
    e=[]
    p=[]

    for i in range(len(match)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(match)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(match)):        
        if p1[i]>0 or \
           p2[i]>0 or \
           p3[i]>0 or \
           p4[i]>0 or \
           p5[i]>0 or \
           p6[i]>0 or \
           p7[i]>0 or \
           p8[i]>0 or \
           p9[i]>0 or \
           p10[i]>0 or \
           p11[i]>0 or \
           p12[i]>0 or \
           p13[i]>0 or \
           p14[i]>0 or \
           p15[i]>0 or \
           p16[i]>0 or \
           p17[i]>0 or \
           p18[i]>0 or \
           p19[i]>0:
               p0=1
               p.append(p0)
        else:
            p0=0
            p.append(p0)

         
    epu=[]
    for i in range(len(match)):  
        if u[i]>0 and e[i]>0 and p[i]>0:
            epu0=1
            epu.append(epu0)
        else:
            epu0=0
            epu.append(epu0)
 
    if len(e)==len(p)==len(u)==len(epu)==len(match)==len(date):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['p']=p
    articlelist['u']=u
    articlelist['epu']=epu

    articlelist=articlelist.rename(columns={0:'match'})
    epu_test=articlelist.filter(['date','epu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(10)


    epudaily['epu_count']=epudaily['epu']/epudaily['count']
    epudaily['epu_econ']=epudaily['epu']/epudaily['e']

    epudaily.head(10)
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\epu'
    epudaily.to_csv(os.path.join(path3,'epudaily'+file[:4]+'.csv'))

##############################################################
##this function is designed for rmrb2007-2016
def epu2(file):
    with open(file,'r', encoding = 'utf8', errors='ignore') as f:
        text=f.read()
    text=text.replace(' ', '') #delete space
    text=text.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
    datepattern=re.compile(r'\d{4}\-\d{2}\-\d{2}')
    match = re.split(datepattern, text) #split into single article
    del match[0]

    date=re.findall(datepattern,text) #identify dates

##to make sure the #of text matches that of date
    if len(match)!=len(date):
        print('Split Error!')
    else:
        print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
#        texts=f.write(match[m])
#    m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
    articlelist=pd.DataFrame(data=match, index=date)
    articlelist.info() 
    articlelist['date']=date

##compile key words

# save count of keywords into DataFrame
    u1=rexepu.keywords(match,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(match,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(match,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(match,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(match,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(match,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(match,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(match,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(match,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(match,rexepu.pu10)
    articlelist['u10']=u10

#e1=keywords(match,pe1)
#articlelist['e1']=e1
#e2=keywords(match,pe2)
#articlelist['e2']=e2

    p1 =rexepu.keywords(match,rexepu.pp1)
    articlelist['p1']=p1
    p2 =rexepu.keywords(match,rexepu.pp2)
    articlelist['p2']=p2
    p3 =rexepu.keywords(match,rexepu.pp3)
    articlelist['p3']=p3
    p4 =rexepu.keywords(match,rexepu.pp4)
    articlelist['p4']=p4
    p5 =rexepu.keywords(match,rexepu.pp5)
    articlelist['p5']=p5
    p6 =rexepu.keywords(match,rexepu.pp6)
    articlelist['p6']=p6
    p7 =rexepu.keywords(match,rexepu.pp7)
    articlelist['p7']=p7
    p8 =rexepu.keywords(match,rexepu.pp8)
    articlelist['p8']=p8
    p9 =rexepu.keywords(match,rexepu.pp9)
    articlelist['p9']=p9
    p10 =rexepu.keywords(match,rexepu.pp10)
    articlelist['p10']=p10
    p11 =rexepu.keywords(match,rexepu.pp11)
    articlelist['p11']=p11
    p12 =rexepu.keywords(match,rexepu.pp12)
    articlelist['p12']=p12
    p13 =rexepu.keywords(match,rexepu.pp13)
    articlelist['p13']=p13
    p14 =rexepu.keywords(match,rexepu.pp14)
    articlelist['p14']=p14
    p15 =rexepu.keywords(match,rexepu.pp15)
    articlelist['p15']=p15
    p16 =rexepu.keywords(match,rexepu.pp16)
    articlelist['p16']=p16
    p17 =rexepu.keywords(match,rexepu.pp17)
    articlelist['p17']=p17
    p18 =rexepu.keywords(match,rexepu.pp18)
    articlelist['p18']=p18
    p19 =rexepu.keywords(match,rexepu.pp19)
    articlelist['p19']=p19    
###generate index epu
    u=[]
    p=[]

    for i in range(len(match)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)           
        else:
            u0=0
            u.append(u0)
        
    for i in range(len(match)):        
        if p1[i]>0 or \
           p2[i]>0 or \
           p3[i]>0 or \
           p4[i]>0 or \
           p5[i]>0 or \
           p6[i]>0 or \
           p7[i]>0 or \
           p8[i]>0 or \
           p9[i]>0 or \
           p10[i]>0 or \
           p11[i]>0 or \
           p12[i]>0 or \
           p13[i]>0 or \
           p14[i]>0 or \
           p15[i]>0 or \
           p16[i]>0 or \
           p17[i]>0 or \
           p18[i]>0 or \
           p19[i]:
               p0=1
               p.append(p0)
        else:
            p0=0
            p.append(p0)

         
    epu=[]
    for i in range(len(match)):  
        if u[i]>0 and p[i]>0:
            epu0=1
            epu.append(epu0)
        else:
            epu0=0
            epu.append(epu0)
 

    if len(p)==len(u)==len(epu)==len(match)==len(date):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['p']=p
    articlelist['u']=u
    articlelist['epu']=epu

    articlelist=articlelist.rename(columns={0:'match'})
    articlelist.columns

    epu_test=articlelist.filter(['date','epu'],axis=1)
    epu_test.count()
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.count()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'e'})
    epudaily.head(10)
    epudaily.count

##generate correct list of date
    
    d1 = datetime.datetime(int(file[:4]), 1, 1)  # start date
    d2 = datetime.datetime(int(file[:4]), 12, 31)  # end date

    delta = d2 - d1         # timedelta

    datelist=[]
    for i in range(delta.days + 1):
        a=d1 + timedelta(i)
        datelist.append(a)

    date_form=[]
    for i in datelist:
        aaa=i.strftime('%Y-%m-%d')
        date_form.append(aaa)

    date_frame=pd.DataFrame(data=date_form, index=date_form)
    date_frame=date_frame.rename(columns={0:'date'})
    date_frame.head(10)

###
    epudaily_date=pd.concat([epudaily, date_frame], axis=1)
    epudaily_date=epudaily_date.fillna(0)
    epudaily_date.head(25)
    epudaily_date.count

    a_count=pd.read_csv(file[:4]+'article.csv')
    a_count_n=a_count['count']
    a_count_n1=a_count_n.tolist()
    epudaily_date['count']=a_count_n1
    epudaily_date.head(25)


    epudaily_date.drop('date', axis=1, inplace=True)
    epudaily_date.head(10)
    epudaily_date['epu_count']=epudaily_date['epu']/epudaily_date['count']
    epudaily_date['epu_econ']=epudaily_date['epu']/epudaily_date['e']

    epudaily_date.tail(10)
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\epu'
    epudaily_date.to_csv(os.path.join(path3,'epudaily'+file[:4]+'.csv'))


####this function is for 2017-2018
    
def epu3(folders,path0):
    date=folders #the folder of each date, there are 365 folders named after date
    counts=[]
    articles0=[]
    for i in folders:
        path1=os.path.join(path0,i) #path of each date
        artic=os.listdir(path1) #count the number of articles for each date
       # os.chdir(path1)
        count=len(artic)
        counts.append(count)
        articles=[]
        for j in artic:
            path2=os.path.join(path1,j) #path of each article within certain date
            with open (path2, 'r+', encoding='utf-8',errors='ignore') as f:
                article=f.read()
                article=article.replace(' ', '')
                article=article.replace('\n','')
                articles.append(article)
        articles0.append(articles)

## count the dates
    dates=[[f] for f in date]
    cous=[]
    for i in articles0:
        cou=len(i)
        cous.append(cou)

    dates0=[a*b for a,b in zip(dates,cous)]
    flat_articles = [item for sublist in articles0 for item in sublist]
    flat_dates = [item for sublist in dates0 for item in sublist]
 
    articlelist=pd.DataFrame(data=flat_articles, index=flat_dates)
    articlelist['date']=flat_dates
   

# save count of keywords into DataFrame
    u1=rexepu.keywords(flat_articles,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(flat_articles,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(flat_articles,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(flat_articles,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(flat_articles,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(flat_articles,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(flat_articles,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(flat_articles,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(flat_articles,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(flat_articles,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(flat_articles,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(flat_articles,rexepu.pe2)
    articlelist['e2']=e2

    p1 =rexepu.keywords(flat_articles,rexepu.pp1)
    articlelist['p1']=p1
    p2 =rexepu.keywords(flat_articles,rexepu.pp2)
    articlelist['p2']=p2
    p3 =rexepu.keywords(flat_articles,rexepu.pp3)
    articlelist['p3']=p3
    p4 =rexepu.keywords(flat_articles,rexepu.pp4)
    articlelist['p4']=p4
    p5 =rexepu.keywords(flat_articles,rexepu.pp5)
    articlelist['p5']=p5
    p6 =rexepu.keywords(flat_articles,rexepu.pp6)
    articlelist['p6']=p6
    p7 =rexepu.keywords(flat_articles,rexepu.pp7)
    articlelist['p7']=p7
    p8 =rexepu.keywords(flat_articles,rexepu.pp8)
    articlelist['p8']=p8
    p9 =rexepu.keywords(flat_articles,rexepu.pp9)
    articlelist['p9']=p9
    p10 =rexepu.keywords(flat_articles,rexepu.pp10)
    articlelist['p10']=p10
    p11 =rexepu.keywords(flat_articles,rexepu.pp11)
    articlelist['p11']=p11
    p12 =rexepu.keywords(flat_articles,rexepu.pp12)
    articlelist['p12']=p12
    p13 =rexepu.keywords(flat_articles,rexepu.pp13)
    articlelist['p13']=p13
    p14 =rexepu.keywords(flat_articles,rexepu.pp14)
    articlelist['p14']=p14
    p15 =rexepu.keywords(flat_articles,rexepu.pp15)
    articlelist['p15']=p15
    p16 =rexepu.keywords(flat_articles,rexepu.pp16)
    articlelist['p16']=p16
    p17 =rexepu.keywords(flat_articles,rexepu.pp17)
    articlelist['p17']=p17
    p18 =rexepu.keywords(flat_articles,rexepu.pp18)
    articlelist['p18']=p18
    p19 =rexepu.keywords(flat_articles,rexepu.pp19)
    articlelist['p19']=p19

    
###generate index epu
    u=[]
    e=[]
    p=[]

    for i in range(len(flat_articles)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(flat_articles)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(flat_articles)):        
        if p1[i]>0 or \
           p2[i]>0 or \
           p3[i]>0 or \
           p4[i]>0 or \
           p5[i]>0 or \
           p6[i]>0 or \
           p7[i]>0 or \
           p8[i]>0 or \
           p9[i]>0 or \
           p10[i]>0 or \
           p11[i]>0 or \
           p12[i]>0 or \
           p13[i]>0 or \
           p14[i]>0 or \
           p15[i]>0 or \
           p16[i]>0 or \
           p17[i]>0 or \
           p18[i]>0 or \
           p19[i]>0:
               p0=1
               p.append(p0)
        else:
            p0=0
            p.append(p0)

         
    epu=[]
    for i in range(len(flat_articles)):  
        if u[i]>0 and e[i]>0 and p[i]>0:
            epu0=1
            epu.append(epu0)
        else:
            epu0=0
            epu.append(epu0)
 


    if len(e)==len(p)==len(u)==len(epu)==len(flat_articles)==len(flat_dates):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['p']=p
    articlelist['u']=u
    articlelist['epu']=epu

    articlelist=articlelist.rename(columns={0:'match'})
   # path1=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
  #  path2=path1+'\\'+'all_epu'+year+'.xlsx'

    #articlelist.to_excel(path2,encoding='utf8')

    epu_test=articlelist.filter(['date','epu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(5)
    epudaily.count()

#change date format
    epudaily['date']=epudaily.index
    epudaily['date']=pd.to_datetime(epudaily['date'], format='%Y%m%d').dt.strftime("%m/%d/%Y")
#epudaily.drop('date', axis=1, inplace=True)
    epudaily.head(10)
    epudaily['epu_count']=epudaily['epu']/epudaily['count']
    epudaily['epu_econ']=epudaily['epu']/epudaily['e']

#os.makedirs(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\csv')
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\epu'
    epudaily.to_csv(os.path.join(path3,'epudaily'+folders[0][:4]+'.csv'))

####this function is for GMRB 2008-2017
    
def epu4(folders,path0):
    date=folders #the folder of each date, there are 365 folders named after date
    counts=[]
    articles0=[]
    for i in folders:
        path1=os.path.join(path0,i) #path of each date
        artic=os.listdir(path1) #count the number of articles for each date
       # os.chdir(path1)
        count=len(artic)
        counts.append(count)
        articles=[]
        for j in artic:
            path2=os.path.join(path1,j) #path of each article within certain date
            with open (path2, 'r+', encoding='utf-8',errors='ignore') as f:
                article=f.read()
                article=article.replace(' ', '')
                article=article.replace('\n','')
                articles.append(article)
        articles0.append(articles)

## count the dates
    dates=[[f] for f in date]
    cous=[]
    for i in articles0:
        cou=len(i)
        cous.append(cou)

    dates0=[a*b for a,b in zip(dates,cous)]
    flat_articles = [item for sublist in articles0 for item in sublist]
    flat_dates = [item for sublist in dates0 for item in sublist]
 
    articlelist=pd.DataFrame(data=flat_articles, index=flat_dates)
    articlelist['date']=flat_dates
   

# save count of keywords into DataFrame
    u1=rexepu.keywords(flat_articles,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(flat_articles,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(flat_articles,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(flat_articles,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(flat_articles,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(flat_articles,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(flat_articles,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(flat_articles,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(flat_articles,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(flat_articles,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(flat_articles,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(flat_articles,rexepu.pe2)
    articlelist['e2']=e2

    p1 =rexepu.keywords(flat_articles,rexepu.pp1)
    articlelist['p1']=p1
    p2 =rexepu.keywords(flat_articles,rexepu.pp2)
    articlelist['p2']=p2
    p3 =rexepu.keywords(flat_articles,rexepu.pp3)
    articlelist['p3']=p3
    p4 =rexepu.keywords(flat_articles,rexepu.pp4)
    articlelist['p4']=p4
    p5 =rexepu.keywords(flat_articles,rexepu.pp5)
    articlelist['p5']=p5
    p6 =rexepu.keywords(flat_articles,rexepu.pp6)
    articlelist['p6']=p6
    p7 =rexepu.keywords(flat_articles,rexepu.pp7)
    articlelist['p7']=p7
    p8 =rexepu.keywords(flat_articles,rexepu.pp8)
    articlelist['p8']=p8
    p9 =rexepu.keywords(flat_articles,rexepu.pp9)
    articlelist['p9']=p9
    p10 =rexepu.keywords(flat_articles,rexepu.pp10)
    articlelist['p10']=p10
    p11 =rexepu.keywords(flat_articles,rexepu.pp11)
    articlelist['p11']=p11
    p12 =rexepu.keywords(flat_articles,rexepu.pp12)
    articlelist['p12']=p12
    p13 =rexepu.keywords(flat_articles,rexepu.pp13)
    articlelist['p13']=p13
    p14 =rexepu.keywords(flat_articles,rexepu.pp14)
    articlelist['p14']=p14
    p15 =rexepu.keywords(flat_articles,rexepu.pp15)
    articlelist['p15']=p15
    p16 =rexepu.keywords(flat_articles,rexepu.pp16)
    articlelist['p16']=p16
    p17 =rexepu.keywords(flat_articles,rexepu.pp17)
    articlelist['p17']=p17
    p18 =rexepu.keywords(flat_articles,rexepu.pp18)
    articlelist['p18']=p18
    p19 =rexepu.keywords(flat_articles,rexepu.pp19)
    articlelist['p19']=p19

    
###generate index epu
    u=[]
    e=[]
    p=[]

    for i in range(len(flat_articles)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(flat_articles)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(flat_articles)):        
        if p1[i]>0 or \
           p2[i]>0 or \
           p3[i]>0 or \
           p4[i]>0 or \
           p5[i]>0 or \
           p6[i]>0 or \
           p7[i]>0 or \
           p8[i]>0 or \
           p9[i]>0 or \
           p10[i]>0 or \
           p11[i]>0 or \
           p12[i]>0 or \
           p13[i]>0 or \
           p14[i]>0 or \
           p15[i]>0 or \
           p16[i]>0 or \
           p17[i]>0 or \
           p18[i]>0 or \
           p19[i]>0:
               p0=1
               p.append(p0)
        else:
            p0=0
            p.append(p0)

         
    epu=[]
    for i in range(len(flat_articles)):  
        if u[i]>0 and e[i]>0 and p[i]>0:
            epu0=1
            epu.append(epu0)
        else:
            epu0=0
            epu.append(epu0)
 


    if len(e)==len(p)==len(u)==len(epu)==len(flat_articles)==len(flat_dates):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['p']=p
    articlelist['u']=u
    articlelist['epu']=epu

    articlelist=articlelist.rename(columns={0:'match'})
   # path1=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
  #  path2=path1+'\\'+'all_epu'+year+'.xlsx'

    #articlelist.to_excel(path2,encoding='utf8')

    epu_test=articlelist.filter(['date','epu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(5)
    epudaily.count()

#change date format
    epudaily['date']=epudaily.index
    epudaily['date']=pd.to_datetime(epudaily['date'], format='%Y%m%d').dt.strftime("%m/%d/%Y")
#epudaily.drop('date', axis=1, inplace=True)
    epudaily.head(10)
    epudaily['epu_count']=epudaily['epu']/epudaily['count']
    epudaily['epu_econ']=epudaily['epu']/epudaily['e']

#os.makedirs(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\csv')
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\epu'
    epudaily.to_csv(os.path.join(path3,'epudaily'+folders[0][:4]+'.csv'))


def tpu1(file):
    with open(file,'r+', encoding='utf8', errors='ignore') as f:
        text=f.read()
    text=text.replace(' ', '') #delete space
    text=text.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
    datepattern=re.compile(r'\d{4}\.\d{2}\.\d{2}')
    match = re.split(datepattern, text) #split into single article
    del match[0]

    dateextract=re.findall(datepattern,text) #identify dates
    date=[i.replace('.','-') for i in dateextract] #formalize date

##to make sure the #of text matches that of date
    if len(match)!=len(date):
        print('Split Error!')
    else:
        print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
 #       texts=f.write(match[m])
  #  m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
    articlelist=pd.DataFrame(data=match, index=date)
    articlelist['date']=date

# save count of keywords into DataFrame
    u1=rexepu.keywords(match,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(match,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(match,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(match,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(match,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(match,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(match,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(match,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(match,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(match,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(match,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(match,rexepu.pe2)
    articlelist['e2']=e2

    t1 =rexepu.keywords(match,rexepu.tp1)
    articlelist['t1']=t1
    t2 =rexepu.keywords(match,rexepu.tp2)
    articlelist['t2']=t2
    t3 =rexepu.keywords(match,rexepu.tp3)
    articlelist['t3']=t3
    t4 =rexepu.keywords(match,rexepu.tp4)
    articlelist['t4']=t4
    t5 =rexepu.keywords(match,rexepu.tp5)
    articlelist['t5']=t5
    t6 =rexepu.keywords(match,rexepu.tp6)
    articlelist['t6']=t6
    t7 =rexepu.keywords(match,rexepu.tp7)
    articlelist['t7']=t7
    t8 =rexepu.keywords(match,rexepu.tp8)
    articlelist['t8']=t8
    t9 =rexepu.keywords(match,rexepu.tp9)
    articlelist['t9']=t9
    t10 =rexepu.keywords(match,rexepu.tp10)
    articlelist['t10']=t10
    t11 =rexepu.keywords(match,rexepu.tp11)
    articlelist['t11']=t11
    t12 =rexepu.keywords(match,rexepu.tp12)
    articlelist['t12']=t12
    t13 =rexepu.keywords(match,rexepu.tp13)
    articlelist['t13']=t13
    t14 =rexepu.keywords(match,rexepu.tp14)
    articlelist['t14']=t14
    t15 =rexepu.keywords(match,rexepu.tp15)
    articlelist['t15']=t15
    t16 =rexepu.keywords(match,rexepu.tp16)
    articlelist['t16']=t16
    t17 =rexepu.keywords(match,rexepu.tp17)
    articlelist['t17']=t17
    t18 =rexepu.keywords(match,rexepu.tp18)
    articlelist['t18']=t18
    t19 =rexepu.keywords(match,rexepu.tp19)
    articlelist['t19']=t19
    t20 =rexepu.keywords(match,rexepu.tp20)
    articlelist['t20']=t20
    
###generate index epu
    u=[]
    e=[]
    t=[]

    for i in range(len(match)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(match)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(match)):        
        if t1[i]>0 or \
           t2[i]>0 or \
           t3[i]>0 or \
           t4[i]>0 or \
           t5[i]>0 or \
           t6[i]>0 or \
           t7[i]>0 or \
           t8[i]>0 or \
           t9[i]>0 or \
           t10[i]>0 or \
           t11[i]>0 or \
           t12[i]>0 or \
           t13[i]>0 or \
           t14[i]>0 or \
           t15[i]>0 or \
           t16[i]>0 or \
           t17[i]>0 or \
           t19[i]>0 or \
           t18[i]>0 or \
           t20[i]>0:
               t0=1
               t.append(t0)
        else:
            t0=0
            t.append(t0)

         
    tpu=[]
    for i in range(len(match)):  
        if u[i]>0 and e[i]>0 and t[i]>0:
            tpu0=1
            tpu.append(tpu0)
        else:
            tpu0=0
            tpu.append(tpu0)
 
    if len(e)==len(t)==len(u)==len(tpu)==len(match)==len(date):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['t']=t
    articlelist['u']=u
    articlelist['tpu']=tpu

    articlelist=articlelist.rename(columns={0:'match'})
    epu_test=articlelist.filter(['date','tpu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(10)


    epudaily['tpu_count']=epudaily['tpu']/epudaily['count']
    epudaily['tpu_econ']=epudaily['tpu']/epudaily['e']

    epudaily.head(10)
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu'
    epudaily.to_csv(os.path.join(path3,'tpudaily'+file[:4]+'.csv'))

##############################################################
##this function is designed for rmrb2007-2016
def tpu2(file):
    with open(file,'r', encoding = 'utf8', errors='ignore') as f:
        text=f.read()
    text=text.replace(' ', '') #delete space
    text=text.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
    datepattern=re.compile(r'\d{4}\-\d{2}\-\d{2}')
    match = re.split(datepattern, text) #split into single article
    del match[0]

    date=re.findall(datepattern,text) #identify dates

##to make sure the #of text matches that of date
    if len(match)!=len(date):
        print('Split Error!')
    else:
        print('Congrats, no error in splitting!')

#the original file contains all the text in one txt file, I split them into independent txt files
#m=0
#while m<len(match):
#    if m<10:
#        n='00'+str(m)
#    elif 10<=m<100:
#        n='0'+str(m)
#    else:
#        n=str(m)
#    with open(date[m]+'-'+n+'.txt','w') as f:
#        texts=f.write(match[m])
#    m=m+1


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
    articlelist=pd.DataFrame(data=match, index=date)
    articlelist.info() 
    articlelist['date']=date

##compile key words

# save count of keywords into DataFrame
    u1=rexepu.keywords(match,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(match,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(match,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(match,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(match,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(match,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(match,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(match,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(match,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(match,rexepu.pu10)
    articlelist['u10']=u10

#e1=keywords(match,pe1)
#articlelist['e1']=e1
#e2=keywords(match,pe2)
#articlelist['e2']=e2

    t1 =rexepu.keywords(match,rexepu.tp1)
    articlelist['t1']=t1
    t2 =rexepu.keywords(match,rexepu.tp2)
    articlelist['t2']=t2
    t3 =rexepu.keywords(match,rexepu.tp3)
    articlelist['t3']=t3
    t4 =rexepu.keywords(match,rexepu.tp4)
    articlelist['t4']=t4
    t5 =rexepu.keywords(match,rexepu.tp5)
    articlelist['t5']=t5
    t6 =rexepu.keywords(match,rexepu.tp6)
    articlelist['t6']=t6
    t7 =rexepu.keywords(match,rexepu.tp7)
    articlelist['t7']=t7
    t8 =rexepu.keywords(match,rexepu.tp8)
    articlelist['t8']=t8
    t9 =rexepu.keywords(match,rexepu.tp9)
    articlelist['t9']=t9
    t10 =rexepu.keywords(match,rexepu.tp10)
    articlelist['t10']=t10
    t11 =rexepu.keywords(match,rexepu.tp11)
    articlelist['t11']=t11
    t12 =rexepu.keywords(match,rexepu.tp12)
    articlelist['t12']=t12
    t13 =rexepu.keywords(match,rexepu.tp13)
    articlelist['t13']=t13
    t14 =rexepu.keywords(match,rexepu.tp14)
    articlelist['t14']=t14
    t15 =rexepu.keywords(match,rexepu.tp15)
    articlelist['t15']=t15
    t16 =rexepu.keywords(match,rexepu.tp16)
    articlelist['t16']=t16
    t17 =rexepu.keywords(match,rexepu.tp17)
    articlelist['t17']=t17
    t18 =rexepu.keywords(match,rexepu.tp18)
    articlelist['t18']=t18
    t19 =rexepu.keywords(match,rexepu.tp19)
    articlelist['t19']=t19
    t20 =rexepu.keywords(match,rexepu.tp20)
    articlelist['t20']=t20
    
###generate index epu
    u=[]
    t=[]

    for i in range(len(match)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)           
        else:
            u0=0
            u.append(u0)
        
    for i in range(len(match)):        
        if t1[i]>0 or \
           t2[i]>0 or \
           t3[i]>0 or \
           t4[i]>0 or \
           t5[i]>0 or \
           t6[i]>0 or \
           t7[i]>0 or \
           t8[i]>0 or \
           t9[i]>0 or \
           t10[i]>0 or \
           t11[i]>0 or \
           t12[i]>0 or \
           t13[i]>0 or \
           t14[i]>0 or \
           t15[i]>0 or \
           t16[i]>0 or \
           t17[i]>0 or \
           t18[i]>0 or \
           t19[i]>0 or \
           t20[i]:
               t0=1
               t.append(t0)
        else:
            t0=0
            t.append(t0)

         
    tpu=[]
    for i in range(len(match)):  
        if u[i]>0 and t[i]>0:
            tpu0=1
            tpu.append(tpu0)
        else:
            tpu0=0
            tpu.append(tpu0)
 

    if len(t)==len(u)==len(tpu)==len(match)==len(date):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['t']=p
    articlelist['u']=u
    articlelist['tpu']=tpu

    articlelist=articlelist.rename(columns={0:'match'})
    articlelist.columns

    epu_test=articlelist.filter(['date','tpu'],axis=1)
    epu_test.count()
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.count()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'e'})
    epudaily.head(10)
    epudaily.count

##generate correct list of date
    
    d1 = datetime.datetime(int(file[:4]), 1, 1)  # start date
    d2 = datetime.datetime(int(file[:4]), 12, 31)  # end date

    delta = d2 - d1         # timedelta

    datelist=[]
    for i in range(delta.days + 1):
        a=d1 + timedelta(i)
        datelist.append(a)

    date_form=[]
    for i in datelist:
        aaa=i.strftime('%Y-%m-%d')
        date_form.append(aaa)

    date_frame=pd.DataFrame(data=date_form, index=date_form)
    date_frame=date_frame.rename(columns={0:'date'})
    date_frame.head(10)

###
    epudaily_date=pd.concat([epudaily, date_frame], axis=1)
    epudaily_date=epudaily_date.fillna(0)
    epudaily_date.head(25)
    epudaily_date.count

    a_count=pd.read_csv(file[:4]+'article.csv')
    a_count_n=a_count['count']
    a_count_n1=a_count_n.tolist()
    epudaily_date['count']=a_count_n1
    epudaily_date.head(25)


    epudaily_date.drop('date', axis=1, inplace=True)
    epudaily_date.head(10)
    epudaily_date['tpu_count']=epudaily_date['tpu']/epudaily_date['count']
    epudaily_date['tpu_econ']=epudaily_date['tpu']/epudaily_date['e']

    epudaily_date.tail(10)
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu'
    epudaily_date.to_csv(os.path.join(path3,'tpudaily'+file[:4]+'.csv'))


####this function is for 2017-2018
    
def tpu3(folders,path0):
    date=folders #the folder of each date, there are 365 folders named after date
    counts=[]
    articles0=[]
    for i in folders:
        path1=os.path.join(path0,i) #path of each date
        artic=os.listdir(path1) #count the number of articles for each date
       # os.chdir(path1)
        count=len(artic)
        counts.append(count)
        articles=[]
        for j in artic:
            path2=os.path.join(path1,j) #path of each article within certain date
            with open (path2, 'r+', encoding='utf-8',errors='ignore') as f:
                article=f.read()
                article=article.replace(' ', '')
                article=article.replace('\n','')
                articles.append(article)
        articles0.append(articles)

## count the dates
    dates=[[f] for f in date]
    cous=[]
    for i in articles0:
        cou=len(i)
        cous.append(cou)

    dates0=[a*b for a,b in zip(dates,cous)]
    flat_articles = [item for sublist in articles0 for item in sublist]
    flat_dates = [item for sublist in dates0 for item in sublist]
 
    articlelist=pd.DataFrame(data=flat_articles, index=flat_dates)
    articlelist['date']=flat_dates
   

# save count of keywords into DataFrame
    u1=rexepu.keywords(flat_articles,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(flat_articles,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(flat_articles,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(flat_articles,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(flat_articles,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(flat_articles,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(flat_articles,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(flat_articles,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(flat_articles,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(flat_articles,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(flat_articles,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(flat_articles,rexepu.pe2)
    articlelist['e2']=e2

    t1 =rexepu.keywords(flat_articles,rexepu.tp1)
    articlelist['t1']=t1
    t2 =rexepu.keywords(flat_articles,rexepu.tp2)
    articlelist['t2']=t2
    t3 =rexepu.keywords(flat_articles,rexepu.tp3)
    articlelist['t3']=t3
    t4 =rexepu.keywords(flat_articles,rexepu.tp4)
    articlelist['t4']=t4
    t5 =rexepu.keywords(flat_articles,rexepu.tp5)
    articlelist['t5']=t5
    t6 =rexepu.keywords(flat_articles,rexepu.tp6)
    articlelist['t6']=t6
    t7 =rexepu.keywords(flat_articles,rexepu.tp7)
    articlelist['t7']=t7
    t8 =rexepu.keywords(flat_articles,rexepu.tp8)
    articlelist['t8']=t8
    t9 =rexepu.keywords(flat_articles,rexepu.tp9)
    articlelist['t9']=t9
    t10 =rexepu.keywords(flat_articles,rexepu.tp10)
    articlelist['t10']=t10
    t11 =rexepu.keywords(flat_articles,rexepu.tp11)
    articlelist['t11']=t11
    t12 =rexepu.keywords(flat_articles,rexepu.tp12)
    articlelist['t12']=t12
    t13 =rexepu.keywords(flat_articles,rexepu.tp13)
    articlelist['t13']=t13
    t14 =rexepu.keywords(flat_articles,rexepu.tp14)
    articlelist['t14']=t14
    t15 =rexepu.keywords(flat_articles,rexepu.tp15)
    articlelist['t15']=t15
    t16 =rexepu.keywords(flat_articles,rexepu.tp16)
    articlelist['t16']=t16
    t17 =rexepu.keywords(flat_articles,rexepu.tp17)
    articlelist['t17']=t17
    t18 =rexepu.keywords(flat_articles,rexepu.tp18)
    articlelist['t18']=t18
    t19 =rexepu.keywords(flat_articles,rexepu.tp19)
    articlelist['t19']=t19
    t20 =rexepu.keywords(flat_articles,rexepu.tp20)
    articlelist['t20']=t20
    
###generate index epu
    u=[]
    e=[]
    t=[]

    for i in range(len(flat_articles)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(flat_articles)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(flat_articles)):        
        if t1[i]>0 or \
           t2[i]>0 or \
           t3[i]>0 or \
           t4[i]>0 or \
           t5[i]>0 or \
           t6[i]>0 or \
           t7[i]>0 or \
           t8[i]>0 or \
           t9[i]>0 or \
           t10[i]>0 or \
           t11[i]>0 or \
           t12[i]>0 or \
           t13[i]>0 or \
           t14[i]>0 or \
           t15[i]>0 or \
           t16[i]>0 or \
           t17[i]>0 or \
           t18[i]>0 or \
           t19[i]>0 or \
           t20[i]>0:
               t0=1
               t.append(t0)
        else:
            t0=0
            t.append(t0)

         
    tpu=[]
    for i in range(len(flat_articles)):  
        if u[i]>0 and e[i]>0 and t[i]>0:
            tpu0=1
            tpu.append(tpu0)
        else:
            tpu0=0
            tpu.append(tpu0)
 


    if len(e)==len(t)==len(u)==len(tpu)==len(flat_articles)==len(flat_dates):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['t']=t
    articlelist['u']=u
    articlelist['tpu']=tpu

    articlelist=articlelist.rename(columns={0:'match'})
   # path1=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
  #  path2=path1+'\\'+'all_epu'+year+'.xlsx'

    #articlelist.to_excel(path2,encoding='utf8')

    epu_test=articlelist.filter(['date','tpu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(5)
    epudaily.count()

#change date format
    epudaily['date']=epudaily.index
    epudaily['date']=pd.to_datetime(epudaily['date'], format='%Y%m%d').dt.strftime("%m/%d/%Y")
#epudaily.drop('date', axis=1, inplace=True)
    epudaily.head(10)
    epudaily['tpu_count']=epudaily['tpu']/epudaily['count']
    epudaily['tpu_econ']=epudaily['tpu']/epudaily['e']

#os.makedirs(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\csv')
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu'
    epudaily.to_csv(os.path.join(path3,'tpudaily'+folders[0][:4]+'.csv'))

####this function is for GMRB 2008-2017
    
def tpu4(folders,path0):
    date=folders #the folder of each date, there are 365 folders named after date
    counts=[]
    articles0=[]
    for i in folders:
        path1=os.path.join(path0,i) #path of each date
        artic=os.listdir(path1) #count the number of articles for each date
       # os.chdir(path1)
        count=len(artic)
        counts.append(count)
        articles=[]
        for j in artic:
            path2=os.path.join(path1,j) #path of each article within certain date
            with open (path2, 'r+', encoding='utf-8',errors='ignore') as f:
                article=f.read()
                article=article.replace(' ', '')
                article=article.replace('\n','')
                articles.append(article)
        articles0.append(articles)

## count the dates
    dates=[[f] for f in date]
    cous=[]
    for i in articles0:
        cou=len(i)
        cous.append(cou)

    dates0=[a*b for a,b in zip(dates,cous)]
    flat_articles = [item for sublist in articles0 for item in sublist]
    flat_dates = [item for sublist in dates0 for item in sublist]
 
    articlelist=pd.DataFrame(data=flat_articles, index=flat_dates)
    articlelist['date']=flat_dates
   

# save count of keywords into DataFrame
    u1=rexepu.keywords(flat_articles,rexepu.pu1)
    articlelist['u1']=u1
    u2=rexepu.keywords(flat_articles,rexepu.pu2)
    articlelist['u2']=u2
    u3=rexepu.keywords(flat_articles,rexepu.pu3)
    articlelist['u3']=u3
    u4=rexepu.keywords(flat_articles,rexepu.pu4)
    articlelist['u4']=u4
    u5=rexepu.keywords(flat_articles,rexepu.pu5)
    articlelist['u5']=u5
    u6=rexepu.keywords(flat_articles,rexepu.pu6)
    articlelist['u6']=u6
    u7=rexepu.keywords(flat_articles,rexepu.pu7)
    articlelist['u7']=u7
    u8=rexepu.keywords(flat_articles,rexepu.pu8)
    articlelist['u8']=u8
    u9=rexepu.keywords(flat_articles,rexepu.pu9)
    articlelist['u9']=u9
    u10=rexepu.keywords(flat_articles,rexepu.pu10)
    articlelist['u10']=u10

    e1=rexepu.keywords(flat_articles,rexepu.pe1)
    articlelist['e1']=e1
    e2=rexepu.keywords(flat_articles,rexepu.pe2)
    articlelist['e2']=e2

    t1 =rexepu.keywords(flat_articles,rexepu.tp1)
    articlelist['t1']=t1
    t2 =rexepu.keywords(flat_articles,rexepu.tp2)
    articlelist['t2']=t2
    t3 =rexepu.keywords(flat_articles,rexepu.tp3)
    articlelist['t3']=t3
    t4 =rexepu.keywords(flat_articles,rexepu.tp4)
    articlelist['t4']=t4
    t5 =rexepu.keywords(flat_articles,rexepu.tp5)
    articlelist['t5']=t5
    t6 =rexepu.keywords(flat_articles,rexepu.tp6)
    articlelist['t6']=t6
    t7 =rexepu.keywords(flat_articles,rexepu.tp7)
    articlelist['t7']=t7
    t8 =rexepu.keywords(flat_articles,rexepu.tp8)
    articlelist['t8']=t8
    t9 =rexepu.keywords(flat_articles,rexepu.tp9)
    articlelist['t9']=t9
    t10 =rexepu.keywords(flat_articles,rexepu.tp10)
    articlelist['t10']=t10
    t11 =rexepu.keywords(flat_articles,rexepu.tp11)
    articlelist['t11']=t11
    t12 =rexepu.keywords(flat_articles,rexepu.tp12)
    articlelist['t12']=t12
    t13 =rexepu.keywords(flat_articles,rexepu.tp13)
    articlelist['t13']=t13
    t14 =rexepu.keywords(flat_articles,rexepu.tp14)
    articlelist['t14']=t14
    t15 =rexepu.keywords(flat_articles,rexepu.tp15)
    articlelist['t15']=t15
    t16 =rexepu.keywords(flat_articles,rexepu.tp16)
    articlelist['t16']=t16
    t17 =rexepu.keywords(flat_articles,rexepu.tp17)
    articlelist['t17']=t17
    t18 =rexepu.keywords(flat_articles,rexepu.tp18)
    articlelist['t18']=t18
    t19 =rexepu.keywords(flat_articles,rexepu.tp19)
    articlelist['t19']=t19
    t20 =rexepu.keywords(flat_articles,rexepu.tp20)
    articlelist['t20']=t20

    
###generate index epu
    u=[]
    e=[]
    t=[]

    for i in range(len(flat_articles)):        
        if u1[i]>0 or \
           u2[i]>0 or \
           u3[i]>0 or \
           u4[i]>0 or \
           u5[i]>0 or \
           u6[i]>0 or \
           u7[i]>0 or \
           u8[i]>0 or \
           u9[i]>0 or \
           u10[i]>0:
               u0=1
               u.append(u0)
        else:
            u0=0
            u.append(u0)

    for i in range(len(flat_articles)):
        if (e1[i]>0 or e2[i]>0):
            e0=1
            e.append(e0)
        else:
            e0=0
            e.append(e0)
        
    for i in range(len(flat_articles)):        
        if t1[i]>0 or \
           t2[i]>0 or \
           t3[i]>0 or \
           t4[i]>0 or \
           t5[i]>0 or \
           t6[i]>0 or \
           t7[i]>0 or \
           t8[i]>0 or \
           t9[i]>0 or \
           t10[i]>0 or \
           t11[i]>0 or \
           t12[i]>0 or \
           t13[i]>0 or \
           t14[i]>0 or \
           t15[i]>0 or \
           t16[i]>0 or \
           t17[i]>0 or \
           t18[i]>0 or \
           t19[i]>0 or \
           t20[i]>0:
               t0=1
               t.append(t0)
        else:
            t0=0
            t.append(t0)

         
    tpu=[]
    for i in range(len(flat_articles)):  
        if u[i]>0 and e[i]>0 and t[i]>0:
            tpu0=1
            tpu.append(tpu0)
        else:
            tpu0=0
            tpu.append(tpu0)
 


    if len(e)==len(t)==len(u)==len(epu)==len(flat_articles)==len(flat_dates):
        print('Pass')
    else:
        print('Alert')

#put epu index into DataFrame
    articlelist['e']=e
    articlelist['t']=t
    articlelist['u']=u
    articlelist['tpu']=tpu

    articlelist=articlelist.rename(columns={0:'match'})
   # path1=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\csv_RMRB_20180904'
  #  path2=path1+'\\'+'all_epu'+year+'.xlsx'

    #articlelist.to_excel(path2,encoding='utf8')

    epu_test=articlelist.filter(['date','tpu','e'],axis=1)
    epu_test.head(10)

    epu_test1=epu_test.groupby('date').sum()
    epu_test1.head(10)

    epu_test2=epu_test.groupby('date').size()
    epu_test2.head(10)

    epudaily=pd.concat([epu_test1,epu_test2],axis=1)
    epudaily=epudaily.rename(columns={0:'count'})
    epudaily.head(5)
    epudaily.count()

#change date format
    epudaily['date']=epudaily.index
    epudaily['date']=pd.to_datetime(epudaily['date'], format='%Y%m%d').dt.strftime("%m/%d/%Y")
#epudaily.drop('date', axis=1, inplace=True)
    epudaily.head(10)
    epudaily['tpu_count']=epudaily['tpu']/epudaily['count']
    epudaily['tpu_econ']=epudaily['tpu']/epudaily['e']

#os.makedirs(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\csv')
    path3=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\tpu'
    epudaily.to_csv(os.path.join(path3,'tpudaily'+folders[0][:4]+'.csv'))





