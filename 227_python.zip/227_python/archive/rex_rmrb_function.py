# -*- coding: utf-8 -*-
"""
Created on Fri Oct 12 13:43:24 2018

@author: dingq
"""

##rex for rmrb
import re
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy1=u'财政'
policy2=u'货币'
policy3=u'证监会'
policy4=u'银监会'
policy5=u'财政部'
policy6=u'人民银行'
policy7=u'国家发改委'
policy8=u'开放'
policy9=u'改革'
policy10=u'商务部'
policy11=u'法律'
policy12=u'法规'
policy13=u'税收'
policy14=u'国债'
policy15=u'政府债务'
policy16=u'央行'
policy17=u'外经贸部'
policy18=u'关税'
policy19=u'政府赤字'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp10 =re.compile(policy10)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)


# a function to compile keywords
def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts
    
