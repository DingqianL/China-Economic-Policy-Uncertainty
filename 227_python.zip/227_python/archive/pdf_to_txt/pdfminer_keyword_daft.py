#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 27 17:36:26 2017

@author: dingqianliu
"""

##import os package which helps to deal with file issues##
import os
##to get current file path, default by system##
os.getcwd()
print os.getcwd()
##change the file path, chdir as change directory##
os.chdir('/Users/dingqianliu/Documents/my dissertation/python')
##or can use##
path='/Users/dingqianliu/Documents/my dissertation/python'
os.chdir(path)



#（3）保存pdf文本内容
import os
import re
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams


#将一个pdf转换成txt
def pdfTotxt(filepath,outpath):
    try:
        fp = file(filepath, 'rb')
        outfp=file(outpath,'w')
        #创建一个PDF资源管理器对象来存储共享资源
        #caching = False不缓存
        rsrcmgr = PDFResourceManager(caching = False)
        # 创建一个PDF设备对象
        laparams = LAParams()
        device = TextConverter(rsrcmgr, outfp, codec='utf-8', laparams=laparams,imagewriter=None)
        #创建一个PDF解析器对象
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.get_pages(fp, pagenos = set(),maxpages=0,
                                      password='',caching=False, check_extractable=True):
            page.rotate = page.rotate % 360
            interpreter.process_page(page)
        #关闭输入流
        fp.close()
        #关闭输出流
        device.close()
        outfp.flush()
        outfp.close()
    except Exception, e:
         print "Exception:%s",e
         
##运用这个函数
pdfTotxt('人民日报2011年2月2日.pdf','rmrb20110228.txt')

##循环读取文件
for i in range(1,32):
    x=u'人民日报2011年2月'
    y=str(i)
    z=u'日.pdf'
    a=x+y+z
    p='rmrb201102'
    q='.txt'
    w=p+y+q
    pdfTotxt(a,w)

    x=u'人民日报2011年2月'
    y=str(1)
    z=u'日.pdf'
    a=x+y+z
p='rmrb201102'
q='.txt'
w=p+y+q
print a
pdfTotxt(print a,print w )


with open('myfile11.txt','r+') as f:
    read_data=f.read()



#去掉空格和换行符
read_data=read_data.replace(' ', '')
read_data=read_data.replace('\n','')
with open("rmrb11.txt",'w+') as f:
    f.write(read_data)
    
lead1=u'挑战'.encode('utf8')
p=re.compile(lead1)
results=p.findall(read_data)

read_data
print read_data
len(results)


for result in results:
    print result

