# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 20:54:06 2018

@author: dingq
"""
from pdfminer.pdfparser import PDFParser, PDFDocument  
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter  
from pdfminer.converter import PDFPageAggregator  
from pdfminer.layout import LTTextBoxHorizontal,LAParams  
import os  

def pdfTotxt(filein,fileout):
    try:
        fp = file(filein, 'rb')
        outfp=file(fileout,'w')
        #创建一个PDF资源管理器对象来存储共享资源
        #caching = False不缓存
        rsrcmgr = PDFResourceManager(caching = False)
        # 创建一个PDF设备对象
        laparams = LAParams()
        device = TextConverter(rsrcmgr, outfp, codec='utf-8', laparams=laparams,imagewriter=None)
        #创建一个PDF解析器对象
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.get_pages(fp, pagenos = set(),maxpages=0,
                                      password='',caching=False, check_extractable=True):
            interpreter.process_page(page)
        #关闭输入流
        fp.close()
        #关闭输出流
        device.close()
        outfp.flush()
        outfp.close()
    except Exception as e:
         print ("Exception:%s"),e
         
dire='C:\Users\dingq\Documents\people daily1946-2010\people daily 2010\Mar'
os.chdir(dire)
path=os.listdir(dire)

for x in range(len(path)):
    old_name=path[x]
    new_name='201003'+str(x+1)+'.txt'
    pdfTotxt(old_name,new_name)
