# -*- coding: utf-8 -*-
"""
Created on Sun Jun 17 21:00:35 2018

@author: dingq
"""



from pdfminer.pdfparser import PDFParser, PDFDocument  
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter  
from pdfminer.converter import PDFPageAggregator  
from pdfminer.layout import LTTextBoxHorizontal,LAParams  
import os  



def pdfTOtxt(filein,fileout):
    try:
        fp = open(filein, 'rb')
            # 创建一个PDF文档分析器：PDFParser  
        parser = PDFParser(fp)  
            # 创建一个PDF文档：PDFDocument  
        doc = PDFDocument()  
            # 连接分析器与文档  
        parser.set_document(doc)  
        doc.set_parser(parser)  
            # 提供初始化密码，如果无密码，输入空字符串  
        doc.initialize("")  
            # 检测文档是否提供txt转换，不提供就忽略  
        if not doc.is_extractable:
            print("PDFTextExtractionNotAllowed")  
        else:  
                # 创建PDF资源管理器：PDFResourceManager  
            resource = PDFResourceManager()  
                # 创建一个PDF参数分析器：LAParams  
            laparams = LAParams()  
                # 创建聚合器,用于读取文档的对象：PDFPageAggregator  
            device = PDFPageAggregator(resource, laparams=laparams)  
                # 创建解释器，对文档编码，解释成Python能够识别的格式：PDFPageInterpreter  
            interpreter = PDFPageInterpreter(resource, device)  
                # doc.get_pages() 获取page列表  
            for page in doc.get_pages():  
                    # 利用解释器的process_page()方法解析读取单独页数  
                interpreter.process_page(page)  
                    # 这里layout是一个LTPage对象,里面存放着这个page解析出的各种对象,  
                    # 一般包括LTTextBox, LTFigure, LTImage, LTTextBoxHorizontal等等,想要获取文本就获得对象的text属性，  
                    # 使用聚合器get_result()方法获取页面内容  
                layout = device.get_result()  
                for out in layout:  
                    if (isinstance(out, LTTextBoxHorizontal)):
                        mytxt = out.get_text()
                        with open(fileout, 'a',encoding='utf-8') as f:
                            f.write(mytxt)                        
    except Exception as e:
         print ("Exception:%s"),e

dire=r'C:\Users\dingq\Documents\200_academic\213_Academic_2018 Fall\618 Macro History\final paper\1860'
os.chdir(dire)
files=os.listdir(dire)
files=[f for f in files if f.endswith('pdf')]

for pdfFile in files[87:]:
    #pdfPath=os.path.join(dire,pdfFile)
    txtFile=pdfFile
    if txtFile[-3:]!="txt":
        txtFile=txtFile[4:-4]+".txt"
        pdfTOtxt(pdfFile,txtFile)
    
    
    