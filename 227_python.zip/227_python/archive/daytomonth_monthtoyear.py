# -*- coding: utf-8 -*-
"""
Created on Fri May 18 07:28:33 2018

@author: dingq
"""

import os
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\226_data_pdf\人民日报 1946-2006(txt_csv_update)\update\198610'
os.chdir(path)
list_file=os.listdir(path)


filep=r''
for i in list_file:
    with open(i,'r+',errors='ignore') as files:
        filess=files.read()
        filep=filep+filess
        
with open('198610.txt', 'w+',encoding='utf8') as allfile:
    allfile.write(filep)
    
    
