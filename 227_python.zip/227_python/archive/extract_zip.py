# -*- coding: utf-8 -*-
"""
Created on Tue Oct  2 15:36:05 2018

@author: dingq
"""

#extract from zip files
import zipfile
import os

path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_redownload\2007rmrb'
os.chdir(path)
zip_files=os.listdir(path)
zip_files=[ f for f in zip_files if f.endswith('.zip')]

len(zip_files)

for i in zip_files:
    try:
        zip_file=zipfile.ZipFile(i)
        newpath=os.path.join(path,i[:-4]+'new')
        zip_file.extract('index.html',newpath)
    except zipfile.BadZipfile as e:
        print(i)



##find the zip files with error, I'll redownload them
path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_redownload\2017rmrb'
os.chdir(path)
html_files=os.listdir(path) #all the files in the year, contains both extracted folder and zip files
html_files_not=[ f for f in html_files if f.endswith('.zip')] #find zip files

import numpy as np

folders=list(np.setdiff1d(html_files,html_files_not)) #find all the folders with extracted html

dones=[f[:-3] for f in folders] #find the page number of done folders

zips=[f[:-4] for f in html_files_not] #find the page number of all zipfiles

missing=list(np.setdiff1d(zips,dones)) #find the page number that has errors

missing_d=''
for i in missing:
    missing_d=missing_d+'   '+i[-2:]

with open(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_redownload\2017missing.txt', 'w') as f:
    f.write(missing_d)
    
#transform html to txt
ht_path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_redownload\2007rmrb'
allht=os.listdir(ht_path)
html_paths=[f for f in allht if not f.endswith('.zip')]
html_paths=[f for f in html_paths if not f.endswith('.txt')]

import shutil
from bs4 import BeautifulSoup

for i in html_paths:
    html_path=os.path.join(ht_path,i) #the route of target folder
    os.chdir(html_path)
    htmlfile=os.listdir(html_path) #get the route of html file
    html_text=''.join(htmlfile) #switch list to string
    shutil.move(html_text,html_text[:-5]+'.txt') #change html to txt file, but the html label remains
    with open(html_text[:-5]+'.txt', "r", encoding='utf-8') as f:
        text = f.read()
        soup = BeautifulSoup(text,'lxml')
        text_html = soup.text
        new_txt=html_path[:-3]+'.txt'
    with open(new_txt,'w',encoding='utf-8') as f:
        f.write(text_html)





