# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 13:46:32 2018

@author: dingq
"""

import os
import re
import pandas as pd

path=r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\2018'
folders=os.listdir(path)

len(folders)
date=folders #the folder of each date
counts=[]
articles0=[]
for i in folders:
    path1=os.path.join(path,i)
    artic=os.listdir(path1) #count the number of articles for each date
    os.chdir(path1)
    count=len(artic)
    counts.append(count)
    articles=[]
    for j in artic:
        with open (j, 'r+', encoding='utf-8',errors='ignore') as f:
            article=f.read()
            article=article.replace(' ', '')
            article=article.replace('\n','')
            articles.append(article)
    articles0.append(articles)

##
dates=[[f] for f in date]
cous=[]
for i in articles0:
    cou=len(i)
    cous.append(cou)

dates0=[a*b for a,b in zip(dates,cous)]
flat_articles = [item for sublist in articles0 for item in sublist]
flat_dates = [item for sublist in dates0 for item in sublist]
 
articlelist=pd.DataFrame(data=flat_articles, index=flat_dates)
articlelist['date']=flat_dates
   
###compile the key words###
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

trade1=u'贸易'
trade2=u'外贸'

policy1=u'开放'
policy2=u'关税'
policy3=u'自贸协定'
policy4=u'博览会'
policy5=u'保税区'
policy6=u'海关'
policy7=u'峰会'
policy8=u'合作'
policy9=u'规则'
policy10=u'决策'
policy11=u'部长'
policy12=u'商务部'
policy13=u'法律'
policy14=u'法规'
policy15=u'税'

pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(trade1)
pe2=re.compile(trade2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)

###

# a function to compile keywords

def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts

# save count of keywords into DataFrame
u1=keywords(flat_articles,pu1)
articlelist['u1']=u1
u2=keywords(flat_articles,pu2)
articlelist['u2']=u2
u3=keywords(flat_articles,pu3)
articlelist['u3']=u3
u4=keywords(flat_articles,pu4)
articlelist['u4']=u4
u5=keywords(flat_articles,pu5)
articlelist['u5']=u5
u6=keywords(flat_articles,pu6)
articlelist['u6']=u6
u7=keywords(flat_articles,pu7)
articlelist['u7']=u7
u8=keywords(flat_articles,pu8)
articlelist['u8']=u8
u9=keywords(flat_articles,pu9)
articlelist['u9']=u9
u10=keywords(flat_articles,pu10)
articlelist['u10']=u10

e1=keywords(flat_articles,pe1)
articlelist['e1']=e1
e2=keywords(flat_articles,pe2)
articlelist['e2']=e2

p1 =keywords(flat_articles,pp1)
articlelist['p1']=p1
p2 =keywords(flat_articles,pp2)
articlelist['p2']=p2
p3 =keywords(flat_articles,pp3)
articlelist['p3']=p3
p4 =keywords(flat_articles,pp4)
articlelist['p4']=p4
p5 =keywords(flat_articles,pp5)
articlelist['p5']=p5
p6 =keywords(flat_articles,pp6)
articlelist['p6']=p6
p7 =keywords(flat_articles,pp7)
articlelist['p7']=p7
p8 =keywords(flat_articles,pp8)
articlelist['p8']=p8
p9 =keywords(flat_articles,pp9)
articlelist['p9']=p9
p11 =keywords(flat_articles,pp11)
articlelist['p11']=p11
p12 =keywords(flat_articles,pp12)
articlelist['p12']=p12
p13 =keywords(flat_articles,pp13)
articlelist['p13']=p13
p14 =keywords(flat_articles,pp14)
articlelist['p14']=p14
p15 =keywords(flat_articles,pp15)
articlelist['p15']=p15
    
###generate index epu
u=[]
e=[]
p=[]

for i in range(len(flat_articles)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(flat_articles)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(flat_articles)):        
    if p1[i]>0 or \
       p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(flat_articles)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 
len(e)
len(p)
len(u)
len(epu)


if len(e)==len(p)==len(u)==len(epu)==len(flat_articles)==len(flat_dates):
    print('Pass')
else:
    print('Alert')

#put epu index into DataFrame
articlelist['e']=e
articlelist['p']=p
articlelist['u']=u
articlelist['epu']=epu

articlelist=articlelist.rename(columns={0:'articles'})
articlelist.columns

'''generate epu daily index'''

epu_test=articlelist.filter(['date','epu','e'],axis=1)
epu_test.count()
epu_test.head(10)

epu_test1=epu_test.groupby('date').sum()
epu_test1.count()
epu_test1.head(10)

epu_test2=epu_test.groupby('date').size()
epu_test2.head(10)
epu_test2.count()

epudaily=pd.concat([epu_test1,epu_test2],axis=1)
epudaily=epudaily.rename(columns={0:'count'})
epudaily.head(5)
epudaily.count()

#change date format
epudaily['date']=epudaily.index
epudaily['date']=pd.to_datetime(epudaily['date'], format='%Y%m%d').dt.strftime("%m/%d/%Y")
#epudaily.drop('date', axis=1, inplace=True)
epudaily.head(10)
epudaily['epu_count']=epudaily['epu']/epudaily['count']
epudaily['epu_econ']=epudaily['epu']/epudaily['e']

epudaily.head(5)
#os.makedirs(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\csv')
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\tpu')
epudaily.to_csv('r_epudaily2018_e.csv', index=False)


