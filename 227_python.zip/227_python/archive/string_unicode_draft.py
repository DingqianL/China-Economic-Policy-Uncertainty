#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 19:54:26 2017

@author: dingqianliu
"""

# -*- coding: utf-8 -*-  
# file: example1.py  
import string  
  
# 这个是 str 的字符串  
s = '关关雎鸠'  
s.decode('utf-8') 
# 这个是 unicode 的字符串  
u  
print isinstance(s, str)      # True  
print isinstance(u, unicode)  # True  
  
print s.__class__   # <type 'str'>  
print u.__class__   # <type 'unicode'>  

# 从 str 转换成 unicode  
print s.decode('utf-8')   # 关关雎鸠  
  
# 从 unicode 转换成 str  
print u.encode('utf-8')   # 关关雎鸠  

#####为什么从 unicode 转 str 是 encode，而反过来叫 decode? 
#### 因为 Python 认为 16 位的 unicode 才是字符的唯一内码，而大家常用的字符集如 gb2312，gb18030/gbk，utf-8，以及 ascii 都是字符的二进制（字节）编码形式。把字符从 unicode 转换成二进制编码，当然是要 encode。
####反过来，在 Python 中出现的 str 都是用字符集编码的 ansi 字符串。Python 本身并不知道 str 的编码，需要由开发者指定正确的字符集 decode

import re
message = u'天人合一'.encode('utf8')

print(re.search(u'人'.encode('utf8'), message).group())




p=re.compile(lead)

results=p.findall(read_data)

for result in results:
    print result
    
len(results)
