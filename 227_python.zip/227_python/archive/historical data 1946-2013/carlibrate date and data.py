# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 14:02:07 2018

@author: dingq
"""
###merge data with the data processing below
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')

merge1947.count
epudaily1946.count
epudaily1947.count
epudaily1948.count
a_epudaily1946_2003=epudaily1946.append([epudaily1947,epudaily1948])
a_epudaily1946_2003_2011_2017.count
a_epudaily1946_2003.count
aggregate_epudailty1946_2003=pd.merge(fullrange, a_epudaily1946_2003,how='outer')
aggregate_epudailty1946_2003_2011_2017=pd.merge(fullrange, a_epudaily1946_2003_2011_2017,how='outer')

test1=list(merge1946['date'])
test2=list(epudaily1947['date'])
a_epudaily1946_2003.to_csv('a_epudaily1946_2003.csv')

aggregate_epudailty1946_2003.to_csv('aggregate_epudailty1946_2003.csv')
aggregate_epudailty1946_2003_2011_2017.to_csv('aggregate_epudailty1946_2003_2011_2017.csv')

#####data processing
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import os

date_today = datetime.now().date()
days = pd.date_range(date_today, date_today + timedelta(7), freq='D')

from datetime import date
d0=date(1946,5,15)
d1=date(2017,12,31)
d2=date(1946,12,31)
delta=d1-d0
delta2=d2-d0
period=delta.days+1
print(delta2.days)

fulldate=pd.date_range("19460515", periods=period)
fulldate_string=[i.strftime('%m/%d/%Y') for i in fulldate]
fulldate_datetime=[datetime.strptime(d,'%m/%d/%Y').date() for d in fulldate_string]
fullrange=pd.DataFrame(fulldate_datetime)
fullrange=fullrange.rename(columns={0:'date'})
fullrange.head(10)
fullrange.tail(10)
fullrange.count

os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1946=pd.read_csv('epudaily1946.csv')
epudaily1946.count

epudaily1946.head(10)
epudaily1946.drop(epudaily1946.index[-1], inplace=True)

date_tochange=list(epudaily1946['date'])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%m/%d/%Y').date() for d in date_tochange]
epudaily1946['date']=date_changed
epudaily1946.count

epudaily1946.head(10)
epudaily1946.tail(10)
merge1946=pd.merge(fullrange, epudaily1946,how='outer')
merge1946.count
merge1946.tail(10)
merge1946.head(10)
merge1946.to_csv('merge1946_2.csv')

##input for 1947
os.chdir(r'C:\Users\dingq\Documents\人民日报 1946-2010')

epudaily1947=pd.read_csv('epudaily1947.csv')
epudaily1947.count


epudaily1947.head(10)
date_tochange=list(epudaily1947['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1947['date']=date_changed
epudaily1947.count

##input for 1948
epudaily1948=pd.read_csv('epudaily1948.csv')
epudaily1948.count


epudaily1948.head(10)
date_tochange=list(epudaily1948['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1948['date']=date_changed
epudaily1948.count

##input for 1949
epudaily1949=pd.read_csv('epudaily1949.csv')
epudaily1949.count


epudaily1949.head(10)
date_tochange=list(epudaily1949['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1949['date']=date_changed
epudaily1949.count


##input for 1950
epudaily1950=pd.read_csv('epudaily1950.csv')
epudaily1950.count


epudaily1950.head(10)
date_tochange=list(epudaily1950['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1950['date']=date_changed
epudaily1950.count

##input for 1951
epudaily1951=pd.read_csv('epudaily1951.csv')
epudaily1951.count


epudaily1951.head(10)
date_tochange=list(epudaily1951['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1951['date']=date_changed
epudaily1951.count

##input for 1952
epudaily1952=pd.read_csv('epudaily1952.csv')
epudaily1952.count


epudaily1952.head(10)
date_tochange=list(epudaily1952['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1952['date']=date_changed
epudaily1952.count

##input for 1953
epudaily1953=pd.read_csv('epudaily1953.csv')
epudaily1953.count


epudaily1953.head(10)
date_tochange=list(epudaily1953['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1953['date']=date_changed
epudaily1953.count

##input for 1954
epudaily1954=pd.read_csv('epudaily1954.csv')
epudaily1954.count


epudaily1954.head(10)
date_tochange=list(epudaily1954['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1954['date']=date_changed
epudaily1954.count

##input for 1955
epudaily1955=pd.read_csv('epudaily1955.csv')
epudaily1955.count


epudaily1955.head(10)
date_tochange=list(epudaily1955['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1955['date']=date_changed
epudaily1955.count

##input for 1956
epudaily1956=pd.read_csv('epudaily1956.csv')
epudaily1956.count


epudaily1956.head(10)
date_tochange=list(epudaily1956['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1956['date']=date_changed
epudaily1956.count


##input for 1957
epudaily1957=pd.read_csv('epudaily1957.csv')
epudaily1957.count


epudaily1957.head(10)
date_tochange=list(epudaily1957['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1957['date']=date_changed
epudaily1957.count

##input for 1958
epudaily1958=pd.read_csv('epudaily1958.csv')
epudaily1958.count


epudaily1958.head(10)
date_tochange=list(epudaily1958['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1958['date']=date_changed
epudaily1958.count

##input for 1959
epudaily1959=pd.read_csv('epudaily1959.csv')
epudaily1959.count


epudaily1959.head(10)
date_tochange=list(epudaily1959['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1959['date']=date_changed
epudaily1959.count

##input for 1960
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')

epudaily1960=pd.read_csv('epudaily1960_1.csv')
epudaily1960.count
epudaily1960['date']=epudaily1960.index
epudaily1960=epudaily1960.drop('1960-10\u300018')

epudaily1960.head(10)
date_tochange=list(epudaily1960['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1960['date']=date_changed
epudaily1960.reset_index(drop=True)
epudaily1960.count


##input for 1961
epudaily1961=pd.read_csv('epudaily1961.csv')
epudaily1961.count


epudaily1961.head(10)
date_tochange=list(epudaily1961['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1961['date']=date_changed
epudaily1961.count


##input for 1962
epudaily1962=pd.read_csv('epudaily1962.csv')
epudaily1962.count


epudaily1962.head(10)
date_tochange=list(epudaily1962['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1962['date']=date_changed
epudaily1962.count

##input for 1963
epudaily1963=pd.read_csv('epudaily1963.csv')
epudaily1963.count


epudaily1963.head(10)
date_tochange=list(epudaily1963['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1963['date']=date_changed
epudaily1963.count

##input for 1964
epudaily1964=pd.read_csv('epudaily1964.csv')
epudaily1964.count


epudaily1964.head(10)
date_tochange=list(epudaily1964['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1964['date']=date_changed
epudaily1964.count


##input for 1965
epudaily1965=pd.read_csv('epudaily1965.csv')
epudaily1965.count


epudaily1965.head(10)
date_tochange=list(epudaily1965['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1965['date']=date_changed
epudaily1965.count

##input for 1966
epudaily1966=pd.read_csv('epudaily1966.csv')
epudaily1966.count


epudaily1966.head(10)
date_tochange=list(epudaily1966['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1966['date']=date_changed
epudaily1966.count


##input for 1967
epudaily1967=pd.read_csv('epudaily1967.csv')
epudaily1967.count

epudaily1967.head(10)
date_tochange=list(epudaily1967['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1967['date']=date_changed
epudaily1967.count


##input for 1968
epudaily1968=pd.read_csv('epudaily1968.csv')
epudaily1968.count

epudaily1968.head(10)
date_tochange=list(epudaily1968['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1968['date']=date_changed
epudaily1968.count


##input for 1969
epudaily1969=pd.read_csv('epudaily1969.csv')
epudaily1969.count

epudaily1969.head(10)
date_tochange=list(epudaily1969['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1969['date']=date_changed
epudaily1969.count


##input for 1970
epudaily1970=pd.read_csv('epudaily1970.csv')
epudaily1970.count

epudaily1970.head(10)
date_tochange=list(epudaily1970['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1970['date']=date_changed
epudaily1970.count



##input for 1971
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1971=pd.read_csv('epudaily1971.csv')
epudaily1971.count

epudaily1971.head(10)
date_tochange=list(epudaily1971['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1971['date']=date_changed
epudaily1971.count


##input for 1972
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1972=pd.read_csv('epudaily1972.csv')
epudaily1972.count

epudaily1972.head(10)
date_tochange=list(epudaily1972['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1972['date']=date_changed
epudaily1972.count

##input for 1973
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1973=pd.read_csv('epudaily1973.csv')
epudaily1973.count

epudaily1973.head(10)
date_tochange=list(epudaily1973['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1973['date']=date_changed
epudaily1973.count

##input for 1974
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1974=pd.read_csv('epudaily1974.csv')
epudaily1974.count

epudaily1974.head(10)
date_tochange=list(epudaily1974['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1974['date']=date_changed
epudaily1974.count

##input for 1975
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1975=pd.read_csv('epudaily1975.csv')
epudaily1975.count

epudaily1975.head(10)
date_tochange=list(epudaily1975['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1975['date']=date_changed
epudaily1975.count


##input for 1976
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1976=pd.read_csv('epudaily1976.csv')
epudaily1976.count

epudaily1976.head(10)
date_tochange=list(epudaily1976['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1976['date']=date_changed
epudaily1976.count

##input for 1977
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1977=pd.read_csv('epudaily1977.csv')
epudaily1977.count

epudaily1977.head(10)
date_tochange=list(epudaily1977['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1977['date']=date_changed
epudaily1977.count


##input for 1978
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1978=pd.read_csv('epudaily1978.csv')
epudaily1978.count

epudaily1978.head(10)
date_tochange=list(epudaily1978['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1978['date']=date_changed
epudaily1978.count


##input for 1979
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1979=pd.read_csv('epudaily1979.csv')
epudaily1979.count

epudaily1979.head(10)
date_tochange=list(epudaily1979['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1979['date']=date_changed
epudaily1979.count


##input for 1980
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1980=pd.read_csv('epudaily1980.csv')
epudaily1980.count

epudaily1980.head(10)
date_tochange=list(epudaily1980['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1980['date']=date_changed
epudaily1980.count


##input for 1981
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1981=pd.read_csv('epudaily1981.csv')
epudaily1981.count

epudaily1981.head(10)
date_tochange=list(epudaily1981['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1981['date']=date_changed
epudaily1981.count


##input for 1982
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1982=pd.read_csv('epudaily1982.csv')
epudaily1982.count

epudaily1982.head(10)
date_tochange=list(epudaily1982['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1982['date']=date_changed
epudaily1982.count

##input for 1983
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1983=pd.read_csv('epudaily1983.csv')
epudaily1983.count

epudaily1983.head(10)
date_tochange=list(epudaily1983['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1983['date']=date_changed
epudaily1983.count


##input for 1984
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1984=pd.read_csv('epudaily1984.csv')
epudaily1984.count

epudaily1984.head(10)
date_tochange=list(epudaily1984['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1984['date']=date_changed
epudaily1984.count

##input for 1985
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1985=pd.read_csv('epudaily1985.csv')
epudaily1985.count

epudaily1985.head(10)
date_tochange=list(epudaily1985['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1985['date']=date_changed
epudaily1985.count

##input for 1986
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1986=pd.read_csv('epudaily1986.csv')
epudaily1986.count

epudaily1986.head(10)
date_tochange=list(epudaily1986['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1986['date']=date_changed
epudaily1986.count


##input for 1987
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1987=pd.read_csv('epudaily1987.csv')
epudaily1987.count

epudaily1987.head(10)
date_tochange=list(epudaily1987['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1987['date']=date_changed
epudaily1987.count

##input for 1988
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1988=pd.read_csv('epudaily1988.csv')
epudaily1988.count

epudaily1988.head(10)
date_tochange=list(epudaily1988['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1988['date']=date_changed
epudaily1988.count


##input for 1989
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1989=pd.read_csv('epudaily1989.csv')
epudaily1989.count

epudaily1989.head(10)
date_tochange=list(epudaily1989['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1989['date']=date_changed
epudaily1989.count


##input for 1990
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1990=pd.read_csv('epudaily1990.csv')
epudaily1990.count

epudaily1990.head(10)
date_tochange=list(epudaily1990['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1990['date']=date_changed
epudaily1990.count


##input for 1991
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1991=pd.read_csv('epudaily1991.csv')
epudaily1991.count

epudaily1991.head(10)
date_tochange=list(epudaily1991['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1991['date']=date_changed
epudaily1991.count


##input for 1992
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1992=pd.read_csv('epudaily1992.csv')
epudaily1992.count

epudaily1992.head(10)
date_tochange=list(epudaily1992['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1992['date']=date_changed
epudaily1992.count

##input for 1993
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1993=pd.read_csv('epudaily1993.csv')
epudaily1993.count

epudaily1993.head(10)
date_tochange=list(epudaily1993['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1993['date']=date_changed
epudaily1993.count

##input for 1994
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1994=pd.read_csv('epudaily1994.csv')
epudaily1994.count

epudaily1994.head(10)
date_tochange=list(epudaily1994['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1994['date']=date_changed
epudaily1994.count


##input for 1995
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1995=pd.read_csv('epudaily1995.csv')
epudaily1995.count

epudaily1995.head(10)
date_tochange=list(epudaily1995['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1995['date']=date_changed
epudaily1995.count


##input for 1996
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1996=pd.read_csv('epudaily1996.csv')
epudaily1996.count

epudaily1996.head(10)
date_tochange=list(epudaily1996['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1996['date']=date_changed
epudaily1996.count


##input for 1997
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1997=pd.read_csv('epudaily1997.csv')
epudaily1997.count

epudaily1997.head(10)
date_tochange=list(epudaily1997['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1997['date']=date_changed
epudaily1997.count



##input for 1998
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1998=pd.read_csv('epudaily1998.csv')
epudaily1998.count

epudaily1998.head(10)
date_tochange=list(epudaily1998['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1998['date']=date_changed
epudaily1998.count

##input for 1999
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily1999=pd.read_csv('epudaily1999.csv')
epudaily1999.count

epudaily1999.head(10)
date_tochange=list(epudaily1999['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1999['date']=date_changed
epudaily1999.count

##input for 2000
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily2000=pd.read_csv('epudaily2000.csv')
epudaily2000.count

epudaily2000.head(10)
date_tochange=list(epudaily2000['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2000['date']=date_changed
epudaily2000.count


##input for 2001
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily2001=pd.read_csv('epudaily2001.csv')
epudaily2001.count

epudaily2001.head(10)
date_tochange=list(epudaily2001['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2001['date']=date_changed
epudaily2001.count

##input for 2002
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily2002=epudaily
epudaily2002.count
check=list(epudaily2002.index)
check[300:315]
epudaily2002=epudaily2002.drop('2002-02—20')
epudaily2002=epudaily2002.drop('2002-10—20')
epudaily2002.head(10)
epudaily2002['date']=epudaily2002.index
epudaily2002.reset_index(drop=True)
date_tochange=list(epudaily2002['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2002['date']=date_changed
epudaily2002.count

##input for 2003
os.chdir(r'C:\Users\dingq\Documents\200-academic\220-Academic-My dissertation\data_csv\1946-2003')
epudaily2003=pd.read_csv('epudaily2003.csv')
epudaily2003.count

epudaily2003.head(10)
date_tochange=list(epudaily2003['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2003['date']=date_changed
epudaily2003.count

