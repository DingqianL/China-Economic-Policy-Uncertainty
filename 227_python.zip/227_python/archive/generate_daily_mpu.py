# -*- coding: utf-8 -*-
"""
Created on Mon May 07 20:47:20 2018

@author: dingq
"""

import os
import re


uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy1=u'贸易'
policy2=u'财政'
policy3=u'货币'
policy4=u'证监会'
policy5=u'银监会'
policy6=u'财政部'
policy7=u'人民银行'
policy8=u'国家发改委'
policy9=u'银行'
policy11=u'规则'
policy12=u'决策'
policy13=u'开放'
policy14=u'改革'
policy15=u'规定'
policy16=u'商务部'
policy17=u'法律'
policy18=u'法规'
policy19=u'税'
policy20=u'赤字'
policy21=u'国债'
policy22=u'政府债务'
policy23=u'央行'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp1 =re.compile(policy1)
pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)
pp20 =re.compile(policy20)
pp21 =re.compile(policy21)
pp22 =re.compile(policy22)
pp23 =re.compile(policy23)

article=[]
u1=[]
u2=[]
u3=[]
u4=[]
u5=[]
u6=[]
u7=[]
u8=[]
u9=[]
u10=[]

e1=[]
e2=[]

p1 =[]
p2 =[]
p3 =[]
p4 =[]
p5 =[]
p6 =[]
p7 =[]
p8 =[]
p9 =[]
p11 =[]
p12 =[]
p13 =[]
p14 =[]
p15 =[]
p16 =[]
p17 =[]
p18 =[]
p19 =[]
p20 =[]
p21 =[]
p22 =[]
p23 =[]

os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\2017')
path=os.listdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\2017')
path[0]
len(path)
path=[f for f in path if f.endswith('.txt')]

for m in path:
    with open(m,'r+',encoding='utf8', errors='ignore') as f:
        read_data=f.read()
        read_data=read_data.replace(' ', '')
        read_data=read_data.replace('\n','')
        slot1=read_data.split(lead1)
        slot2=[]
    for j in slot1:
        slot=j.split(lead2)
        slot2.extend(slot)
    n=0
    while n<len(slot2):
        if len(slot2[n])<2:
            slot2.pop(n)
            n-=1
        n+=1
    article=article+list(range(len(slot2)))

    for i in slot2:
        result=len(pu1.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u1.append(uu)
        
    for i in slot2:
        result=len(pu2.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u2.append(uu)
        
    for i in slot2:
        result=len(pu3.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u3.append(uu)

    for i in slot2:
        result=len(pu4.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u4.append(uu)
        
    for i in slot2:
        result=len(pu5.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u5.append(uu)
        
    for i in slot2:
        result=len(pu6.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u6.append(uu)
    
    for i in slot2:
        result=len(pu7.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u7.append(uu)
    
    for i in slot2:
        result=len(pu8.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u8.append(uu)
    
    for i in slot2:
        result=len(pu9.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u9.append(uu)
    
    for i in slot2:
        result=len(pu10.findall(i))
        if result>0:
            uu=result
        else:
            uu=0
        u10.append(uu)
                
    for i in slot2:
        result=len(pe1.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e1.append(ee)
                
    for i in slot2:
        result=len(pe2.findall(i))
        if result>0:
            ee=result
        else:
            ee=0
        e2.append(ee)
                
    for i in slot2:
        result=len(pp1.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p1.append(pp)
        
    for i in slot2:
        result=len(pp2.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p2.append(pp)
                
    for i in slot2:
        result=len(pp3.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p3.append(pp)
                
    for i in slot2:
        result=len(pp4.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p4.append(pp)
                
    for i in slot2:
        result=len(pp5.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p5.append(pp)
        
    for i in slot2:
        result=len(pp6.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p6.append(pp)
                
    for i in slot2:
        result=len(pp7.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p7.append(pp)
        
    for i in slot2:
        result=len(pp8.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p8.append(pp)
        
    for i in slot2:
        result=len(pp9.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p9.append(pp)
        
    
    for i in slot2:
        result=len(pp11.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p11.append(pp)
        
    for i in slot2:
        result=len(pp12.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p12.append(pp)
        
    for i in slot2:
        result=len(pp13.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p13.append(pp)
        
    for i in slot2:
        result=len(pp14.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p14.append(pp)
        
    for i in slot2:
        result=len(pp15.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p15.append(pp)
        
    for i in slot2:
        result=len(pp16.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p16.append(pp)
        
    for i in slot2:
        result=len(pp17.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p17.append(pp)
        
    for i in slot2:
        result=len(pp18.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p18.append(pp)
        
    for i in slot2:
        result=len(pp19.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p19.append(pp)
        
    for i in slot2:
        result=len(pp20.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p20.append(pp)
        
    for i in slot2:
        result=len(pp21.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p21.append(pp)
        
    for i in slot2:
        result=len(pp22.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p22.append(pp)
        
    for i in slot2:
        result=len(pp23.findall(i))
        if result>0:
            pp=result
        else:
            pp=0
        p23.append(pp)
        
   


#data2011={'article':article,u'不确定':u,u'经济':e1,u'商业':e2,u'政策':p1,u'财政':p2,u'货币':p3,\
 #     u'证监会':p4,u'银监会':p5,u'财政部':p6,u'人民银行':p7,u'国家发改委':p8,\
 #     u'银行':p9,u'外汇':p10,u'规则':p11,u'决策':p12,u'开放':p13,u'改革':p14,\
 #     u'规定':p15,u'商务部':p16,u'法律':p17,u'法规':p18,u'税':p19,u'赤字':p20,\
 #     u'国债':p21,u'政府债务':p22,u'央行':p23,u'主席':p24,u'利率':p25}

##data2011={'article':article,'epu':epu}

##epu2011.groupby(index).max()


##os.chdir('/Users/dingqianliu/Documents/my dissertation/data_csv')
##epu2011.to_csv('epu2011.csv',encoding='utf-8')

import datetime

start=datetime.date(2016,12,31)
date=[]
i=0
while i<len(article):
    if i<len(article)-1:
        if article[i-1]<article[i]:
            time=str(start)
            date.append(time)
            i+=1
        else:
            start=start+datetime.timedelta(days=1)
            time=str(start)
            date.append(time)
            i+=1
    else:
        date.append(time)
        i+=1
    
len(article)
len(date)

u=[]
e=[]
p=[]

for i in range(len(article)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(article)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(article)):        
    if p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0 or \
       p16[i]>0 or \
       p17[i]>0 or \
       p18[i]>0 or \
       p19[i]>0 or \
       p20[i]>0 or \
       p21[i]>0 or \
       p22[i]>0 or \
       p23[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(u)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 
len(e)
len(p)
len(u)
len(epu)

len(article)
len(date)

import pandas as pd       
data2007={'count':article,'e':e,'p':p,'u':u,'epu':epu,'date':date}
epu2007=pd.DataFrame(data=data2007,index=date)

cc=epu2007.groupby('date').sum().reset_index()
bb=epu2007.groupby('date').max().reset_index()
date_sort=bb['date']
article_sort=bb['count']
epu_sort=cc['epu']
e_sort=cc['e']
p_sort=cc['p']
u_sort=cc['u']

epu2007_sorted=pd.concat([date_sort,epu_sort,article_sort,e_sort,p_sort,u_sort],axis=1)
epu2007_sorted['epu_count']=epu2007_sorted['epu']/epu2007_sorted['count']
epu2007_sorted['epu_econ']=epu2007_sorted['epu']/epu2007_sorted['e']

epu2007_sorted.head(10)

epu2007_sorted.set_index('date',inplace=True)
epu2007_sorted.to_csv('r_epu2017_e.csv',encoding='utf-8')

