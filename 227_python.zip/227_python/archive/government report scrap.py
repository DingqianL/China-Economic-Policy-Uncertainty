# -*- coding: utf-8 -*-
"""
Created on Sat Sep  1 19:36:58 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 11 15:10:31 2018

@author: dingq
"""
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 15:33:52 2018

@author: dingq
"""




'''现在的问题是要将这些步骤连接起来:
    1. 打开某一天的第一版页面，并爬取当天所有版面的链接，保存在list中
    2. 写loop，爬取每个版面的文章列表链接，保存在list中
    3. 将列表链接和网站general链接组合起来，保存在list中
    4. 写loop，爬取当天报纸每一天的文章
    
    '''
'''第一步：爬取当天所有版面的链接，保存在list中'''
#准备好软件包
from bs4 import BeautifulSoup
import urllib.request
import re
import time
import os
import http

#提取当天第一版的 URL 的HTML内容
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
general='http://www.gov.cn/guowuyuan/baogao.htm'

newpath = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\government report'
if not os.path.exists(newpath):
    os.makedirs(newpath)
os.chdir(newpath)



try:
    f=urllib.request.urlopen(general)
    response=f.read()
#用BeautifulSoup解析数据，'html.parser'在python3中是必须
    html=BeautifulSoup(response,'html.parser')
except urllib.error.HTTPError:
    print('urllib.error.HTTPError')  
    #出现错误，停几秒先    
except http.client.IncompleteRead:
    print('IncompleteRead')
    time.sleep(2)
    f=urllib.request.urlopen(general)
    response=f.read()

#提取版面链接
pagelink=html.find_all('a')
links=[]
for i in pagelink:
    page=i.get('href')
    links.append(page)

links=links[5:]
links=links[:-2]

len(links)

links_u=[]
for i in links:
    i=i[:-2]
    links_u.append(i)
'''2. 写loop，爬取每个版面的文章列表链接，保存在list中'''

'''3. 将列表链接和网站general链接组合起来，保存在list中'''
'''4. 写loop，爬取当天报纸每一天的文章'''



##设置休息时间，以免把server搞摊了
#del title_links[3]

m=0
while m<len(links_u):
    try:
        gov_request=urllib.request.Request(url=links_u[m], headers=headers)
        gov_response=urllib.request.urlopen(gov_request)
        response=gov_response.read()
        html=BeautifulSoup(response,'html.parser')
        content=html.find_all(id='Zoom')#找到文章的内容
        for j in content:
            text=j.get_text()
    #print(text_all)
        with open(str(m)+'.txt','w',encoding='utf8') as f:
            f.write(text)
        time.sleep(8)
        m=m+1
    except http.client.IncompleteRead:
        print('IncompleteRead')
        time.sleep(2)
        m=m
    except urllib.error.HTTPError:
        print('urllib.error.HTTPError')  
        time.sleep(4)#出现错误，停几秒先
        m=m+1
    except http.client.RemoteDisconnected:
        print('RemoteDisconnected')
        time.sleep(2)
        m=m


#import http.client
#http.client.HTTPConnection._http_vsn = 11
#http.client.HTTPConnection._http_vsn_str = 'HTTP/1.1'