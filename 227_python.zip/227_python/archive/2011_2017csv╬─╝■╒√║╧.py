#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 20:05:53 2018

@author: dingqianliu
"""


import os
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_csv\less policy 2007-2018')
path=os.listdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_csv\less policy 2007-2018')
len(path)
path=path[1:12]


import pandas as pd
df2007=pd.read_csv(path[0])
df2008=pd.read_csv(path[1])
df2009=pd.read_csv(path[2])
df2010=pd.read_csv(path[3])
df2011=pd.read_csv(path[4])
df2012=pd.read_csv(path[5])
df2013=pd.read_csv(path[6])
df2014=pd.read_csv(path[7])
df2015=pd.read_csv(path[8])
df2016=pd.read_csv(path[9])
df2017=pd.read_csv(path[10])

df07_08=df2007.append(df2008)
df07_08_09=df07_08.append(df2009)
df07_08_09_10=df07_08_09.append(df2010)
df07_08_09_10_11=df07_08_09_10.append(df2011)
df07_08_09_10_11_12=df07_08_09_10_11.append(df2012)
df07_08_09_10_11_12_13=df07_08_09_10_11_12.append(df2013)
df07_08_09_10_11_12_13_14=df07_08_09_10_11_12_13.append(df2014)
df07_08_09_10_11_12_13_14_15=df07_08_09_10_11_12_13_14.append(df2015)
df07_08_09_10_11_12_13_14_15_16=df07_08_09_10_11_12_13_14_15.append(df2016)
df07_08_09_10_11_12_13_14_15_16_17=df07_08_09_10_11_12_13_14_15_16.append(df2017)
df07_08_09_10_11_12_13_14_15_16_17.head(10)

df07_08_09_10_11_12_13_14_15_16_17=df07_08_09_10_11_12_13_14_15_16_17.rename(columns={'article':'count'})
df07_08_09_10_11_12_13_14_15_16_17=df07_08_09_10_11_12_13_14_15_16_17.rename(columns={'epu_article':'epu_count'})


date_test=list(df07_08_09_10_11_12_13_14_15_16_17['date'])

type(date_test[1])
date_test[:3]

from datetime import datetime

date_test_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_test]
date_test_changed[:3]
df07_08_09_10_11_12_13_14_15_16_17['date']=date_test_changed


epu_std=df07_08_09_10_11_12_13_14_15_16_17['epu_count'].std()

df07_08_09_10_11_12_13_14_15_16_17['epu_std']\
=df07_08_09_10_11_12_13_14_15_16_17['epu_count']/epu_std
epu_mean=df07_08_09_10_11_12_13_14_15_16_17['epu_std'].mean()

df07_08_09_10_11_12_13_14_15_16_17['epu_normalized']\
=df07_08_09_10_11_12_13_14_15_16_17['epu_std']/epu_mean*100
df07_08_09_10_11_12_13_14_15_16_17.describe()

df07_08_09_10_11_12_13_14_15_16_17.head(n=10)
df07_08_09_10_11_12_13_14_15_16_17.tail(n=10)

df07_08_09_10_11_12_13_14_15_16_17.to_csv('r_epu_daily_normalized2008-2017.csv',encoding='utf-8')


date_date=df07_08_09_10_11_12_13_14_15_16_17['date']

date_date=date_date.tolist()

import datetime
date_time=[]
for i in date_date:
    i=str(i)
    datetime0=datetime.datetime.strptime(i,'%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y-%m')
    month_time.append(month_time0)

len(month_time)

df07_08_09_10_11_12_13_14_15_16_17['month']=month_time

df07_08_09_10_11_12_13_14_15_16_17['month']

df_month=df07_08_09_10_11_12_13_14_15_16_17.groupby('month').sum().reset_index()
df_month['epu_count']=df_month['epu']/df_month['count']

df_month.head(n=10)

df_month.describe()
std2=df_month['epu_normalized'].std()
df_month['epu_month_std']=df_month['epu_normalized']/std2

mean2=df_month['epu_month_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('r_epu_month_2007-2017.csv',encoding='utf-8')

