# -*- coding: utf-8 -*-
"""
Created on Thu Oct 18 14:08:57 2018

@author: dingq
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import re
import pandas as pd
import os'

url = "http://data.people.com.cn/rmrb/20181018/1/a2839e24514a482bad3a87816aaa8f51"

# create a new Firefox session
driver = webdriver.Chrome()
driver.implicitly_wait(10)
driver.get(url)

python_button = driver.find_element_by_class_name('next') #FHSU
python_button.click() #click fhsu link

#Selenium hands the page source to Beautiful Soup
soup_level1=BeautifulSoup(driver.page_source, 'lxml')

datalist = [] #empty list
x = 0 #counter

for link in soup_level1.find_all('a', id=re.compile("^MainContent_uxLevel2_JobTitles_uxJobTitleBtn_")):
    ##code to execute in for loop goes here