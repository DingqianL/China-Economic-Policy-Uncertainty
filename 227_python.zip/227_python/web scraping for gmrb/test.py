# -*- coding: utf-8 -*-
"""
Created on Sun Jul  1 10:36:22 2018

@author: dingq
"""

import  requests
import threading
from bs4 import BeautifulSoup
import re
import os
import time


#请求头字典
import requests

page = requests.get("http://gmrb.egreenapple.com/web/article.html")
page
page.status_code
'''
We won't fully dive into status codes here, 
but a status code starting with a 2 generally indicates success, 
and a code starting with a 4 or a 5 indicates an error.
'''
page.content

#Parsing a page with BeautifulSoup
''' use the BeautifulSoup library to parse this document, 
and extract the text from the p tag.'''
soup = BeautifulSoup(page.content, 'html.parser')


'''from bs4 import BeautifulSoup
soup = BeautifulSoup(page.content, 'html.parser')
We can now print out the HTML content of the page, 
formatted nicely, using the prettify method on the BeautifulSoup object:'''
print(soup.prettify())


'''As all the tags are nested, 
we can move through the structure one level at a time. 
We can first select all the elements at the top level of the page 
using the children property of soup. Note that children returns a list generator, 
so we need to call the list function on it:'''
list(soup.children)


#Let's see what the type of each element in the list is:

[type(item) for item in list(soup.children)]

