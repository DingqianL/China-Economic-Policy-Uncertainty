# -*- coding: utf-8 -*-
"""
Created on Wed Jul 25 09:31:01 2018

@author: dingq
"""

from selenium import webdriver #I'm going to use chrome
from selenium.webdriver.common.keys import Keys # to support keys on the keyboard

driver = webdriver.Chrome()

driver.get("http://gmrb.egreenapple.com//index_wenzhang.html")
element = driver.find_element_by_id("titleList")

elem.clear()
elem.send_keys("pycon")
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()


element = driver.find_element_by_id("titleList")

elem.clear()
elem.send_keys("pycon")
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()


