# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 16:01:26 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 11:39:12 2018

@author: dingq
"""
%logstart 
!pip install jieba
import jieba


with open('2002.txt','r+') as f:
    text=f.read()

seg_list=jieba.cut(text,cut_all=False)
print("Default Mode: " + "/ ".join(seg_list)) 



