# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 22:31:32 2019

@author: dingq
"""

# import module
from selenium import webdriver
#from selenium.webdriver.common.keys import Keys
import time
import random
import numpy as np
import pandas as pd
import os
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\SCMP1949_')
#set up chrome driver
driver = webdriver.Chrome()

# open the website to scrap from
driver.get("https://urldefense.proofpoint.com/v2/url?u=http-3A__proxy.uchicago.edu_login-3Furl-3Dhttps-3A__search.proquest.com_hnpsouthchinamorningpost_index-3Faccountid-3D14657&d=DwIGaQ&c=U0G0XJAMhEk_X0GAGzCL7Q&r=ygMmKkki3HchkGmvJMmTvmYX9l-sDfRJUzVcS3ane-8&m=mbbcWcFx6rZHHT7hcKxfJenmbQe83WJ4cwAuC0E-t8U&s=OoyP7EtUkCJtVcWNiiOqaxoJrzAPtsLAabqCm9bBJS4&e=")
time.sleep(10) # to fully load the page
element = driver.find_element_by_name("searchTerm")
element.send_keys("ft(uncertain OR uncertainty)")

startdates= pd.date_range('1984-11-01','1995-01-01' , freq='1M')-pd.offsets.MonthBegin(1)
startdates = startdates.tolist()
startdates = [d.strftime('%Y-%m-%d') for d in startdates ]

enddates= pd.date_range('1984-12-31','1995-01-31' , freq='1M')-pd.offsets.MonthEnd(1)
enddates = enddates.tolist()
enddates = [d.strftime('%Y-%m-%d') for d in enddates ]

len(startdates) == len(enddates)

u = []
for i in range(len(enddates)):
    
    element2 = driver.find_element_by_id("startingDate")
    element2.clear()
    element2.send_keys(startdates[i])
    
    
    element3 = driver.find_element_by_id("endingDate")
    element3.clear()
    element3.send_keys(enddates[i])
    
    element4 = driver.find_element_by_id("dateRangeSubmit")
    element4.click()
    
    c = driver.find_element_by_id("pqResultsCount")
    c = c.text
    u.append(c)
    
    time.sleep(int(np.random.randint(low=0.5, high=8, size=1)))

u1 = ' '.join(u)
with open('term u.txt','w') as f:
    f.write(u1)
    
u_count = [re.findall(r'\d+', i) for i in u]
u_count = [''.join(i) for i in u_count]
u_count = pd.DataFrame({'u': u_count})

element = driver.find_element_by_name("searchTerm")
element.clear()
element.send_keys("ft(economy OR economic)")
element0 = driver.find_element_by_name("uxf-icon uxf-search")
element0.click()

startdates= pd.date_range('1949-10-01','1995-01-01' , freq='1M')-pd.offsets.MonthBegin(1)
startdates = startdates.tolist()
startdates = [d.strftime('%Y-%m-%d') for d in startdates ]

enddates= pd.date_range('1949-11-30','1995-01-31' , freq='1M')-pd.offsets.MonthEnd(1)
enddates = enddates.tolist()
enddates = [d.strftime('%Y-%m-%d') for d in enddates ]

len(startdates) == len(enddates)


e0 = []
for i in range(10):
    
    element2 = driver.find_element_by_id("startingDate")
    element2.clear()
    element2.send_keys(startdates[i])
    
    
    element3 = driver.find_element_by_id("endingDate")
    element3.clear()
    element3.send_keys(enddates[i])
    
    element4 = driver.find_element_by_id("dateRangeSubmit")
    element4.click()
    
    c = driver.find_element_by_id("pqResultsCount")
    c = c.text
    e0.append(c)
    
    time.sleep(int(np.random.randint(low=0.5, high=10, size=1)))

e1 = ' '.join(e)
with open('term e.txt','w') as f:
    f.write(e1)


element = driver.find_element_by_name("searchTerm")
element.clear()
element.send_keys(r'''ft(((policy OR spending OR budget OR political OR "interest rates" OR reform) AND (government OR Beijing OR authorities)) OR tax OR regulation OR regulatory OR "central bank" OR "People's Bank of China" OR PBOC OR deficit OR WTO)''')
element0 = driver.find_element_by_name("uxf-icon uxf-search")
element0.click()


p = []
for i in range(len(enddates)):
    
    element2 = driver.find_element_by_id("startingDate")
    element2.clear()
    element2.send_keys(startdates[i])
    
    
    element3 = driver.find_element_by_id("endingDate")
    element3.clear()
    element3.send_keys(enddates[i])
    
    element4 = driver.find_element_by_id("dateRangeSubmit")
    element4.click()
    
    c = driver.find_element_by_id("pqResultsCount")
    c = c.text
    p.append(c)
    
    time.sleep(int(np.random.randint(low=0.5, high=10, size=1)))


p1 = ' '.join(p)
with open('term p.txt','w') as f:
    f.write(p1)
    
import re
p_count = [re.findall(r'\d+', i) for i in p]
p_count = [''.join(i) for i in p_count]
p_count = pd.DataFrame({'p': p_count})

e_count = [re.findall(r'\d+', i) for i in e]
e_count = [''.join(i) for i in e_count]
e_count = pd.DataFrame({'e': e_count})

ep_count = p_count.join(e_count)

date = pd.date_range(start = '19491001', end = '19941231', freq = 'M')

date = pd.DataFrame({'date':date})
date['year'] = date['date'].dt.year
date['month'] = date['date'].dt.month

ep_count = ep_count.join(date)

ep_count.to_csv('ep_count.csv')

