# -*- coding: utf-8 -*-
"""
Created on Fri Jul 13 08:32:21 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 11 15:10:31 2018

@author: dingq
"""
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 15:33:52 2018

@author: dingq
"""




'''现在的问题是要将这些步骤连接起来:
    1. 打开某一天的第一版页面，并爬取当天所有版面的链接，保存在list中
    2. 写loop，爬取每个版面的文章列表链接，保存在list中
    3. 将列表链接和网站general链接组合起来，保存在list中
    4. 写loop，爬取当天报纸每一天的文章
    
    '''
'''第一步：爬取当天所有版面的链接，保存在list中'''
#准备好软件包
from bs4 import BeautifulSoup
import urllib.request
import re
import time
import os


newpath = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb\scrap_greenapple\20070101'
if not os.path.exists(newpath):
    os.makedirs(newpath)
os.chdir(newpath)


headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}

#提取当天第一版的 URL 的HTML内容
f_request=urllib.request.Request(url='http://gmrb.egreenapple.com/search?ChannelID=11893&randno=28070', headers=headers)
f_response=urllib.request.urlopen(f_request)
response_f=f_response.read()
#用BeautifulSoup解析数据，'html.parser'在python3中是必须
html=BeautifulSoup(response_f,'html.parser',from_encoding="gb2312")
print(html.original_encoding)
print(html.encode('gb18030'))
      
with open('test.txt','w', encoding='utf8') as f:
    f.write(str(html))
    
      


#提取版面链接
pagelink=html.find_all(id='pageLink')
res_p=r"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')"
res_pp=re.compile(res_p) #the regular expression to find the URL
links=[]
for i in pagelink:
    page=res_pp.findall(str(i))
    links.append(page)

links=[item for sublist in links for item in sublist]
len(links)

'''2. 写loop，爬取每个版面的文章列表链接，保存在list中'''

#提取该版面上每篇文章的链接
general='http://epaper.gmw.cn/gmrb/html/2008-01/26/'
page_links=[]
for i in links:
    page_link=general+i
    page_links.append(page_link)
    
len(page_links)

title_lists=[]
for i in page_links:
    f=urllib.request.urlopen(i)
    response=f.read()
    html=BeautifulSoup(response,'html.parser')
    title_list=html.find_all(id='titleList')
    titles=res_pp.findall(str(title_list))
    title_lists.append(titles)
    time.sleep(4)
len(title_lists)


'''3. 将列表链接和网站general链接组合起来，保存在list中'''
title_links=[]
for i in title_lists:
    for j in i:
        title_link=general+j
        title_links.append(title_link)
        
len(title_links)

'''4. 写loop，爬取当天报纸每一天的文章'''


##设置休息时间，以免把server搞摊了
#del title_links[3]

for i in title_links[46:]:
    gmrb_request=urllib.request.Request(url=i, headers=headers)
    gmrb_response=urllib.request.urlopen(gmrb_request)
    response=gmrb_response.read()
    html=BeautifulSoup(response,'html.parser')
    title=html.find_all('h1')#找到文章的题目
    date_author=html.find_all(class_='lai')#找到文章的作者和时间
    content=html.find_all(id='articleContent')#找到文章的内容
    all_=title+date_author+content
    text_all=''
    for j in all_:
        text=j.get_text()
        text_all=text_all+text
    #print(text_all)
    with open(str(title_links.index(i))+'.txt','w',encoding='utf8') as f:
        f.write(text_all)
    time.sleep(7)




