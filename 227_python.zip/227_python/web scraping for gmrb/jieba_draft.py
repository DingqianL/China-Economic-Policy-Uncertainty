# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 11:39:12 2018

@author: dingq
"""

####move '.txt' file to another folder
import os
import shutil

a=[2006,2007,2008,2009,2010,2011,2012,2013,2014,2015] #make a list that includes all the year

#the iratation to move the text files
for j in a:
    #make the old path of folders
    old=r'C:\Users\dingq\Downloads\税法报纸\省级\65.新疆维吾尔自治区\新疆日报'+'\\'+str(j)
    #make the new path of folders
    new=r'C:\Users\dingq\Documents\200_academic\260_project\Tax\regional\xinjiang'+'\\'+str(j)
    #make the new folder
    if not os.path.exists(new):
        os.makedirs(new)
    #list all the files in the old folder
    files=os.listdir(old)
    #filter out all the text files in the old foler
    txtfiles=[f for f in files if f.endswith(".txt")]
    #itaration to move text file from old foler to new folder
    for i in txtfiles:
        #make the path of each text files
        txtdire=old+"\\"+i
        #move the files （not copy) to the new folder with shutil module
        shutil.move(txtdire, new)

##将txt文件存入dataframe中,先对全国性报纸
#import modules
import os
import pandas as pd
#set the target path
path=r'C:\Users\dingq\Documents\200_academic\260_project\Tax\national'
#get all the year folder in the target folder
years=os.listdir(path)

#generate empty dataframe and list
dataframe=pd.DataFrame()
year=[]
titles=[]
texts=[]

#iteration to analyze files for all national text files
for i in years:                     #in every file folder of 'year', such as '2006'
    path1=path+'\\'+i               #get into the folder of year
    files=os.listdir(path1)         #list the txt files in each year folder
        
    for j in files:                 #iteration to get title for each article
        file=path1+'\\'+j           #get the path for each article
        title=j[:-4]                #get individual article's title
        yes=i                       #code year for each article
        #read one text file and delete all spaces and line change
        with open(file, encoding='utf8', errors='ignore') as f:
            text=f.read()           #read one file 
            text=text.replace(' ', '')
            text=text.replace('\n', '')
        #put article in each corespondense list
        titles.append(title)
        year.append(yes)
        texts.append(text)

#put the list in the data frame
dataframe['title']=titles
dataframe['year']=year
dataframe['text']=texts
os.chdir(r'C:\Users\dingq\Documents\200_academic\260_project\Tax')
dataframe.to_excel('national_raw.xlsx', encoding='utf8')

    
###others example    
import numpy as np
import pandas as pd
import jieba
import jieba.analyse
import codecs

#设置pd的显示长度
#pd.set_option('max_colwidth',500)


segments = []
for i in texts:
    #TextRank 关键词抽取，只获取固定词性
    words = jieba.analyse.extract_tags(i, topK=10,withWeight=True,allowPOS=('ns', 'n', 'vn', 'v'))
    segments.append(words)
    
    segment=[]
    for word, weight in words:
        # 记录全局分词
        segment.append({'word':word, 'weight':weight,'count':1})
        segments.append(segment)
dfSg = pd.DataFrame(segments)
dfSg.to_excel('national _weight.xlsx', encoding='utf8')

#####################
#####对省级报纸，将txt文件存入dataframe中

import os
import pandas as pd
path=r'C:\Users\dingq\Documents\200_academic\260_project\Tax\regional'
provinces=os.listdir(path)


dataframe=pd.DataFrame()
year=[]
titles=[]
texts=[]
province=[]
for i in provinces:                 #in every file folder of 'province', like 'anhui'
    path1=path+'\\'+i               #get into the folder of province,
    years=os.listdir(path1)         #list the txt files in each year folder
    for n in years:
        path2=path1+'\\'+n          #get into the folder of each province for each year
        files=os.listdir(path2)     #get all the text files in each year's folder in list
        for j in files:
            file=path2+'\\'+j       #get the path for each text file
            title=j[:-4]            #get the title for each text file
            yes=n                   #get the year for each text file
            pro=i                   #get the province for each text files
            #open and read each text file
            with open(file, encoding='utf8', errors='ignore') as f:
                text=f.read()           #read one file 
                #remove the space and line changes
                text=text.replace(' ', '')
                text=text.replace('\n', '')
            titles.append(title)    #put title of each article in a list
            year.append(yes)        #put year of each article in a list
            texts.append(text)      #put text of each article in a list
            province.append(pro)    #put province of each article in a list
        
dataframe['year']=year
dataframe['province']=province
dataframe['title']=titles
dataframe['text']=texts
os.chdir(r'C:\Users\dingq\Documents\200_academic\260_project\Tax')
dataframe.to_excel('regional_raw.xlsx', encoding='utf8')

    
###others example    
import numpy as np
import pandas as pd
import jieba
import jieba.analyse
import codecs

#设置pd的显示长度
pd.set_option('max_colwidth',500)

segments = []
for i in texts:
    #TFIDF 关键词抽取，只获取固定词性
    words = jieba.analyse.extract_tags(i, topK=10,withWeight=True,allowPOS=('ns', 'n', 'vn', 'v'))
    segments.append(words)
    
dfSg = pd.DataFrame(segments)

dfSg.to_excel('regional _weight.xlsx', encoding='utf8')

# 词频统计
dfWord = dfSg.groupby('word')['count'].sum()

#导出excel
dfWord.to_excel('keywords_regional_top5_tfidf.xlsx', encoding='utf-8')
    
    
    