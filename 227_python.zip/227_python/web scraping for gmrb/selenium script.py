# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 10:11:07 2018

@author: dingq
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys

import sys
print(sys.path)

driver = webdriver.Chrome()

driver.get("http://gmrb.egreenapple.com/index_wenzhang.html")
element = driver.find_element_by_id("titleList")
element.

elem.clear()
elem.send_keys("pycon")
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()


driver.

