# -*- coding: utf-8 -*-
"""
Created on Fri Sep  7 15:04:47 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 11 15:10:31 2018

@author: dingq
"""
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  9 15:33:52 2018

@author: dingq
"""




'''现在的问题是要将这些步骤连接起来:
    1. 打开某一天的第一版页面，并爬取当天所有版面的链接，保存在list中
    2. 写loop，爬取每个版面的文章列表链接，保存在list中
    3. 将列表链接和网站general链接组合起来，保存在list中
    4. 写loop，爬取当天报纸每一天的文章
    
    '''
'''第一步：爬取当天所有版面的链接，保存在list中'''
#准备好软件包
from bs4 import BeautifulSoup
import urllib.request
import re
import time
import os
import http


a='20070101'
#提取当天第一版的 URL 的HTML内容
headers1={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36'}
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
general='http://data.people.com.cn/rmrb'+'/'+a
add_on='/1'

newpath = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\rmrb_re_scrap2'+'\\'+a
if not os.path.exists(newpath):
    os.makedirs(newpath)
os.chdir(newpath)



try:
    rmrb_p=urllib.request.Request(url=general+add_on, headers=headers)
    rmrb_p_r=urllib.request.urlopen(rmrb_p)
    response=rmrb_p_r.read()
#用BeautifulSoup解析数据，'html.parser'在python3中是必须
    html=BeautifulSoup(response,'html.parser')
except urllib.error.HTTPError:
    print('urllib.error.HTTPError')  
    #出现错误，停几秒先    
except http.client.IncompleteRead:
    print('IncompleteRead')
    time.sleep(5)
    rmrb_p=urllib.request.Request(url=general+add_on, headers=headers)
    rmrb_p_r=urllib.request.urlopen(rmrb_p)
    response=rmrb_p_r.read()
    html=BeautifulSoup(response,'html.parser')



#提取当天文章总数和版面数
p=re.compile('\d')

article_num=html.find_all(id='UseRmrbNum')
article_num=''.join([str(f) for f in article_num])
article_num=int(''.join(p.findall(article_num)))
article_num=str(article_num)
page_num=html.find_all(id='UseRmrbPageNum')
page_num=''.join([str(f) for f in page_num])
page_num=''.join(p.findall(page_num))

#with open('page.csv', 'a') as f:
#    f.write(article_num)
    
    
#拼接当天所有版面的链接
plist=list(range(1,int(page_num)+1))

plist=['/'+str(f) for f in plist]

pagelink=[general+f for f in plist]



'''2. 写loop，爬取每个版面的文章列表链接，保存在list中'''

#提取该版面上每篇文章的链接
title_lists=[]
m=0
while m<len(pagelink):
    try:
        f=urllib.request.Request(url=pagelink[m], headers=headers)
        f=urllib.request.urlopen(f)
        response=f.read()
        html=BeautifulSoup(response,'html.parser')
        title_list=html.find_all('div',class_='title_list')
        title_list=str(title_list)
        res_p=r"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')"
        res_pp=re.compile(res_p) #the regular expression to find the URL
        titles=res_pp.findall(title_list)
        for i in titles:
            fulltitles='http://data.people.com.cn'+i
            title_lists.append(fulltitles)
        time.sleep(5)
        m=m+1
    except http.client.IncompleteRead:
        print('IncompleteRead')
        time.sleep(5)
        m=m
    except urllib.error.HTTPError:
        print('urllib.error.HTTPError')  
        time.sleep(2)#出现错误，停几秒先
        m=m+1
    except http.client.RemoteDisconnected:
        print('RemoteDisconnected')
        time.sleep(2)
        m=m
if int(article_num) == len(title_lists):
    print('Article Numbers correct!')
else:
    print('watch out!')

titles_lists=[]
for i in title_lists:
    m=i+'_print.html'
    titles_lists.append(m)
    
    

'''4. 写loop，爬取当天报纸每一天的文章'''



##设置休息时间，以免把server搞摊了
#del title_links[3]
#from selenium import webdriver
#from selenium.webdriver.chrome.options import Options
import time
#from selenium.webdriver import Firefox
#driver = webdriver.Chrome()
#driver.get("http://data.people.com.cn/rmrb/20070101/1/1d7ed5192a2c47d2a157782cae9e761b")
#time.sleep(3)
#print(driver.find_element_by_id("FontZoom").text)
#driver.close()
#m=13
#chrome_options = Options()
#chrome_options.add_argument("user-data-dir=selenium") 
#driver = webdriver.Chrome(chrome_options=chrome_options)

m=31
while m<len(titles_lists[:38]):
    try:
        rmrb_request=urllib.request.Request(url=titles_lists[m], headers=headers)
        rmrb_response=urllib.request.urlopen(rmrb_request)
        response=rmrb_response.read()
        html=BeautifulSoup(response,'html.parser')
        title=html.find_all('div',class_='title')#找到文章的题目
        #title=''.join(str([f for f in title]))
        content=html.find_all(id='FontZoom')#找到文章的作者和时间
        #driver = webdriver.Chrome()
        #driver.implicitly_wait(0)
        #driver.get('http://data.people.com.cn/rmrb/20070101/1/1d7ed5192a2c47d2a157782cae9e761b')
        #time.sleep(2)
        #element=driver.find_element_by_class_name('next')
        #content=driver.find_element_by_id("FontZoom").text#找到文章的内容
        all_=title+content
        text_all=''
        for j in all_:
            text=j.get_text()
            text_all=text_all+text
        #all_=content
    #print(text_all)
        with open(str(m)+'.txt','w',encoding='utf8') as f:
            f.write(text_all)
        #driver.quit()
        time.sleep(10)
        m=m+1
    except http.client.IncompleteRead:
        print('IncompleteRead')
        time.sleep(2)
        m=m
    except urllib.error.HTTPError:
        print('urllib.error.HTTPError')  
        time.sleep(4)#出现错误，停几秒先
        m=m+1
    except http.client.RemoteDisconnected:
        print('RemoteDisconnected')
        time.sleep(2)
        m=m


#import http.client
#http.client.HTTPConnection._http_vsn = 11
#http.client.HTTPConnection._http_vsn_str = 'HTTP/1.1'