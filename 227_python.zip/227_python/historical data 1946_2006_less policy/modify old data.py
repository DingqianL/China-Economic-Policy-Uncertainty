# -*- coding: utf-8 -*-
"""
Created on Wed May 30 14:01:59 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 12:14:20 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 12:11:49 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 12:09:20 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 12:04:46 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 12:02:56 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 11:58:56 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 11:55:42 2018

@author: dingq
"""
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 11:37:23 2018

@author: dingq
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 10:34:39 2018

"""



### New and full data received on Mar 28 2018
### However, the data come in annually, that is all the newspaper in one year came in a singel text file.

##before data, put all text files into one file
import os
path=r'C:\Users\dingq\Documents\人民日报 1946-2010\update\19681231'
os.chdir(path)
files=os.listdir(path)

#,encoding='utf-8'

with open('19681231.txt','w+',encoding='utf-8') as fff:
    for i in files:
        with open(i,'r+',encoding='utf-8') as f:
            file=f.read()
            fff.write(file)
        

## step 1: split the file into single article with date label



#import modules
import os 
import re
import pandas as pd

#open and read text file
#os.chdir(r'C:\Users\dingq\Documents\人民日报 1946-2010\update\198104')
file=r'19681231.txt'

with open(file,'r+',encoding='utf-8') as f:
    text=f.read()
text=text.replace(' ', '') #delete space
text=text.replace('\n','') #delete lines

#identify dates and split annual text into single article with date label
datepattern=re.compile(r'\d{4}.\d{2}.\d{2}')
match = re.split(datepattern, text) #split into single article
dateextract=re.findall(datepattern,text) #identify dates

date=[i.replace('.','-') for i in dateextract] #formalize date
del match[0]
##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
articlelist=pd.DataFrame(data=match, index=date)
#articlelist.info() 
articlelist['date']=date


##compile key words
uncertainty1=u'不确定'
uncertainty2=u'不明确'
uncertainty3=u'不明朗'
uncertainty4=u'未明'
uncertainty5=u'难料'
uncertainty6=u'难以预计'
uncertainty7=u'难以估计'
uncertainty8=u'难以预测'
uncertainty9=u'难以预料'
uncertainty10=u'未知'

economy1=u'经济'
economy2=u'商业'

policy2=u'财政'
policy3=u'货币'
policy4=u'证监会'
policy5=u'银监会'
policy6=u'财政部'
policy7=u'人民银行'
policy8=u'国家发改委'
policy9=u'银行'
policy11=u'规则'
policy12=u'决策'
policy13=u'开放'
policy14=u'改革'
policy15=u'规定'
policy16=u'商务部'
policy17=u'法律'
policy18=u'法规'
policy19=u'税'
policy20=u'赤字'
policy21=u'国债'
policy22=u'政府债务'
policy23=u'央行'


pu1=re.compile(uncertainty1)
pu2=re.compile(uncertainty2)
pu3=re.compile(uncertainty3)
pu4=re.compile(uncertainty4)
pu5=re.compile(uncertainty5)
pu6=re.compile(uncertainty6)
pu7=re.compile(uncertainty7)
pu8=re.compile(uncertainty8)
pu9=re.compile(uncertainty9)
pu10=re.compile(uncertainty10)

pe1=re.compile(economy1)
pe2=re.compile(economy2)

pp2 =re.compile(policy2)
pp3 =re.compile(policy3)
pp4 =re.compile(policy4)
pp5 =re.compile(policy5)
pp6 =re.compile(policy6)
pp7 =re.compile(policy7)
pp8 =re.compile(policy8)
pp9 =re.compile(policy9)
pp11 =re.compile(policy11)
pp12 =re.compile(policy12)
pp13 =re.compile(policy13)
pp14 =re.compile(policy14)
pp15 =re.compile(policy15)
pp16 =re.compile(policy16)
pp17 =re.compile(policy17)
pp18 =re.compile(policy18)
pp19 =re.compile(policy19)
pp20 =re.compile(policy20)
pp21 =re.compile(policy21)
pp22 =re.compile(policy22)
pp23 =re.compile(policy23)

# a function to compile keywords
def keywords(article,keyword):
    counts=[]
    for i in article:
        result=len(keyword.findall(i))
        if result>0:
            count=result
        else:
            count=0  
        counts.append(count)
    return counts
    
# save count of keywords into DataFrame
u1=keywords(match,pu1)
articlelist['u1']=u1
u2=keywords(match,pu2)
articlelist['u2']=u2
u3=keywords(match,pu3)
articlelist['u3']=u3
u4=keywords(match,pu4)
articlelist['u4']=u4
u5=keywords(match,pu5)
articlelist['u5']=u5
u6=keywords(match,pu6)
articlelist['u6']=u6
u7=keywords(match,pu7)
articlelist['u7']=u7
u8=keywords(match,pu8)
articlelist['u8']=u8
u9=keywords(match,pu9)
articlelist['u9']=u9
u10=keywords(match,pu10)
articlelist['u10']=u10

e1=keywords(match,pe1)
articlelist['e1']=e1
e2=keywords(match,pe2)
articlelist['e2']=e2

p2 =keywords(match,pp2)
articlelist['p2']=p2
p3 =keywords(match,pp3)
articlelist['p3']=p3
p4 =keywords(match,pp4)
articlelist['p4']=p4
p5 =keywords(match,pp5)
articlelist['p5']=p5
p6 =keywords(match,pp6)
articlelist['p6']=p6
p7 =keywords(match,pp7)
articlelist['p7']=p7
p8 =keywords(match,pp8)
articlelist['p8']=p8
p9 =keywords(match,pp9)
articlelist['p9']=p9
p11 =keywords(match,pp11)
articlelist['p11']=p11
p12 =keywords(match,pp12)
articlelist['p12']=p12
p13 =keywords(match,pp13)
articlelist['p13']=p13
p14 =keywords(match,pp14)
articlelist['p14']=p14
p15 =keywords(match,pp15)
articlelist['p15']=p15
p16 =keywords(match,pp16)
articlelist['p16']=p16
p17 =keywords(match,pp17)
articlelist['p17']=p17
p18 =keywords(match,pp18)
articlelist['p18']=p18
p19 =keywords(match,pp19)
articlelist['p19']=p19
p20 =keywords(match,pp20)
articlelist['p20']=p20
p21 =keywords(match,pp21)
articlelist['p21']=p21
p22 =keywords(match,pp22)
articlelist['p22']=p22
p23 =keywords(match,pp23)
articlelist['p23']=p23
    
###generate index epu
u=[]
e=[]
p=[]

for i in range(len(match)):        
    if u1[i]>0 or \
       u2[i]>0 or \
       u3[i]>0 or \
       u4[i]>0 or \
       u5[i]>0 or \
       u6[i]>0 or \
       u7[i]>0 or \
       u8[i]>0 or \
       u9[i]>0 or \
       u10[i]>0:
           u0=1
           u.append(u0)
    else:
        u0=0
        u.append(u0)

for i in range(len(match)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)
        
for i in range(len(match)):        
    if p2[i]>0 or \
       p3[i]>0 or \
       p4[i]>0 or \
       p5[i]>0 or \
       p6[i]>0 or \
       p7[i]>0 or \
       p8[i]>0 or \
       p9[i]>0 or \
       p11[i]>0 or \
       p12[i]>0 or \
       p13[i]>0 or \
       p14[i]>0 or \
       p15[i]>0 or \
       p16[i]>0 or \
       p17[i]>0 or \
       p18[i]>0 or \
       p19[i]>0 or \
       p20[i]>0 or \
       p21[i]>0 or \
       p22[i]>0 or \
       p23[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

         
epu=[]
for i in range(len(match)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)
 
len(e)
len(p)
len(u)
len(epu)

#put epu index into DataFrame
articlelist['e']=e
articlelist['p']=p
articlelist['u']=u
articlelist['epu']=epu

articlelist=articlelist.rename(columns={0:'match'})
articlelist.columns

###step3: generate epu daily index
epu_test=articlelist.filter(['date','epu'],axis=1)
#epu_test.count()

epu_test1=epu_test.groupby('date').sum()
epu_test1['date']=epu_test1.index


epu_test1.head(10)
epu_test1.drop(epu_test1.index[:4], inplace=True)
epu_test1.drop(epu_test1.index[-20:], inplace=True)
epu_test1.to_csv('epu_test1.csv')


epu_test2=epu_test.groupby('date').size()
epu_test2.drop(epu_test2.index[:4], inplace=True)
epu_test2.drop(epu_test2.index[-20:], inplace=True)


epu_test2.head(10)
epudaily=pd.concat([epu_test1,epu_test2],axis=1)
epudaily=epudaily.rename(columns={0:'count'})

epudaily.drop('date', axis=1, inplace=True)
epudaily['epu_count']=epudaily['epu']/epudaily['count']

epudaily.head(10)
epudaily.to_csv('fix_19681231.csv')


