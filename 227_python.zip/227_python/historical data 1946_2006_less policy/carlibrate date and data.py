# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 14:02:07 2018

@author: dingq
"""

#####data processing
from datetime import datetime
import pandas as pd
import os

#date_today = datetime.now().date()
#days = pd.date_range(date_today, date_today + timedelta(7), freq='D')

from datetime import date
d0=date(1946,5,15)
d1=date(2017,12,31)
d2=date(1946,12,31)
delta=d1-d0
delta2=d2-d0
period=delta.days+1
print(delta2.days)


fulldate=pd.date_range("19460515", periods=period)
fulldate_string=[i.strftime('%m/%d/%Y') for i in fulldate]
fulldate_datetime=[datetime.strptime(d,'%m/%d/%Y').date() for d in fulldate_string]
fullrange=pd.DataFrame(fulldate_datetime)
fullrange=fullrange.rename(columns={0:'date'})
fullrange.head(10)
fullrange.tail(10)
fullrange.count


os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_csv\reduced1946-2006')
epudaily1946=pd.read_csv('r_epudaily1946.csv')
epudaily1946.count

epudaily1946.head(10)
date_tochange=list(epudaily1946['date'])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%m/%d/%Y').date() for d in date_tochange]
epudaily1946['date']=date_changed
epudaily1946.count

epudaily1946.head(10)
epudaily1946.tail(10)
merge1946=pd.merge(fullrange, epudaily1946,how='outer')
merge1946.count
merge1946.tail(10)
merge1946.head(10)
merge1946.to_csv('merge1946_2.csv')

##input for 1947
epudaily1947=pd.read_csv('r_epudaily1947.csv')
epudaily1947.count


epudaily1947.head(10)
date_tochange=list(epudaily1947['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1947['date']=date_changed
epudaily1947.count

##input for 1948
epudaily1948=pd.read_csv('r_epudaily1948.csv')
epudaily1948.count


epudaily1948.head(10)
date_tochange=list(epudaily1948['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1948['date']=date_changed
epudaily1948.count

##input for 1949
epudaily1949=pd.read_csv('r_epudaily1949.csv')
epudaily1949.count


epudaily1949.head(10)
date_tochange=list(epudaily1949['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1949['date']=date_changed
epudaily1949.count


##input for 1950
epudaily1950=pd.read_csv('r_epudaily1950.csv')
epudaily1950.count


epudaily1950.head(10)
date_tochange=list(epudaily1950['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1950['date']=date_changed
epudaily1950.count

##input for 1951
epudaily1951=pd.read_csv('r_epudaily1951.csv')
epudaily1951.count


epudaily1951.head(10)
date_tochange=list(epudaily1951['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1951['date']=date_changed
epudaily1951.count

##input for 1952
epudaily1952=pd.read_csv('r_epudaily1952.csv')
epudaily1952.count


epudaily1952.head(10)
date_tochange=list(epudaily1952['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1952['date']=date_changed
epudaily1952.count

##input for 1953
epudaily1953=pd.read_csv('r_epudaily1953.csv')
epudaily1953.count


epudaily1953.head(10)
date_tochange=list(epudaily1953['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1953['date']=date_changed
epudaily1953.count

##input for 1954
epudaily1954=pd.read_csv('r_epudaily1954.csv')
epudaily1954.count


epudaily1954.head(10)
date_tochange=list(epudaily1954['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1954['date']=date_changed
epudaily1954.count

##input for 1955
epudaily1955=pd.read_csv('r_epudaily1955.csv')
epudaily1955.count


epudaily1955.head(10)
date_tochange=list(epudaily1955['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1955['date']=date_changed
epudaily1955.count

##input for 1956
epudaily1956=pd.read_csv('r_epudaily1956.csv')
epudaily1956.count


epudaily1956.head(10)
date_tochange=list(epudaily1956['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1956['date']=date_changed
epudaily1956.count


##input for 1957
epudaily1957=pd.read_csv('r_epudaily1957.csv')
epudaily1957.count


epudaily1957.head(10)
date_tochange=list(epudaily1957['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1957['date']=date_changed
epudaily1957.count

##input for 1958
epudaily1958=pd.read_csv('r_epudaily1958.csv')
epudaily1958.count


epudaily1958.head(10)
date_tochange=list(epudaily1958['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1958['date']=date_changed
epudaily1958.count

##input for 1959
epudaily1959=pd.read_csv('r_epudaily1959.csv')
epudaily1959.count


epudaily1959.head(10)
date_tochange=list(epudaily1959['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1959['date']=date_changed
epudaily1959.count

##input for 1960
epudaily1960=pd.read_csv('r_epudaily1960.csv')
epudaily1960=epudaily1960[epudaily1960.date !='1960-10\u300018']
#epudaily1960.to_csv('1960test.csv')
epudaily1960.head(10)
date_tochange=list(epudaily1960['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1960['date']=date_changed
epudaily1960.reset_index(drop=True)
epudaily1960.count


##input for 1961
epudaily1961=pd.read_csv('r_epudaily1961.csv')
epudaily1961.count


epudaily1961.head(10)
date_tochange=list(epudaily1961['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1961['date']=date_changed
epudaily1961.count


##input for 1962
epudaily1962=pd.read_csv('r_epudaily1962.csv')
epudaily1962.count


epudaily1962.head(10)
date_tochange=list(epudaily1962['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1962['date']=date_changed
epudaily1962.count

##input for 1963
epudaily1963=pd.read_csv('r_epudaily1963.csv')
epudaily1963.count


epudaily1963.head(10)
date_tochange=list(epudaily1963['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1963['date']=date_changed
epudaily1963.count

##input for 1964
epudaily1964=pd.read_csv('r_epudaily1964.csv')
epudaily1964.count


epudaily1964.head(10)
date_tochange=list(epudaily1964['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1964['date']=date_changed
epudaily1964.count


##input for 1965
epudaily1965=pd.read_csv('r_epudaily1965.csv')
epudaily1965.count


epudaily1965.head(10)
date_tochange=list(epudaily1965['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1965['date']=date_changed
epudaily1965.count

##input for 1966
epudaily1966=pd.read_csv('r_epudaily1966.csv')
epudaily1966.count


epudaily1966.head(10)
date_tochange=list(epudaily1966['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1966['date']=date_changed
epudaily1966.count


##input for 1967
epudaily1967=pd.read_csv('r_epudaily1967.csv')
epudaily1967.count

epudaily1967.head(10)
date_tochange=list(epudaily1967['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1967['date']=date_changed
epudaily1967.count


##input for 1968
epudaily1968=pd.read_csv('r_epudaily1968.csv')
epudaily1968.count
epudaily1968.columns=['date', 'epu', 'count', 'epu_count']
epudaily1968=epudaily1968.drop(epudaily1968.index[-1])
epudaily1968.tail(10)
date_tochange=list(epudaily1968['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1968['date']=date_changed
epudaily1968.count


##input for 1969
epudaily1969=pd.read_csv('r_epudaily1969.csv')
epudaily1969.count

epudaily1969.head(10)
date_tochange=list(epudaily1969['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1969['date']=date_changed
epudaily1969.count


##input for 1970
epudaily1970=pd.read_csv('r_epudaily1970.csv')
epudaily1970.count

epudaily1970.head(10)
date_tochange=list(epudaily1970['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1970['date']=date_changed
epudaily1970.count



##input for 1971
epudaily1971=pd.read_csv('r_epudaily1971.csv')
epudaily1971.count

epudaily1971.head(10)
date_tochange=list(epudaily1971['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1971['date']=date_changed
epudaily1971.count


##input for 1972
epudaily1972=pd.read_csv('r_epudaily1972.csv')
epudaily1972.count

epudaily1972.head(10)
date_tochange=list(epudaily1972['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1972['date']=date_changed
epudaily1972.count

##input for 1973
epudaily1973=pd.read_csv('r_epudaily1973.csv')
epudaily1973.count

epudaily1973.head(10)
date_tochange=list(epudaily1973['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1973['date']=date_changed
epudaily1973.count

##input for 1974
epudaily1974=pd.read_csv('r_epudaily1974.csv')
epudaily1974.count

epudaily1974.head(10)
date_tochange=list(epudaily1974['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1974['date']=date_changed
epudaily1974.count

##input for 1975
epudaily1975=pd.read_csv('r_epudaily1975.csv')
epudaily1975.count

epudaily1975.head(10)
date_tochange=list(epudaily1975['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1975['date']=date_changed
epudaily1975.count


##input for 1976
epudaily1976=pd.read_csv('r_epudaily1976.csv')
epudaily1976.count

epudaily1976.head(10)
date_tochange=list(epudaily1976['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1976['date']=date_changed
epudaily1976.count

##input for 1977
epudaily1977=pd.read_csv('r_epudaily1977.csv')
epudaily1977.count

epudaily1977.head(10)
date_tochange=list(epudaily1977['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1977['date']=date_changed
epudaily1977.count


##input for 1978
epudaily1978=pd.read_csv('r_epudaily1978.csv')
epudaily1978.count

epudaily1978.head(10)
date_tochange=list(epudaily1978['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1978['date']=date_changed
epudaily1978.count


##input for 1979
epudaily1979=pd.read_csv('r_epudaily1979.csv')
epudaily1979.count

epudaily1979.head(10)
date_tochange=list(epudaily1979['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1979['date']=date_changed
epudaily1979.count


##input for 1980
epudaily1980=pd.read_csv('r_epudaily1980.csv')
epudaily1980.count
epudaily1980.columns
epudaily1980.columns=['date', 'epu', 'count', 'epu_count']
epudaily1980=epudaily1980.drop(epudaily1980.index[-20:])
epudaily1980.head(10)
date_tochange=list(epudaily1980['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1980['date']=date_changed
epudaily1980.count


##input for 1981
epudaily1981=pd.read_csv('r_epudaily1981.csv')
epudaily1981.count

epudaily1981.head(10)
date_tochange=list(epudaily1981['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1981['date']=date_changed
epudaily1981.count


##input for 1982
epudaily1982=pd.read_csv('r_epudaily1982.csv')
epudaily1982.count

epudaily1982.head(10)
date_tochange=list(epudaily1982['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1982['date']=date_changed
epudaily1982.count

##input for 1983
epudaily1983=pd.read_csv('r_epudaily1983.csv')
epudaily1983.count

epudaily1983.head(10)
date_tochange=list(epudaily1983['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1983['date']=date_changed
epudaily1983.count


##input for 1984
epudaily1984=pd.read_csv('r_epudaily1984.csv')
epudaily1984.count

epudaily1984.head(10)
date_tochange=list(epudaily1984['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1984['date']=date_changed
epudaily1984.count

##input for 1985
epudaily1985=pd.read_csv('r_epudaily1985.csv')
epudaily1985.count

epudaily1985.head(10)
date_tochange=list(epudaily1985['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1985['date']=date_changed
epudaily1985.count

##input for 1986
epudaily1986=pd.read_csv('r_epudaily1986.csv')
epudaily1986.count

epudaily1986.head(10)
date_tochange=list(epudaily1986['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1986['date']=date_changed
epudaily1986.count


##input for 1987
epudaily1987=pd.read_csv('r_epudaily1987.csv')
epudaily1987.count

epudaily1987.head(10)
date_tochange=list(epudaily1987['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1987['date']=date_changed
epudaily1987.count

##input for 1988
epudaily1988=pd.read_csv('r_epudaily1988.csv')
epudaily1988.count

epudaily1988.head(10)
date_tochange=list(epudaily1988['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1988['date']=date_changed
epudaily1988.count


##input for 1989
epudaily1989=pd.read_csv('r_epudaily1989.csv')
epudaily1989.count

epudaily1989.head(10)
date_tochange=list(epudaily1989['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1989['date']=date_changed
epudaily1989.count


##input for 1990
epudaily1990=pd.read_csv('r_epudaily1990.csv')
epudaily1990.count

epudaily1990.head(10)
date_tochange=list(epudaily1990['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1990['date']=date_changed
epudaily1990.count


##input for 1991
epudaily1991=pd.read_csv('r_epudaily1991.csv')
epudaily1991.count

epudaily1991.head(10)
date_tochange=list(epudaily1991['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1991['date']=date_changed
epudaily1991.count


##input for 1992
epudaily1992=pd.read_csv('r_epudaily1992.csv')
epudaily1992.count

epudaily1992.head(10)
date_tochange=list(epudaily1992['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1992['date']=date_changed
epudaily1992.count

##input for 1993
epudaily1993=pd.read_csv('r_epudaily1993.csv')
epudaily1993.count

epudaily1993.head(10)
date_tochange=list(epudaily1993['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1993['date']=date_changed
epudaily1993.count

##input for 1994
epudaily1994=pd.read_csv('r_epudaily1994.csv')
epudaily1994.count

epudaily1994.head(10)
date_tochange=list(epudaily1994['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1994['date']=date_changed
epudaily1994.count


##input for 1995
epudaily1995=pd.read_csv('r_epudaily1995.csv')
epudaily1995.count
epudaily1995.columns
epudaily1995.columns=['date', 'epu', 'count', 'epu_count']
epudaily1995=epudaily1995.drop(epudaily1995.index[:322])
epudaily1995=epudaily1995.drop(epudaily1995.index[-102:])
epudaily1995.head(10)
date_tochange=list(epudaily1995['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1995['date']=date_changed
epudaily1995.count


##input for 1996
epudaily1996=pd.read_csv('r_epudaily1996.csv')
epudaily1996.count

epudaily1996.head(10)
date_tochange=list(epudaily1996['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1996['date']=date_changed
epudaily1996.count


##input for 1997
epudaily1997=pd.read_csv('r_epudaily1997.csv')
epudaily1997.count

epudaily1997.head(10)
date_tochange=list(epudaily1997['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1997['date']=date_changed
epudaily1997.count



##input for 1998
epudaily1998=pd.read_csv('r_epudaily1998.csv')
epudaily1998.count

epudaily1998.head(10)
date_tochange=list(epudaily1998['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1998['date']=date_changed
epudaily1998.count

##input for 1999
epudaily1999=pd.read_csv('r_epudaily1999.csv')
epudaily1999.count

epudaily1999.head(10)
date_tochange=list(epudaily1999['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily1999['date']=date_changed
epudaily1999.count

##input for 2000
epudaily2000=pd.read_csv('r_epudaily2000.csv')
epudaily2000.count

epudaily2000.head(10)
date_tochange=list(epudaily2000['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2000['date']=date_changed
epudaily2000.count


##input for 2001
epudaily2001=pd.read_csv('r_epudaily2001.csv')
epudaily2001.count

epudaily2001.head(10)
date_tochange=list(epudaily2001['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2001['date']=date_changed
epudaily2001.count

##input for 2002
epudaily2002=pd.read_csv('r_epudaily2002.csv')
epudaily2002.count
epudaily2002=epudaily2002[epudaily2002.date !='2002-02—20']
epudaily2002=epudaily2002[epudaily2002.date !='2002-10—20']

epudaily2002.head(10)
date_tochange=list(epudaily2002['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2002['date']=date_changed
epudaily2002.count


##input for 2003
epudaily2003=pd.read_csv('r_epudaily2003.csv')
epudaily2003.count
epudaily2003=epudaily2003.drop(epudaily2003.index[-135:])

epudaily2003.tail(10)
date_tochange=list(epudaily2003['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2003['date']=date_changed
epudaily2003.count


##input for 2004
epudaily2004=pd.read_csv('r_epudaily2004.csv')
epudaily2004.count

epudaily2004.head(10)
date_tochange=list(epudaily2004['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2004['date']=date_changed
epudaily2004.count

##input for 2005
epudaily2005=pd.read_csv('r_epudaily2005.csv')
epudaily2005.count

epudaily2005.head(10)
date_tochange=list(epudaily2005['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2005['date']=date_changed
epudaily2005.count

##input for 2006
epudaily2006=pd.read_csv('r_epudaily2006.csv')
epudaily2006.count

epudaily2006.head(10)
date_tochange=list(epudaily2006['date'])
type(date_tochange[1])
date_tochange[:3]

date_changed=[datetime.strptime(d,'%Y-%m-%d').date() for d in date_tochange]
date_changed[:3]
epudaily2006['date']=date_changed
epudaily2006.head(10)


###merge data with the data processing below
os.chdir(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\data_csv\1946-2006')

a_epudaily2007_2017=pd.read_csv(r'r_epu_daily_normalized2007-2017.csv')
a_epudaily2007_2017.drop('epu_std', axis=1, inplace=True)
a_epudaily2007_2017.drop('epu_normalized', axis=1, inplace=True)
a_epudaily2007_2017.drop('Unnamed: 0', axis=1, inplace=True)
a_epudaily2007_2017.head(10)


a_epudaily1946_2017=epudaily1946.append([epudaily1947,
                                         epudaily1948,
                                         epudaily1949,
                                         epudaily1950,
                                         epudaily1951,
                                         epudaily1952,
                                         epudaily1953,
                                         epudaily1954,
                                         epudaily1955,
                                         epudaily1956,
                                         epudaily1957,
                                         epudaily1958,
                                         epudaily1959,
                                         epudaily1960,
                                         epudaily1961,
                                         epudaily1962,
                                         epudaily1963,
                                         epudaily1964,
                                         epudaily1965,
                                         epudaily1966,
                                         epudaily1967,
                                         epudaily1968,
                                         epudaily1969,
                                         epudaily1970,
                                         epudaily1971,
                                         epudaily1972,
                                         epudaily1973,
                                         epudaily1974,
                                         epudaily1975,
                                         epudaily1976,
                                         epudaily1977,
                                         epudaily1978,
                                         epudaily1979,
                                         epudaily1980,
                                         epudaily1981,
                                         epudaily1982,
                                         epudaily1983,
                                         epudaily1984,
                                         epudaily1985,
                                         epudaily1986,
                                         epudaily1987,
                                         epudaily1988,
                                         epudaily1989,
                                         epudaily1990,
                                         epudaily1991,
                                         epudaily1992,
                                         epudaily1993,
                                         epudaily1994,
                                         epudaily1995,
                                         epudaily1996,
                                         epudaily1997,
                                         epudaily1998,
                                         epudaily1999,
                                         epudaily2000,
                                         epudaily2001,
                                         epudaily2002,
                                         epudaily2003,
                                         epudaily2004,
                                         epudaily2005,
                                         epudaily2006,
                                         a_epudaily2007_2017])


a_epudaily1946_2017.to_csv('a_epudaily1946_2017.csv')
aggregate_epudailty1946_2017=pd.merge(fullrange, a_epudaily1946_2017,how='outer')
#aggregate_epudailty1946_2006_2011_2017=pd.merge(fullrange, a_epudaily1946_2003_2011_2017,how='outer')


aggregate_epudailty1946_2017.to_csv('aggregate_epudailty1946_2017.csv')
#aggregate_epudailty1946_2003_2011_2017.to_csv('aggregate_epudailty1946_2003_2011_2017.csv')



###generate daily index 
epu_std=aggregate_epudailty1946_2017['epu_count'].std()

aggregate_epudailty1946_2017['epu_std']\
=aggregate_epudailty1946_2017['epu_count']/epu_std
epu_mean=aggregate_epudailty1946_2017['epu_std'].mean()

aggregate_epudailty1946_2017['epu_normalized']\
=aggregate_epudailty1946_2017['epu_std']/epu_mean*100
aggregate_epudailty1946_2017.describe()

aggregate_epudailty1946_2017.head(n=10)
aggregate_epudailty1946_2017.tail(n=10)

aggregate_epudailty1946_2017.to_csv('reduced_epu_daily_normalized1949-2017.csv',encoding='utf-8')


#and monthly index

date_date=aggregate_epudailty1946_2017['date']
date_date=date_date.tolist()

import datetime
date_time=[]
for i in date_date:
    i=str(i)
    datetime0=datetime.datetime.strptime(i,'%Y-%m-%d')
    date_time.append(datetime0)


len(date_time)

month_time=[]
for i in date_time:
    month_time0=i.strftime('%Y-%m')
    month_time.append(month_time0)

len(month_time)

aggregate_epudailty1946_2017['month']=month_time

aggregate_epudailty1946_2017['month']

df_month=aggregate_epudailty1946_2017.groupby('month').sum().reset_index()
df_month['epu_count']=df_month['epu']/df_month['count']

df_month.head(n=10)

df_month.describe()
std2=df_month['epu_normalized'].std()
df_month['epu_month_std']=df_month['epu_normalized']/std2

mean2=df_month['epu_month_std'].mean()

df_month['epu_month_normalized']=df_month['epu_month_std']*100/mean2
df_month.head(10)
del df_month['epu_month_std']
df_month.head(10)
df_month.to_csv('reduced_epu_month_1949-2017.csv',encoding='utf-8')

