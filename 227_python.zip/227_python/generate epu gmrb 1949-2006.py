# -*- coding: utf-8 -*-
"""
Created on Wed Dec 12 15:40:28 2018

@author: dingq
"""

import os
import pandas as pd
path=r"C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\gmrb"

os.chdir(path)
folders=os.listdir(path)
folders=[f for f in folders if len(f)>3 and len(f)<5]
folders=folders[:-1]
folders=folders[:-11]

#counts1978_2007=pd.DataFrame()
#for i in folders1:
#    #path1=os.path.join(path,i)
#    files=os.listdir(i)
 #   excels=''.join([f for f in files if f.endswith(".xlsx")])
  #  counts=pd.read_excel(os.path.join(i,excels))
   # counts1978_2007=counts1978_2007.append(counts)
    
counts1949_2007=pd.DataFrame()
for i in folders:
    #path1=os.path.join(path,i)
    files=os.listdir(i)
    excels=''.join([f for f in files if f.endswith(".xlsx")])
    counts=pd.read_excel(os.path.join(i,excels))
    counts1949_2007=counts1949_2007.append(counts)

counts1949_2007.head(10)
counts1949_2007.columns=['date','count','num']

del counts1949_2007['num']
counts1949_2007.to_csv('number of articles.csv',index=False)
counts1949_2007.to_excel('number of articles.xlsx',index=False)

### the codes above finished the pull-together work of number of articles (1978-2007)


##generate complete datetime object 1949.06.16--2007.12.31
full1949_2007=pd.date_range(start='1949-06-16', end='2007-12-31')
len(full1949_2007)
full1949_2007=pd.DataFrame(full1949_2007, columns=['date'],index=full1949_2007)
full1949_2007.head(10)
full1949_2007.to_csv('range1949_2007.csv')


dateparse = lambda x: pd.datetime.strptime(x, '%Y.%m.%d')
counts1949_2007=pd.read_csv('number of articles.csv', parse_dates=['date'], date_parser=dateparse)
counts1949_2007=counts1949_2007.set_index('date')
counts1949_2007.head(10)
len(counts1949_2007)

fullcount1949_2007=pd.concat([full1949_2007,counts1949_2007], axis=1 ,sort=False)
len(fullcount1949_2007)
fullcount1949_2007.head(10)
fullcount1949_2007.to_csv('test.csv')
#####code above finished combine number of article
    
articles=[]
for i in folders:
    files=os.listdir(i)
    txts=[f for f in files if f.endswith(".txt")]
    for j in txts:
        with open(os.path.join(i,j), 'r+', errors='ignore') as f:
            article=f.read()
            article=article.replace(' ', '')
            article=article.replace('\n','')
            articles.append(article)

len(articles)
import re
datepattern=re.compile(r'\d{4}\.\d{2}\.\d{2}')

dates=[]
for i in articles:
    date=re.findall(datepattern,i) #identify dates
    dates.extend(date)

len(dates)

  
for i in dates:
    if len(i)==0:
        print(dates.index(i))
len(dates)
len(articles)

from datetime import datetime

dates0=[]
for i in dates:
    date_object = datetime.strptime(i, '%Y.%m.%d').date()
    date_object = datetime.strftime(date_object,'%Y-%m-%d')
    dates0.append(date_object)

articlelist=pd.DataFrame(data=articles,index=dates0)
articlelist.columns=['article']
articlelist.head(3)

import rexepu

p1 =rexepu.keywords(articles,rexepu.pp1)
articlelist['p1']=p1
p2 =rexepu.keywords(articles,rexepu.pp2)
articlelist['p2']=p2
p3 =rexepu.keywords(articles,rexepu.pp3)
articlelist['p3']=p3
p4 =rexepu.keywords(articles,rexepu.pp4)
articlelist['p4']=p4
p5 =rexepu.keywords(articles,rexepu.pp5)
articlelist['p5']=p5
p6 =rexepu.keywords(articles,rexepu.pp6)
articlelist['p6']=p6
p7 =rexepu.keywords(articles,rexepu.pp7)
articlelist['p7']=p7
p8 =rexepu.keywords(articles,rexepu.pp8)
articlelist['p8']=p8
p9 =rexepu.keywords(articles,rexepu.pp9)
articlelist['p9']=p9
p10 =rexepu.keywords(articles,rexepu.pp10)
articlelist['p10']=p10
p11 =rexepu.keywords(articles,rexepu.pp11)
articlelist['p11']=p11
p12 =rexepu.keywords(articles,rexepu.pp12)
articlelist['p12']=p12
p13 =rexepu.keywords(articles,rexepu.pp13)
articlelist['p13']=p13
p14 =rexepu.keywords(articles,rexepu.pp14)
articlelist['p14']=p14
p15 =rexepu.keywords(articles,rexepu.pp15)
articlelist['p15']=p15
p16 =rexepu.keywords(articles,rexepu.pp16)
articlelist['p16']=p16
p17 =rexepu.keywords(articles,rexepu.pp17)
articlelist['p17']=p17
p18 =rexepu.keywords(articles,rexepu.pp18)
articlelist['p18']=p18
p19 =rexepu.keywords(articles,rexepu.pp19)
articlelist['p19']=p19


t1 =rexepu.keywords(articles,rexepu.tp1)
articlelist['t1']=t1
t2 =rexepu.keywords(articles,rexepu.tp2)
articlelist['t2']=t2
t3 =rexepu.keywords(articles,rexepu.tp3)
articlelist['t3']=t3
t4 =rexepu.keywords(articles,rexepu.tp4)
articlelist['t4']=t4
t5 =rexepu.keywords(articles,rexepu.tp5)
articlelist['t5']=t5
t6 =rexepu.keywords(articles,rexepu.tp6)
articlelist['t6']=t6
t7 =rexepu.keywords(articles,rexepu.tp7)
articlelist['t7']=t7
t8 =rexepu.keywords(articles,rexepu.tp8)
articlelist['t8']=t8
t9 =rexepu.keywords(articles,rexepu.tp9)
articlelist['t9']=t9
t10 =rexepu.keywords(articles,rexepu.tp10)
articlelist['t10']=t10
t11 =rexepu.keywords(articles,rexepu.tp11)
articlelist['t11']=t11
t12 =rexepu.keywords(articles,rexepu.tp12)
articlelist['t12']=t12
t13 =rexepu.keywords(articles,rexepu.tp13)
articlelist['t13']=t13
t14 =rexepu.keywords(articles,rexepu.tp14)
articlelist['t14']=t14
t15 =rexepu.keywords(articles,rexepu.tp15)
articlelist['t15']=t15
t16 =rexepu.keywords(articles,rexepu.tp16)
articlelist['t16']=t16
t17 =rexepu.keywords(articles,rexepu.tp17)
articlelist['t17']=t17
t18 =rexepu.keywords(articles,rexepu.tp18)
articlelist['t18']=t18    
    

p=[]
t=[]


for i in range(len(articles)):        
        if p1[i]>0 or \
           p2[i]>0 or \
           p3[i]>0 or \
           p4[i]>0 or \
           p5[i]>0 or \
           p6[i]>0 or \
           p7[i]>0 or \
           p8[i]>0 or \
           p9[i]>0 or \
           p10[i]>0 or \
           p11[i]>0 or \
           p12[i]>0 or \
           p13[i]>0 or \
           p14[i]>0 or \
           p15[i]>0 or \
           p16[i]>0 or \
           p17[i]>0 or \
           p18[i]>0 or \
           p19[i]>0:
               p0=1
               p.append(p0)
        else:
            p0=0
            p.append(p0)
len(p)


for i in range(len(articles)):        
    if t1[i]>0 or \
       t2[i]>0 or \
       t3[i]>0 or \
       t4[i]>0 or \
       t5[i]>0 or \
       t6[i]>0 or \
       t7[i]>0 or \
       t8[i]>0 or \
       t9[i]>0 or \
       t10[i]>0 or \
       t11[i]>0 or \
       t12[i]>0 or \
       t13[i]>0 or \
       t14[i]>0 or \
       t15[i]>0 or \
       t16[i]>0 or \
       t17[i]>0 or \
       t18[i]>0: 
           t0=1
           t.append(t0)
    else:
        t0=0
        t.append(t0)
         
len(t)   



articlelist['p']=p
articlelist['t']=t

epu=[]
tpu=[]
tepu=[]

for i in range(len(articles)):
    if p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)

for i in range(len(articles)):
    if t[i]>0:
        tpu0=1
        tpu.append(tpu0)
    else:
        tpu0=0
        tpu.append(tpu0)

for i in range(len(articles)):
    if p[i]>0 and t[i]>0:
        tepu0=1
        tepu.append(tepu0)
    else:
        tepu0=0
        tepu.append(tepu0)




articlelist['epu']=epu
articlelist['tpu']=tpu
articlelist['tepu']=tepu



eputest=pd.DataFrame(data={'epu':epu,'date':dates0,'tpu':tpu,'tepu':tepu},index=dates0)
eputest.tail(20)

eputest1=eputest.groupby('date').sum()
eputest1.head(10)
eputest1.tail(10)
eputest1.to_csv('test.csv')

dateparse2 = lambda x: pd.datetime.strptime(x, '%Y-%m-%d')
eputest2=pd.read_csv('test.csv', parse_dates=['date'], date_parser=dateparse2)
eputest2=eputest2.set_index('date')
eputest2.head(10)


##generate full date range:

gmrbepu1949_2007=pd.concat([full1949_2007,eputest2], axis=1 ,sort=False)
gmrbepu1949_2007.head(20)

gmrbepu1949_2007.to_csv('gmrbepu1978_2007.csv')
len(gmrbepu1949_2007)

len(full1949_2007)

gmrbepucount1949_2007=pd.concat([fullcount1949_2007,gmrbepu1949_2007], axis=1 ,sort=False)
gmrbepucount1949_2007.head(10)

#gmrbepucount1949_2007.fillna(0)

count_0=list(gmrbepucount1949_2007['count'])
epu_0=list(gmrbepucount1949_2007['epu'])
tpu_0=list(gmrbepucount1949_2007['tpu'])
tepu_0=list(gmrbepucount1949_2007['tepu'])

import math

for i in epu_0:
    if math.isnan(count_0[epu_0.index(i)])==False and math.isnan(i)==True:
        epu_0[epu_0.index(i)]=0
        
for i in tpu_0:
    if math.isnan(count_0[tpu_0.index(i)])==False and math.isnan(i)==True:
        tpu_0[tpu_0.index(i)]=0

for i in tepu_0:
    if math.isnan(count_0[tepu_0.index(i)])==False and math.isnan(i)==True:
        tepu_0[tepu_0.index(i)]=0


epu_0[:50]

gmrbepucount1949_2007['epu']=epu_0
gmrbepucount1949_2007['tpu']=tpu_0
gmrbepucount1949_2007['tepu']=tepu_0


gmrbepucount1949_2007.head(10)
gmrbepucount1949_2007.to_csv('gmrbtepu1949_2007.csv')


