# -*- coding: utf-8 -*-
"""

"""

import os
import pandas as pd
import re
import sys
sys.path.append(r'C:\Users\dingq\AppData\Roaming\Python\Python39\site-packages')
sys.path.append(r'C:\Users\dingq\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.9_qbz5n2kfra8p0\LocalCache\local-packages\Python39\Scripts')
import rexepu

# for RMRB
path1 = r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\RMRB_compelete\rmrb1946_2006_full.txt'

with open(path1,'r+',errors='ignore') as f:
    text=f.read()
text=text.replace(' ', '') #delete space
text=text.replace('\n','') #delete lines
# match = text.split('\n') #split into single article

#identify dates and split annual text into single article with date label
datepattern=re.compile(r'\d{4}\.\d{2}\.\d{2}')
match = re.split(datepattern, text) #split into single article
del match[0]
del match[60356]

del match[165936]

del match[227002]

dateextract=re.findall(datepattern,text) #identify dates

date=[i.replace('.','-') for i in dateextract] #formalize date
del date[60356]
del date[165936]
del date[227002]

##to make sure the #of text matches that of date
if len(match)!=len(date):
    print('Split Error!')
else:
    print('Congrats, no error in splitting!')


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
articlelist=pd.DataFrame(data = match)
articlelist=pd.DataFrame(data = match, index = date)
articlelist['date'] = date
  
# save count of keywords into DataFrame
u1=rexepu.keywords(match,rexepu.pu1)
articlelist['u1']=u1
u2=rexepu.keywords(match,rexepu.pu2)
articlelist['u2']=u2
u3=rexepu.keywords(match,rexepu.pu3)
articlelist['u3']=u3
u4=rexepu.keywords(match,rexepu.pu4)
articlelist['u4']=u4
u5=rexepu.keywords(match,rexepu.pu5)
articlelist['u5']=u5
u6=rexepu.keywords(match,rexepu.pu6)
articlelist['u6']=u6
u7=rexepu.keywords(match,rexepu.pu7)
articlelist['u7']=u7
u8=rexepu.keywords(match,rexepu.pu8)
articlelist['u8']=u8
u9=rexepu.keywords(match,rexepu.pu9)
articlelist['u9']=u9
u10=rexepu.keywords(match,rexepu.pu10)
articlelist['u10']=u10

e1=rexepu.keywords(match,rexepu.pe1)
articlelist['e1']=e1
e2=rexepu.keywords(match,rexepu.pe2)
articlelist['e2']=e2

n3p3=rexepu.keywords(match,rexepu.n3p3) #农业
articlelist['ny']=n3p3
n1p4=rexepu.keywords(match,rexepu.n1p4) #工业
articlelist['gy']=n1p4
n1p2=rexepu.keywords(match,rexepu.n1p2) #生产
articlelist['sc']=n1p2



p1 =rexepu.keywords(match,rexepu.pp1)
articlelist['p1']=p1
p2 =rexepu.keywords(match,rexepu.pp2)
articlelist['p2']=p2
p3 =rexepu.keywords(match,rexepu.pp3)
articlelist['p3']=p3
p4 =rexepu.keywords(match,rexepu.pp4)
articlelist['p4']=p4
p5 =rexepu.keywords(match,rexepu.pp5)
articlelist['p5']=p5
p6 =rexepu.keywords(match,rexepu.pp6)
articlelist['p6']=p6
p7 =rexepu.keywords(match,rexepu.pp7)
articlelist['p7']=p7
p8 =rexepu.keywords(match,rexepu.pp8)
articlelist['p8']=p8
p9 =rexepu.keywords(match,rexepu.pp9)
articlelist['p9']=p9
p10 =rexepu.keywords(match,rexepu.pp10)
articlelist['p10']=p10
p11 =rexepu.keywords(match,rexepu.pp11)
articlelist['p11']=p11
p12 =rexepu.keywords(match,rexepu.pp12)
articlelist['p12']=p12
p13 =rexepu.keywords(match,rexepu.pp13)
articlelist['p13']=p13
p14 =rexepu.keywords(match,rexepu.pp14)
articlelist['p14']=p14
p15 =rexepu.keywords(match,rexepu.pp15)
articlelist['p15']=p15
p16 =rexepu.keywords(match,rexepu.pp16)
articlelist['p16']=p16
p17 =rexepu.keywords(match,rexepu.pp17)
articlelist['p17']=p17
p18 =rexepu.keywords(match,rexepu.pp18)
articlelist['p18']=p18 
p19 =rexepu.keywords(match,rexepu.pp19)
articlelist['p19']=p19



###generate index epu
u=[]
e=[]
p = []

for i in range(len(match)):        
    if u1[i]>0 or u2[i]>0 or u3[i]>0 or u4[i]>0 or u5[i]>0 or u6[i]>0 or u7[i]>0 or u8[i]>0 or u9[i]>0 or u10[i]>0:
           u0=1
           u.append(u0)
    else:
            u0=0
            u.append(u0)

for i in range(len(match)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)

for i in range(len(match)):        
    if p1[i]>0 or p2[i]>0 or p3[i]>0 or p4[i]>0 or p5[i]>0 or p6[i]>0 or p7[i]>0 or p8[i]>0 or p9[i]>0 or p10[i]>0 or p11[i]>0 or p12[i]>0 or p13[i]>0 or p14[i]>0 or p15[i]>0 or p16  [i]>0 or p17[i]>0 or p18[i]>0 or p19[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

epu = []

for i in range(len(match)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)

epuny = []

for i in range(len(match)):  
    if (u[i]>0 and e[i]>0) and (p[i]>0 or n3p3[i]>0):
        epuny0=1
        epuny.append(epuny0)
    else:
        epuny0=0
        epuny.append(epuny0)

epugy = []

for i in range(len(match)):  
    if (u[i]>0 and e[i]>0) and (p[i]>0 or n1p4[i]>0):
        epugy0=1
        epugy.append(epugy0)
    else:
        epugy0=0
        epugy.append(epugy0)

epusc = []

for i in range(len(match)):  
    if (u[i]>0 and e[i]>0) and (p[i]>0 or n1p2[i]>0):
        epusc0=1
        epusc.append(epusc0)
    else:
        epusc0=0
        epusc.append(epusc0)


eu=[]

for i in range(len(match)):  
    if u[i]>0 and e[i]>0:
        eu0=1
        eu.append(eu0)
    else:
        eu0=0
        eu.append(eu0)
 

if len(e)==len(u)==len(eu)==len(match)==len(match):
    print('Pass')
else:
    print('Alert')

#put epu index into DataFrame
articlelist['e']=e
articlelist['u']=u
articlelist['eu']=eu
articlelist['epuny']=epuny
articlelist['epugy']=epugy
articlelist['epusc']=epusc

banmian = re.compile(u'\d{1,}版名')

bans = []
cleans = []
for i in match: #50
    ban0 = ''.join(re.findall(banmian,i))[:-2]
    bans.append(ban0)
    cl = re.sub(u'\d{1,}版名', '  ', i)
    cl = re.sub(u'\s+', '', cl)

    cleans.append(cl)

articlelist['clean_match'] = cleans
articlelist['banmian'] = bans

articlelist = articlelist.rename(columns={0:'match'})

articlelist = articlelist.drop_duplicates(subset='clean_match', keep="first")

# articlelist.to_excel(r'search with machine using audit terms.xlsx')
articlelist = articlelist.loc[articlelist['eu']>0]


## ny
articlelist0 = articlelist.loc[articlelist['ny']>0]
articlelist0['year'] = pd.to_datetime(articlelist0['date']).dt.year
articlelist0 = articlelist0.loc[articlelist0['year']<1978]

articlelist0 = articlelist0.reset_index(drop=True)
articlelist0 = articlelist0.reset_index()

import numpy as np

#ny
sample_list = np.random.choice(range(len(articlelist0)), 100, replace=False).tolist()
articlelist.loc[articlelist['index'].astype(int).isin(sample_list), 'sample'] = 1
# articlelist.to_excel(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\audit\audit marginal nongye.xlsx')

samples = articlelist.loc[articlelist['sample']==1]
samples.to_excel(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\audit\audit marginal nongye 100 sample.xlsx')

#gy
articlelist1 = articlelist.loc[articlelist['gy']>0]
articlelist1['year'] = pd.to_datetime(articlelist1['date']).dt.year
articlelist1 = articlelist1.loc[articlelist1['year']<1978]

articlelist1 = articlelist1.reset_index(drop=True)
articlelist1 = articlelist1.reset_index()

sample_list1 = np.random.choice(len(articlelist1), 100, replace=False).tolist()
articlelist1.loc[articlelist1['index'].astype(int).isin(sample_list1), 'sample1'] = 1
# articlelist.to_excel(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\audit\audit marginal nongye.xlsx')

samples1 = articlelist1.loc[articlelist1['sample1']==1]
samples1.to_excel(r'audit marginal gongye 100 sample.xlsx')

#sc
articlelist2 = articlelist.loc[articlelist['sc']>0]
articlelist2['year'] = pd.to_datetime(articlelist2['date']).dt.year
articlelist2 = articlelist2.loc[articlelist2['year']<1978]

articlelist2 = articlelist2.reset_index(drop=True)
articlelist2 = articlelist2.reset_index()


sample_list2 = np.random.choice(len(articlelist2), 100, replace=False).tolist()
articlelist2.loc[articlelist2['index'].astype(int).isin(sample_list2), 'sample2'] = 1
# articlelist.to_excel(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\audit\audit marginal nongye.xlsx')

samples2 = articlelist2.loc[articlelist2['sample2']==1]
samples2.to_excel(r'audit marginal shengchan 100 sample.xlsx')


#### post audit, 

articlelist = pd.read_excel(r'C:\Users\dingq\Documents\200_academic\220_Academic_My dissertation\225_data_txt\audit\audit marginal nongye 100 sample_results.xlsx')

match = articlelist['match'].to_list()


##step2: generate epu index for each article with DataFrame
# put article and date into dataframe
# save count of keywords into DataFrame
u1=rexepu.keywords(match,rexepu.pu1)
articlelist['u1']=u1
u2=rexepu.keywords(match,rexepu.pu2)
articlelist['u2']=u2
u3=rexepu.keywords(match,rexepu.pu3)
articlelist['u3']=u3
u4=rexepu.keywords(match,rexepu.pu4)
articlelist['u4']=u4
u5=rexepu.keywords(match,rexepu.pu5)
articlelist['u5']=u5
u6=rexepu.keywords(match,rexepu.pu6)
articlelist['u6']=u6
u7=rexepu.keywords(match,rexepu.pu7)
articlelist['u7']=u7
u8=rexepu.keywords(match,rexepu.pu8)
articlelist['u8']=u8
u9=rexepu.keywords(match,rexepu.pu9)
articlelist['u9']=u9
u10=rexepu.keywords(match,rexepu.pu10)
articlelist['u10']=u10

e1=rexepu.keywords(match,rexepu.pe1)
articlelist['e1']=e1
e2=rexepu.keywords(match,rexepu.pe2)
articlelist['e2']=e2

n3p3=rexepu.keywords(match,rexepu.n3p3) #农业
articlelist['ny']=n3p3

p1 =rexepu.keywords(match,rexepu.pp1)
articlelist['p1']=p1
p2 =rexepu.keywords(match,rexepu.pp2)
articlelist['p2']=p2
p3 =rexepu.keywords(match,rexepu.pp3)
articlelist['p3']=p3
p4 =rexepu.keywords(match,rexepu.pp4)
articlelist['p4']=p4
p5 =rexepu.keywords(match,rexepu.pp5)
articlelist['p5']=p5
p6 =rexepu.keywords(match,rexepu.pp6)
articlelist['p6']=p6
p7 =rexepu.keywords(match,rexepu.pp7)
articlelist['p7']=p7
p8 =rexepu.keywords(match,rexepu.pp8)
articlelist['p8']=p8
p9 =rexepu.keywords(match,rexepu.pp9)
articlelist['p9']=p9
p10 =rexepu.keywords(match,rexepu.pp10)
articlelist['p10']=p10
p11 =rexepu.keywords(match,rexepu.pp11)
articlelist['p11']=p11
p12 =rexepu.keywords(match,rexepu.pp12)
articlelist['p12']=p12
p13 =rexepu.keywords(match,rexepu.pp13)
articlelist['p13']=p13
p14 =rexepu.keywords(match,rexepu.pp14)
articlelist['p14']=p14
p15 =rexepu.keywords(match,rexepu.pp15)
articlelist['p15']=p15
p16 =rexepu.keywords(match,rexepu.pp16)
articlelist['p16']=p16
p17 =rexepu.keywords(match,rexepu.pp17)
articlelist['p17']=p17
p18 =rexepu.keywords(match,rexepu.pp18)
articlelist['p18']=p18 
p19 =rexepu.keywords(match,rexepu.pp19)
articlelist['p19']=p19



###generate index epu
u=[]
e=[]
p = []

for i in range(len(match)):        
    if u1[i]>0 or u2[i]>0 or u3[i]>0 or u4[i]>0 or u5[i]>0 or u6[i]>0 or u7[i]>0 or u8[i]>0 or u9[i]>0 or u10[i]>0:
           u0=1
           u.append(u0)
    else:
            u0=0
            u.append(u0)

for i in range(len(match)):
    if (e1[i]>0 or e2[i]>0):
        e0=1
        e.append(e0)
    else:
        e0=0
        e.append(e0)

for i in range(len(match)):        
    if p1[i]>0 or p2[i]>0 or p3[i]>0 or p4[i]>0 or p5[i]>0 or p6[i]>0 or p7[i]>0 or p8[i]>0 or p9[i]>0 or p10[i]>0 or p11[i]>0 or p12[i]>0 or p13[i]>0 or p14[i]>0 or p15[i]>0 or p16  [i]>0 or p17[i]>0 or p18[i]>0 or p19[i]>0:
           p0=1
           p.append(p0)
    else:
        p0=0
        p.append(p0)

epu = []

for i in range(len(match)):  
    if u[i]>0 and e[i]>0 and p[i]>0:
        epu0=1
        epu.append(epu0)
    else:
        epu0=0
        epu.append(epu0)

epuny = []

for i in range(len(match)):  
    if u[i]>0 and e[i]>0 and p[i]>0 and n3p3[i]>0:
        epuny0=1
        epuny.append(epuny0)
    else:
        epuny0=0
        epuny.append(epuny0)

eu=[]

for i in range(len(match)):  
    if u[i]>0 and e[i]>0:
        eu0=1
        eu.append(eu0)
    else:
        eu0=0
        eu.append(eu0)
 

if len(e)==len(u)==len(eu)==len(epu)==len(epuny)==len(n3p3):
    print('Pass')
else:
    print('Alert')

#put epu index into DataFrame
articlelist['epu']=epu
articlelist['epuny']=epuny


articlelist.to_excel(r'audit marginal nongye 100 sample_with epu.xlsx')


## compare the results
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# base-line terms compare to true EPU
y_true = articlelist['Agriculture-related policy uncertainty'].to_list()
y_pred = articlelist['EPU_term B'].to_list()
confusion_matrix1 = confusion_matrix(y_true, y_pred)

cm_display2 = ConfusionMatrixDisplay(confusion_matrix = confusion_matrix1, display_labels = [False, True])

cm_display2.plot()
plt.show()

# base-line terms compare to true EPU about argriculture policy
